package com.claro.bffmiclaro.client;

import com.claro.bffmiclaro.configuration.restclient.RestClientCustom;
import com.claro.bffmiclaro.dto.response.customer.CustomerDto;
import com.claro.common.claro.dto.response.Response;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.hc.client5.http.HttpRoute;
import org.apache.hc.client5.http.config.ConnectionConfig;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.core5.function.Resolver;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class CustomerClient {

    private final RestClient restClient;
    private final Map<String, Resolver<HttpRoute, ConnectionConfig>> resolverMap;
    private final PoolingHttpClientConnectionManager connectionManager;

    @Value("${customer.rest-client.read-timeout}")
    private int readTimeout;

    @Value("${customer.rest-client.connect-timeout}")
    private int connectTimeout;

    @Value("${customer.rest-client.max-per-route}")
    private int maxPerRoute;

    @Value("${customer.path.customer-by-id}")
    private String customerByIdPath;

    @Value("${customer.path.customer-by-document}")
    private String customerByDocumentPath;

    @Value("${customer.url}")
    private String host;

    @PostConstruct
    public void initialize() {
        RestClientCustom.chargeCustomRoute(host + customerByIdPath, maxPerRoute, readTimeout, connectTimeout, resolverMap, connectionManager);
        RestClientCustom.chargeCustomRoute(host + customerByDocumentPath, maxPerRoute, readTimeout, connectTimeout, resolverMap, connectionManager);
    }

    public Response<List<CustomerDto>> getCustomerByDocument(String type, String number, String xRequestId, String xCorrelationId, String xClientVersionId, String jwtToken) {
        log.debug(":::::: Integration getCustomerByDocument: {} ::::::", host + customerByDocumentPath);
        return this.restClient.get()
                .uri(uriBuilder -> uriBuilder
                        .path(host + customerByDocumentPath)
                        .queryParam("type", type)
                        .queryParam("number", number)
                        .build())
                .header("Authorization", jwtToken)
                .header("x-request-id", xRequestId)
                .header("x-correlation-id", xCorrelationId)
                .header("x-client-version-id", xClientVersionId)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .onStatus(HttpStatusCode::isError,
                        (req, resp) -> RestClientCustom.decodeException(resp))
                .body(new ParameterizedTypeReference<>() { });
    }
}

