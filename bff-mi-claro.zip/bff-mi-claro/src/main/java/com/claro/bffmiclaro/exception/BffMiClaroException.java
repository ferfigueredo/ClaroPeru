package com.claro.bffmiclaro.exception;

public class BffMiClaroException extends RuntimeException {
    public BffMiClaroException(String errorMessage) {
        super(errorMessage);
    }
}