package com.claro.bffmiclaro.dto.response.invoice;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.List;

@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class BillsDetailResponse {

    private BigDecimal totalDebt;

    private String currency;

    private List<PaidBill> paidBills;

    private List<PendingBill> pendingBills;
}

