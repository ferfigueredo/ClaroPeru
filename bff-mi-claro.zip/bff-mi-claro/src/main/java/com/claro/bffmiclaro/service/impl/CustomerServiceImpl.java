package com.claro.bffmiclaro.service.impl;

import com.claro.bffmiclaro.client.CustomerClient;
import com.claro.bffmiclaro.client.ProductClient;
import com.claro.bffmiclaro.dto.response.customer.CustomerDto;
import com.claro.bffmiclaro.dto.response.CustomerLinesResponse;
import com.claro.bffmiclaro.dto.response.product.LineDto;
import com.claro.bffmiclaro.dto.response.product.ProductDto;
import com.claro.bffmiclaro.service.CustomerService;
import com.claro.common.claro.dto.response.Page;
import com.claro.common.claro.dto.response.PageResponse;
import com.claro.common.claro.dto.response.Response;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {

    private static final int PRODUCTS_PAGE_SIZE = 10;
    private final CustomerClient customerClient;
    private final ProductClient productClient;

    /** See {@link CustomerService#getCustomersWithProducts(String, String, String, String, String, int, int, String)} */
    @Override
    public PageResponse<List<CustomerLinesResponse>> getCustomersWithProducts(String type, String number, String xRequestId, String xCorrelationId, String xClientVersionId, int page, int size, String authorizationHeader) {

        List<CustomerDto> customers = this.fetchCustomers(type, number, xRequestId, xCorrelationId, xClientVersionId, authorizationHeader);
        if (customers.isEmpty()) {
            return new PageResponse<>("OK", 200, Collections.emptyList(), new Page(0, 0, 0));
        }

        List<String> customerIds = customers.stream().map(CustomerDto::getId).collect(Collectors.toList());
        List<ProductDto> allProducts = this.fetchAllProducts(customerIds, xRequestId, xCorrelationId, xClientVersionId, authorizationHeader);
        Map<String, List<LineDto>> linesByCustomerId = this.groupLinesByCustomerId(allProducts);
        List<CustomerLinesResponse> customerLinesResponses = this.buildCustomerLinesResponses(customers, linesByCustomerId);

        return paginate(customerLinesResponses, page, size);
    }

    private List<CustomerDto> fetchCustomers(String type, String number, String xRequestId, String xCorrelationId, String xClientVersionId, String authorizationHeader) {
        Response<List<CustomerDto>> customerResponse = this.customerClient.getCustomerByDocument(type, number, xRequestId, xCorrelationId, xClientVersionId, authorizationHeader);
        if (Objects.isNull(customerResponse) || Objects.isNull(customerResponse.data()) || customerResponse.data().isEmpty()) {
            return Collections.emptyList();
        }
        return customerResponse.data();
    }

    private List<ProductDto> fetchAllProducts(List<String> customerIds, String xRequestId, String xCorrelationId, String xClientVersionId, String authorizationHeader) {


        PageResponse<List<ProductDto>> firstPage = this.productClient.getAllProducts(1, PRODUCTS_PAGE_SIZE, null, customerIds, xRequestId, xCorrelationId, xClientVersionId, authorizationHeader);

        if (firstPage == null || firstPage.data() == null || firstPage.data().isEmpty()) {
            return Collections.emptyList();
        }

        List<ProductDto> allProducts = new ArrayList<>(firstPage.data());
        int totalPages = firstPage.page().getTotalPages();

        IntStream.rangeClosed(2, totalPages).parallel().forEach(pageNumber -> {
            PageResponse<List<ProductDto>> subsequentPage = this.productClient.getAllProducts(pageNumber, PRODUCTS_PAGE_SIZE, null, customerIds, xRequestId, xCorrelationId, xClientVersionId, authorizationHeader);
            if (subsequentPage != null && subsequentPage.data() != null) {
                synchronized (allProducts) {
                    allProducts.addAll(subsequentPage.data());
                }
            }
        });

        return allProducts;
    }

    private Map<String, List<LineDto>> groupLinesByCustomerId(List<ProductDto> products) {
        return products.stream()
                .collect(Collectors.groupingBy(ProductDto::getCustomerId,
                        Collectors.mapping(ProductDto::getLine, Collectors.toList())));
    }

    private List<CustomerLinesResponse> buildCustomerLinesResponses(List<CustomerDto> customers, Map<String, List<LineDto>> linesByCustomerId) {
        return customers.stream()
                .map(customer -> {
                    List<LineDto> customerLines = linesByCustomerId.getOrDefault(customer.getId(), Collections.emptyList());
                    return new CustomerLinesResponse(customer, customerLines);
                })
                .toList();
    }

    private PageResponse<List<CustomerLinesResponse>> paginate(List<CustomerLinesResponse> responses, int page, int size) {
        int totalItems = responses.size();
        int totalPages = (int) Math.ceil((double) totalItems / size);
        int fromIndex = (page - 1) * size;

        if (fromIndex >= totalItems) {
            return new PageResponse<>("OK", 200, Collections.emptyList(), new Page(totalPages, totalItems, size));
        }

        int toIndex = Math.min(fromIndex + size, totalItems);
        List<CustomerLinesResponse> paginatedList = responses.subList(fromIndex, toIndex);
        Page pageInfo = new Page(totalPages, totalItems, size);

        return new PageResponse<>("OK", 200, paginatedList, pageInfo);
    }
}
