package com.claro.bffmiclaro.client;

import com.claro.bffmiclaro.configuration.restclient.RestClientCustom;
import com.claro.bffmiclaro.dto.request.invoice.BillDto;
import com.claro.bffmiclaro.dto.response.invoice.BillsDetailResponse;
import com.claro.common.claro.dto.response.Response;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.hc.client5.http.HttpRoute;
import org.apache.hc.client5.http.config.ConnectionConfig;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.core5.function.Resolver;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class InvoiceClient {

    private final RestClient restClient;
    private final Map<String, Resolver<HttpRoute, ConnectionConfig>> resolverMap;
    private final PoolingHttpClientConnectionManager connectionManager;

    @Value("${invoice.rest-client.read-timeout}")
    private int readTimeout;

    @Value("${invoice.rest-client.connect-timeout}")
    private int connectTimeout;

    @Value("${invoice.rest-client.max-per-route}")
    private int maxPerRoute;

    @Value("${invoice.path.bills}")
    private String billsPath;

    @Value("${invoice.url}")
    private String host;

    @PostConstruct
    public void initialize() {
        RestClientCustom.chargeCustomRoute(host + billsPath, maxPerRoute, readTimeout, connectTimeout, resolverMap, connectionManager);
    }

    public Response<BillsDetailResponse> getBills(BillDto billDto) {
        log.debug(":::::: Integration getBills: {} ::::::", host + billsPath);
        return this.restClient.get()
                .uri(uriBuilder -> uriBuilder
                        .path(host + billsPath)
                        .queryParam("document-type", billDto.getDocumentType())
                        .queryParam("document-number", billDto.getDocumentNumber())
                        .queryParam("lineNumber", billDto.getLineNumber())
                        .queryParam("history-months", billDto.getHistoryMonths())
                        .queryParam("pending-records-count", billDto.getPendingRecordsCount())
                        .queryParam("historical-records-count", billDto.getHistoricalRecordsCount())
                        .build())
                .header("Authorization", billDto.getAuthorizationHeader())
                .header("x-correlation-id", billDto.getXCorrelationId())
                .header("x-request-id", billDto.getXRequestId())
                .header("x-client-version-id", billDto.getXClientVersionId())
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .onStatus(HttpStatusCode::isError,
                        (req, resp) -> RestClientCustom.decodeException(resp))
                .body(new ParameterizedTypeReference<>() {
                });
    }
}

