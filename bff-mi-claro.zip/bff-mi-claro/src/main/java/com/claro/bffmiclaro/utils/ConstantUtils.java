package com.claro.bffmiclaro.utils;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ConstantUtils {

    public static final String LOG_ERROR_RESPONSE = "::: Error {} ::: {}";
    public static final String LOG_ERROR = "::: An error occurred consuming the service, Status: {} :::";
    public static final String DESERIALIZATION_ERROR = "::: Error Deserializing response from client :::";
}
