package com.claro.bffmiclaro.exception;

import com.claro.common.claro.exceptions.dto.ErrorDTO;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
public class ClientException extends RuntimeException {

    private final ErrorDTO errorDTO;
    private final HttpStatus httpStatus;

    public ClientException(ErrorDTO errorDTO, HttpStatus httpStatus, String message) {
        super(message);
        this.errorDTO = errorDTO;
        this.httpStatus = httpStatus;
    }
}

