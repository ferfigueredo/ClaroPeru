package com.claro.bffmiclaro.service;

import com.claro.bffmiclaro.dto.request.invoice.BillDto;
import com.claro.bffmiclaro.dto.response.invoice.BillsDetailResponse;
import com.claro.common.claro.dto.response.Response;

public interface InvoiceService {

    /**
     * Get bills by customer
     *
     * @param billDto
     * @return
     */
    Response<BillsDetailResponse> getBills(BillDto billDto);
}

