package com.claro.bffmiclaro.service.impl;

import com.claro.bffmiclaro.client.InvoiceClient;
import com.claro.bffmiclaro.dto.request.invoice.BillDto;
import com.claro.bffmiclaro.dto.response.invoice.BillsDetailResponse;
import com.claro.bffmiclaro.service.InvoiceService;
import com.claro.common.claro.dto.response.Response;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class InvoiceServiceImpl implements InvoiceService {

    private final InvoiceClient invoiceClient;

    /** See {@link InvoiceService#getBills(BillDto)} */
    @Override
    public Response<BillsDetailResponse> getBills(BillDto billDto) {
        return this.invoiceClient.getBills(billDto);
    }
}
