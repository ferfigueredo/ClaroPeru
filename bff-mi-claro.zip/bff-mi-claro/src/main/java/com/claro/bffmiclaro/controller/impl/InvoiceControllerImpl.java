package com.claro.bffmiclaro.controller.impl;

import com.claro.bffmiclaro.controller.InvoiceController;
import com.claro.bffmiclaro.dto.request.invoice.BillDto;
import com.claro.bffmiclaro.dto.response.invoice.BillsDetailResponse;
import com.claro.bffmiclaro.service.InvoiceService;
import com.claro.common.claro.dto.response.Response;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class InvoiceControllerImpl implements InvoiceController {

    private final InvoiceService invoiceService;

    /** See {@link InvoiceController#getBills(String, String, String, Integer, Integer, Integer, String, String, String, String)} )} */
    @Override
    public ResponseEntity<Response<BillsDetailResponse>> getBills(String documentType, String documentNumber, String lineNumber,
                                                                  Integer historyMonths, Integer pendingRecordsCount,
                                                                  Integer historicalRecordsCount, String xCorrelationId,
                                                                  String xRequestId, String xClientVersionId, String authorizationHeader) {
        var billRequest = BillDto.builder()
                .documentType(documentType)
                .documentNumber(documentNumber)
                .lineNumber(lineNumber)
                .historyMonths(historyMonths)
                .pendingRecordsCount(pendingRecordsCount)
                .historicalRecordsCount(historicalRecordsCount)
                .xCorrelationId(xCorrelationId)
                .xRequestId(xRequestId)
                .xClientVersionId(xClientVersionId)
                .authorizationHeader(authorizationHeader)
                .build();
        return ResponseEntity.ok(this.invoiceService.getBills(billRequest));
    }
}
