package com.claro.bffmiclaro.dto.request.invoice;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillDto {
    private String documentType;
    private String documentNumber;
    private String lineNumber;
    private Integer historyMonths;
    private Integer pendingRecordsCount;
    private Integer historicalRecordsCount;
    private String xCorrelationId;
    private String xRequestId;
    private String xClientVersionId;
    private String authorizationHeader;
}

