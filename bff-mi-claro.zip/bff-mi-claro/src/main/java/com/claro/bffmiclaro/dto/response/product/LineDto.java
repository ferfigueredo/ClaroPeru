package com.claro.bffmiclaro.dto.response.product;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LineDto {

    private String coId;

    private String lineNumber;

    private String type;

    private String planCode;

    private String planDescription;

    private String alias;


}
