package com.claro.bffmiclaro.controller;

import com.claro.bffmiclaro.dto.response.CustomerLinesResponse;
import com.claro.common.claro.dto.response.PageResponse;
import com.claro.common.claro.exceptions.dto.ErrorDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@RequestMapping("/bff-mi-claro/api")
@Tag(name = "customer", description = "The Customer API")
public interface CustomerController {


    /**
     * Get customers with products
     *
     * @param type Customer's document type
     * @param number Customer's document number
     * @param xRequestId Request ID for tracking the request
     * @param xCorrelationId Correlation ID for tracking the request
     * @param xClientVersionId Client version ID
     * @param page Page number
     * @param size Page size
     * @return A paginated list of customers with their products
     */

    @Operation(summary = "Get customers with products", description = "Get customers with products",
            responses = {
                    @ApiResponse(responseCode = "200", description = "OK", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = PageResponse.class),
                                    examples = {
                                            @ExampleObject(name = "Successful response.",
                                                    value = """
                                                            {
                                                              "message": "Successful operation",
                                                              "code": 200,
                                                              "data": [
                                                                {
                                                                  "customer": {
                                                                    "customerId": "123",
                                                                    "documentType": "DNI",
                                                                    "documentNumber": "12345678",
                                                                    "name": "John",
                                                                    "lastName": "Doe",
                                                                    "email": "john.doe@example.com"
                                                                  },
                                                                  "lines": [
                                                                    {
                                                                      "lineNumber": "987654321",
                                                                      "status": "Active",
                                                                      "plan": "Postpago",
                                                                      "planType": "Mobile",
                                                                      "activationDate": "2023-01-01",
                                                                      "lineType": "Mobile",
                                                                      "mainLine": "true"
                                                                    }
                                                                  ]
                                                                }
                                                              ],
                                                              "page": {
                                                                "size": 10,
                                                                "totalElements": 1,
                                                                "totalPages": 1,
                                                                "number": 1
                                                              }
                                                            }
                                                            """)
                                    })}),
                    @ApiResponse(responseCode = "400", description = "Validation error on parameters", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class),
                                    examples = {
                                            @ExampleObject(name = "Invalid parameter", value = """
                                                    {
                                                          "code": 400,
                                                          "detail": "Invalid document type.",
                                                          "message": "CUSTOMER_ERROR",
                                                          "status": "BAD_REQUEST",
                                                          "subType": "CUST1",
                                                          "type": "InvalidParameterException"
                                                      }
                                                    """)
                                    })}),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class),
                                    examples = {
                                            @ExampleObject(name = "Resource not found", value = """
                                                    {
                                                        "code": 404,
                                                        "detail": "Customer not found",
                                                        "message": "CUSTOMER_ERROR",
                                                        "status": "NOT_FOUND",
                                                        "subType": "CUST3",
                                                        "type": "NotFoundException"
                                                    }
                                                    """)
                                    })}),
                    @ApiResponse(responseCode = "500", description = "Internal server error", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class),
                                    examples = {
                                            @ExampleObject(name = "Internal server error.",
                                                    value = """
                                                            {
                                                            "code": 500,
                                                            "detail": "There is an internal problem."
                                                            "message": "CUSTOMER_ERROR",
                                                            "status": "INTERNAL_SERVER_ERROR",
                                                            "subType": "ERROR",
                                                            "type": "ClientException"
                                                             }
                                                            """)
                                    })
                    })
            })
    @GetMapping(value = "/v1/customers", produces = "application/json")
    ResponseEntity<PageResponse<List<CustomerLinesResponse>>> getCustomersWithProducts(
            @Parameter(in = ParameterIn.QUERY, description = "Customer's document type", required = true, schema = @Schema(type = "string")) @RequestParam("document-type") String type,
            @Parameter(in = ParameterIn.QUERY, description = "Customer's document number", required = true, schema = @Schema(type = "string")) @RequestParam("document-number") String number,
            @Parameter(in = ParameterIn.HEADER, description = "Request ID for tracking the request", required = true, schema = @Schema(type = "string")) @RequestHeader("x-request-id") String xRequestId,
            @Parameter(in = ParameterIn.HEADER, description = "Correlation ID for tracking the request", required = true, schema = @Schema(type = "string")) @RequestHeader("x-correlation-id") String xCorrelationId,
            @Parameter(in = ParameterIn.HEADER, description = "Client version ID", required = true, schema = @Schema(type = "string")) @RequestHeader("x-client-version-id") String xClientVersionId,
            @Parameter(in = ParameterIn.QUERY, description = "Page number", required = true, schema = @Schema(type = "integer", defaultValue = "1")) @RequestParam(value = "page", defaultValue = "1") int page,
            @Parameter(in = ParameterIn.QUERY, description = "Page size", required = true, schema = @Schema(type = "integer", defaultValue = "10")) @RequestParam(value = "size", defaultValue = "10") int size,
            @Parameter(in = ParameterIn.HEADER, description = "Authorization token", required = true, schema = @Schema(type = "string")) @RequestHeader("Authorization") String authorizationHeader
    );
}
