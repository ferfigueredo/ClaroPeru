package com.claro.bffmiclaro.controller.impl;

import com.claro.bffmiclaro.controller.CustomerController;
import com.claro.bffmiclaro.dto.response.CustomerLinesResponse;
import com.claro.bffmiclaro.service.CustomerService;
import com.claro.common.claro.dto.response.PageResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class CustomerControllerImpl implements CustomerController {

    private final CustomerService customerService;

    /** See {@link CustomerController#getCustomersWithProducts(String, String, String, String, String, int, int, String)} */
    @Override
    public ResponseEntity<PageResponse<List<CustomerLinesResponse>>> getCustomersWithProducts(String type, String number, String xRequestId, String xCorrelationId, String xClientVersionId, int page, int size, String authorizationHeader) {
        return ResponseEntity.ok(this.customerService.getCustomersWithProducts(type, number, xRequestId, xCorrelationId, xClientVersionId, page, size, authorizationHeader));
    }
}
