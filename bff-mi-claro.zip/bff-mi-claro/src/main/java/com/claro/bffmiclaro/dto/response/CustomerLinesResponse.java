package com.claro.bffmiclaro.dto.response;

import com.claro.bffmiclaro.dto.response.customer.CustomerDto;
import com.claro.bffmiclaro.dto.response.product.LineDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerLinesResponse {
    private CustomerDto customer;
    private List<LineDto> lines;
}

