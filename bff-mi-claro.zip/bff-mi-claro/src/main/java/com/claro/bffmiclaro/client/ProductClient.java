package com.claro.bffmiclaro.client;

import com.claro.bffmiclaro.configuration.restclient.RestClientCustom;
import com.claro.bffmiclaro.dto.response.product.ProductDto;
import com.claro.common.claro.dto.response.PageResponse;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.hc.client5.http.HttpRoute;
import org.apache.hc.client5.http.config.ConnectionConfig;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.core5.function.Resolver;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class ProductClient {

    private final RestClient restClient;
    private final Map<String, Resolver<HttpRoute, ConnectionConfig>> resolverMap;
    private final PoolingHttpClientConnectionManager connectionManager;

    @Value("${product.rest-client.read-timeout}")
    private int readTimeout;

    @Value("${product.rest-client.connect-timeout}")
    private int connectTimeout;

    @Value("${product.rest-client.max-per-route}")
    private int maxPerRoute;

    @Value("${product.path.products}")
    private String productsPath;

    @Value("${product.url}")
    private String host;

    @PostConstruct
    public void initialize() {
        RestClientCustom.chargeCustomRoute(host + productsPath, maxPerRoute, readTimeout, connectTimeout, resolverMap, connectionManager);
    }

    public PageResponse<List<ProductDto>> getAllProducts(Integer pageNumber, Integer pageSize, String lineNumber,
                                                         List<String> customerId, String xRequestId,
                                                         String xCorrelationId, String xClientVersionId, String jwtToken) {
        log.debug(":::::: Integration getAllProducts: {} ::::::", host + productsPath);
        return this.restClient.get()
                .uri(uriBuilder -> uriBuilder
                        .path(host + productsPath)
                        .queryParam("page-number", pageNumber)
                        .queryParam("page-size", pageSize)
                        .queryParam("line-number", lineNumber)
                        .queryParam("customer-id", customerId.toArray())
                        .build())
                .header("Authorization", jwtToken)
                .header("x-request-id", xRequestId)
                .header("x-correlation-id", xCorrelationId)
                .header("x-client-version-id", xClientVersionId)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .onStatus(HttpStatusCode::isError,
                        (req, resp) -> RestClientCustom.decodeException(resp))
                .body(new ParameterizedTypeReference<>() { });
    }
}

