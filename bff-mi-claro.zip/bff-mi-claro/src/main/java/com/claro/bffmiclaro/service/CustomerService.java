package com.claro.bffmiclaro.service;

import com.claro.bffmiclaro.dto.response.CustomerLinesResponse;
import com.claro.common.claro.dto.response.PageResponse;

import java.util.List;

public interface CustomerService {

    /**
     * Get customers with products
     *
     * @param type Customer's document type
     * @param number Customer's document number
     * @param xRequestId Request ID for tracking the request
     * @param xCorrelationId Correlation ID for tracking the request
     * @param xClientVersionId Client version ID
     * @param page Page number
     * @param size Page size
     * @param authorizationHeader Authorization token
     * @return A paginated list of customers with their products
     */
    PageResponse<List<CustomerLinesResponse>> getCustomersWithProducts(String type, String number, String xRequestId, String xCorrelationId, String xClientVersionId, int page, int size, String authorizationHeader);
}
