package com.claro.bffmiclaro.configuration.restclient;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.springframework.context.annotation.Bean;
import org.apache.hc.client5.http.config.RequestConfig;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestClient;
import org.apache.hc.core5.util.Timeout;

@Configuration
@RequiredArgsConstructor
public class RestClientConfig {

    /*
     * defaultPoolTimeout: Time out de la cola de espera del pool, tiempo maximo que esperará un request para ser atendido por el
     *  pool en caso de estar trabajando en su maxima capacidad.
     */

    @Value("${rest-client.default.pool-deadline-timeout}")
    private int defaultPoolTimeout;

    private final PoolingHttpClientConnectionManager poolManager;

    @Bean
    public RestClient createGenericRestClient(RestClient.Builder restClientBuilder) {
        return restClientBuilder
                .requestFactory(clientHttpRequestFactory())
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .build();
    }

    private ClientHttpRequestFactory clientHttpRequestFactory() {
        var requestConfig = RequestConfig.custom()
                .setConnectionRequestTimeout(Timeout.ofSeconds(defaultPoolTimeout))
                .build();
        return new HttpComponentsClientHttpRequestFactory(HttpClientBuilder.create()
                .setConnectionManager(poolManager)
                .setDefaultRequestConfig(requestConfig)
                .build());
    }
}
