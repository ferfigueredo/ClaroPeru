package com.claro.bffmiclaro.controller;

import com.claro.bffmiclaro.dto.response.invoice.BillsDetailResponse;
import com.claro.common.claro.dto.response.Response;
import com.claro.common.claro.exceptions.dto.ErrorDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RequestMapping("/bff-mi-claro/api")
@Tag(name = "invoices", description = "The Invoices API")
public interface InvoiceController {

    /**
     * List paid and pending bills.
     * @param documentType
     * @param documentNumber
     * @param lineNumber
     * @param historyMonths
     * @param pendingRecordsCount
     * @param historicalRecordsCount
     * @param xCorrelationId
     * @param xRequestId
     * @return
     */
    @Operation(
            operationId = "getBills",
            summary = "List paid and pending bills",
            tags = {"invoices"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "OK", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = BillsDetailResponse.class),
                                    examples = {
                                            @ExampleObject(name = "Successful response.",
                                                    value = """
                                                            {
                                                                "message": "Successful operation",
                                                                "code": 200,
                                                                "data": {
                                                                    "totalDebt": 104.5,
                                                                    "currency": "PEN",
                                                                    "paidBills": [
                                                                        {
                                                                            "type": "REC",
                                                                            "number": "SB01-0465448455",
                                                                            "name": "Recibo agosto    ",
                                                                            "amount": 69.9,
                                                                            "paymentDue": "2025-08-14T00:00:00",
                                                                            "lineNumbers": [
                                                                                "001"
                                                                            ]
                                                                        }
                                                                    ],
                                                                    "pendingBills": [
                                                                        {
                                                                            "type": "REC",
                                                                            "number": "SB01-0465448456",
                                                                            "name": "Recibo septiembre",
                                                                            "amount": 59.5,
                                                                            "dueDate": "2025-09-14T00:00:00",
                                                                            "lineNumbers": [
                                                                                "001"
                                                                            ]
                                                                        }
                                                                    ]
                                                                }
                                                            }
                                                            """)
                                    })}),
                    @ApiResponse(responseCode = "400", description = "Validation error on parameters", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class),
                                    examples = {
                                            @ExampleObject(name = "Invalid parameter", value = """
                                                    {
                                                          "code": 400,
                                                          "detail": "You must provide either document info (type and number) or a line number.",
                                                          "message": "INVOICE_ERROR",
                                                          "status": "BAD_REQUEST",
                                                          "subType": "IDF1",
                                                          "type": "InvalidParameterException"
                                                      }
                                                    """)
                                    })}),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class),
                                    examples = {
                                            @ExampleObject(name = "Resource not found", value = """
                                                    {
                                                        "code": 404,
                                                        "detail": "No Existe Cliente",
                                                        "message": "INVOICE_ERROR",
                                                        "status": "NOT_FOUND",
                                                        "subType": "IDF3",
                                                        "type": "StoredProcedureException"
                                                    }
                                                    """)
                                    })}),
                    @ApiResponse(responseCode = "500", description = "Internal server error", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class),
                                    examples = {
                                            @ExampleObject(name = "Internal server error.",
                                                    value = """
                                                                            {
                                                                            "code": 500,
                                                                            "detail": "There is an internal problem."
                                                                            "message": "INVOICE_ERROR",
                                                                            "status": "INTERNAL_SERVER_ERROR",
                                                                            "subType": "ERROR",
                                                                            "type": "ClientException"
                                                                             }
                                                            """)
                                    })
                    })})

    @GetMapping("/v1/invoices")
    ResponseEntity<Response<BillsDetailResponse>> getBills(
            @Parameter(in = ParameterIn.QUERY, description = "Customer's document type", required = true, schema = @Schema(type = "string")) @RequestParam("document-type") String documentType,
            @Parameter(in = ParameterIn.QUERY, description = "Customer's document number", required = true, schema = @Schema(type = "string")) @RequestParam("document-number") String documentNumber,
            @RequestParam(name = "line-number", required = false) String lineNumber,
            @RequestParam(name = "history-months", required = false) Integer historyMonths,
            @RequestParam(name = "pending-records-count", required = false) Integer pendingRecordsCount,
            @RequestParam(name = "historical-records-count", required = false) Integer historicalRecordsCount,
            @Parameter(in = ParameterIn.HEADER, description = "Request ID for tracking the request", required = true, schema = @Schema(type = "string")) @RequestHeader("x-request-id") String xRequestId,
            @Parameter(in = ParameterIn.HEADER, description = "Correlation ID for tracking the request", required = true, schema = @Schema(type = "string")) @RequestHeader("x-correlation-id") String xCorrelationId,
            @Parameter(in = ParameterIn.HEADER, description = "Client version ID", required = true, schema = @Schema(type = "string")) @RequestHeader("x-client-version-id") String xClientVersionId,
            @Parameter(in = ParameterIn.HEADER, description = "Authorization token", required = true, schema = @Schema(type = "string")) @RequestHeader("Authorization") String authorizationHeader
    );
}