package com.claro.bffmiclaro.controller.impl;

import com.claro.bffmiclaro.dto.response.invoice.BillsDetailResponse;
import com.claro.bffmiclaro.service.InvoiceService;
import com.claro.common.claro.dto.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static com.claro.bffmiclaro.utils.TestUtils.CELLULAR_NUMBER;
import static com.claro.bffmiclaro.utils.TestUtils.CLIENT_VERSION_ID;
import static com.claro.bffmiclaro.utils.TestUtils.CORRELATION_ID;
import static com.claro.bffmiclaro.utils.TestUtils.DOCUMENT_NUMBER;
import static com.claro.bffmiclaro.utils.TestUtils.DOCUMENT_TYPE;
import static com.claro.bffmiclaro.utils.TestUtils.JWT_TOKEN;
import static com.claro.bffmiclaro.utils.TestUtils.REQUEST_ID;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class InvoiceControllerImplTest {

    private InvoiceService invoiceService;
    private InvoiceControllerImpl invoiceController;

    @BeforeEach
    void setUp() {
        this.invoiceService = mock(InvoiceService.class);
        this.invoiceController = new InvoiceControllerImpl(invoiceService);
    }

    @Test
    void getBillsShouldReturnOk() {

        var response = new Response<>(HttpStatus.OK.name(), HttpStatus.OK.value(), new BillsDetailResponse());
        when(this.invoiceService.getBills(any())).thenReturn(response);

        var result = this.invoiceController.getBills(DOCUMENT_TYPE, DOCUMENT_NUMBER, CELLULAR_NUMBER, 1, 1, 1, CORRELATION_ID, REQUEST_ID, CLIENT_VERSION_ID, JWT_TOKEN);

        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(response, result.getBody());
    }

}
