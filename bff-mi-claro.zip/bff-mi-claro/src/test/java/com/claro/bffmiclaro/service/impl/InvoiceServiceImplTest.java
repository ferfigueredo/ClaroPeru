package com.claro.bffmiclaro.service.impl;

import com.claro.bffmiclaro.client.InvoiceClient;
import com.claro.bffmiclaro.dto.request.invoice.BillDto;
import com.claro.bffmiclaro.dto.response.invoice.BillsDetailResponse;
import com.claro.common.claro.dto.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class InvoiceServiceImplTest {

    private InvoiceClient invoiceClient;
    private InvoiceServiceImpl invoiceService;

    @BeforeEach
    void setUp() {
        this.invoiceClient = mock(InvoiceClient.class);
        this.invoiceService = new InvoiceServiceImpl(invoiceClient);
    }

    @Test
    void getBillsShouldReturnResponseFromClient() {
        var response = new Response<>(HttpStatus.OK.name(), HttpStatus.OK.value(), new BillsDetailResponse());
        when(invoiceClient.getBills(any())).thenReturn(response);

        Response<BillsDetailResponse> result = invoiceService.getBills(new BillDto());

        assertNotNull(result);
        assertEquals(response, result);
    }
}
