package com.claro.bffmiclaro.utils;

public class TestUtils {

    public static final int DEFAULT_TIME_MILLISECONDS = 10000;
    public static final int DEFAULT_PAGE_SIZE = 10;

    public static final String DOCUMENT_TYPE = "DNI";
    public static final String DOCUMENT_NUMBER = "123456789";
    public static final String CORRELATION_ID = "123456789";
    public static final String REQUEST_ID = "123456789";
    public static final String CLIENT_VERSION_ID = "123456789";
    public static final String CELLULAR_NUMBER = "123456789";
    public static final String JWT_TOKEN = "eyJhbGciOi";
}

