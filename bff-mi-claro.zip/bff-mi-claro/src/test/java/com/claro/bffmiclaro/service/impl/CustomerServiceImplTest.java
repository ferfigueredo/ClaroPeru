package com.claro.bffmiclaro.service.impl;

import com.claro.bffmiclaro.client.CustomerClient;
import com.claro.bffmiclaro.client.ProductClient;
import com.claro.bffmiclaro.dto.response.customer.CustomerDto;
import com.claro.bffmiclaro.dto.response.product.LineDto;
import com.claro.bffmiclaro.dto.response.product.ProductDto;
import com.claro.bffmiclaro.utils.TestUtils;
import com.claro.common.claro.dto.response.Page;
import com.claro.common.claro.dto.response.PageResponse;
import com.claro.common.claro.dto.response.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Collections;
import java.util.List;

import static com.claro.bffmiclaro.utils.TestUtils.CLIENT_VERSION_ID;
import static com.claro.bffmiclaro.utils.TestUtils.CORRELATION_ID;
import static com.claro.bffmiclaro.utils.TestUtils.DEFAULT_PAGE_SIZE;
import static com.claro.bffmiclaro.utils.TestUtils.DOCUMENT_NUMBER;
import static com.claro.bffmiclaro.utils.TestUtils.JWT_TOKEN;
import static com.claro.bffmiclaro.utils.TestUtils.REQUEST_ID;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class CustomerServiceImplTest {

    private CustomerClient customerClient;
    private ProductClient productClient;
    private CustomerServiceImpl customerService;

    @BeforeEach
    void setUp() {
        this.customerClient = mock(CustomerClient.class);
        this.productClient = mock(ProductClient.class);
        this.customerService = new CustomerServiceImpl(customerClient, productClient);
    }

    @Test
    void getCustomersWithProductsShouldReturnEmptyWhenNoCustomers() {
        when(customerClient.getCustomerByDocument(any(), any(), any(), any(), any(), any())).thenReturn(new Response<>("OK", 200, Collections.emptyList()));
        var result = customerService.getCustomersWithProducts(TestUtils.DOCUMENT_TYPE, DOCUMENT_NUMBER, REQUEST_ID, CORRELATION_ID, CLIENT_VERSION_ID, 1, DEFAULT_PAGE_SIZE, JWT_TOKEN);
        assertNotNull(result);
        assertEquals(0, result.data().size());
    }

    @Test
    void getCustomersWithProductsShouldReturnCustomersWithNoProducts() {
        var customer = new CustomerDto();
        customer.setId("1");
        when(customerClient.getCustomerByDocument(any(), any(), any(), any(), any(), any())).thenReturn(new Response<>("OK", 200, List.of(customer)));
        when(productClient.getAllProducts(anyInt(), anyInt(), any(), anyList(), any(), any(), any(), any())).thenReturn(new PageResponse<>("OK", 200, Collections.emptyList(), new Page(0, 0, 0)));

        var result = customerService.getCustomersWithProducts(TestUtils.DOCUMENT_TYPE, DOCUMENT_NUMBER, REQUEST_ID, CORRELATION_ID, CLIENT_VERSION_ID, 1, DEFAULT_PAGE_SIZE, JWT_TOKEN);

        assertNotNull(result);
        assertEquals(1, result.data().size());
        assertEquals(0, result.data().get(0).getLines().size());
    }

    @Test
    void getCustomersWithProductsShouldReturnCustomersWithProducts() {
        var customer = new CustomerDto();
        customer.setId("1");
        var product = new ProductDto();
        product.setCustomerId("1");
        var line = new LineDto();
        product.setLine(line);

        when(customerClient.getCustomerByDocument(any(), any(), any(), any(), any(), any())).thenReturn(new Response<>("OK", 200, List.of(customer)));
        when(productClient.getAllProducts(anyInt(), anyInt(), any(), anyList(), any(), any(), any(), any())).thenReturn(new PageResponse<>("OK", 200, List.of(product), new Page(1, 1, 1)));

        var result = customerService.getCustomersWithProducts(TestUtils.DOCUMENT_TYPE, DOCUMENT_NUMBER, REQUEST_ID, CORRELATION_ID, CLIENT_VERSION_ID, 1, DEFAULT_PAGE_SIZE, JWT_TOKEN);

        assertNotNull(result);
        assertEquals(1, result.data().size());
        assertEquals(1, result.data().getFirst().getLines().size());
    }

    @Test
    void getCustomersWithProductsShouldHandleNullCustomerResponse() {

        when(customerClient.getCustomerByDocument(any(), any(), any(), any(), any(), any())).thenReturn(null);

        var result = customerService.getCustomersWithProducts(TestUtils.DOCUMENT_TYPE, DOCUMENT_NUMBER, REQUEST_ID, CORRELATION_ID, CLIENT_VERSION_ID, 1, DEFAULT_PAGE_SIZE, JWT_TOKEN);

        assertNotNull(result);
        assertEquals(0, result.data().size());
    }

    @Test
    void getCustomersWithProductsShouldHandleNullProductResponse() {

        var customer = new CustomerDto();
        customer.setId("1");
        when(customerClient.getCustomerByDocument(any(), any(), any(), any(), any(), any())).thenReturn(new Response<>("OK", 200, List.of(customer)));
        when(productClient.getAllProducts(anyInt(), anyInt(), any(), anyList(), any(), any(), any(), any())).thenReturn(null);

        var result = customerService.getCustomersWithProducts(TestUtils.DOCUMENT_TYPE, DOCUMENT_NUMBER, REQUEST_ID, CORRELATION_ID, CLIENT_VERSION_ID, 1, DEFAULT_PAGE_SIZE, JWT_TOKEN);

        assertNotNull(result);
        assertEquals(1, result.data().size());
        assertEquals(0, result.data().getFirst().getLines().size());
    }
}