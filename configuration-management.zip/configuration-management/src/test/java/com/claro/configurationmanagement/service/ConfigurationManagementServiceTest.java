package com.claro.configurationmanagement.service;

import com.claro.configurationmanagement.exception.ConfigurationManagementException;
import com.claro.configurationmanagement.model.projection.EquivalenceView;
import com.claro.configurationmanagement.repository.DocumentTypeEquivalenceRepository;
import com.claro.configurationmanagement.service.impl.ConfigurationManagementServiceImpl;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.util.Optional;

import static com.claro.configurationmanagement.utils.TestUtils.ABBREVIATION;
import static com.claro.configurationmanagement.utils.TestUtils.APP;
import static com.claro.configurationmanagement.utils.TestUtils.CRM_DOC_TYPE_CODE;
import static com.claro.configurationmanagement.utils.TestUtils.DESCRIPTION;
import static com.claro.configurationmanagement.utils.TestUtils.LEGACY_APP_NAME;
import static com.claro.configurationmanagement.utils.TestUtils.LEGACY_DOC_TYPE_CODE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ConfigurationManagementServiceTest {

    @Mock
    private DocumentTypeEquivalenceRepository documentTypeEquivalenceRepository;

    @Mock
    private EquivalenceView equivalenceView;
    @InjectMocks
    private ConfigurationManagementServiceImpl service;

    @Test
    @DisplayName("getDocumentTypeEquivalence returns equivalence")
    void whenGetDocumentTypeEquivalenceFound() {
        when(equivalenceView.getLegacyDocTypeCode()).thenReturn(LEGACY_DOC_TYPE_CODE);
        when(equivalenceView.getCrmDocTypeCode()).thenReturn(CRM_DOC_TYPE_CODE);
        when(equivalenceView.getDescription()).thenReturn(DESCRIPTION);
        when(equivalenceView.getAbbreviation()).thenReturn(ABBREVIATION);
        when(equivalenceView.getLegacyAppName()).thenReturn(LEGACY_APP_NAME);
        when(documentTypeEquivalenceRepository.findEquivalenceByAbbreviationAndApp(ABBREVIATION, APP)).thenReturn(Optional.of(equivalenceView));

        var response = service.getDocumentTypeEquivalence(ABBREVIATION, APP);
        assertEquals(HttpStatus.OK.value(), response.code());
    }

    @Test
    @DisplayName("getDocumentTypeEquivalence not found")
    void whenGetDocumentTypeEquivalenceNotFound() {
        when(documentTypeEquivalenceRepository.findEquivalenceByAbbreviationAndApp(ABBREVIATION, APP)).thenReturn(Optional.empty());
        assertThrows(ConfigurationManagementException.class, () -> {
            service.getDocumentTypeEquivalence(ABBREVIATION, APP);
        });
    }

}
