package com.claro.configurationmanagement.service;

import com.claro.configurationmanagement.exception.ConfigurationManagementException;
import com.claro.configurationmanagement.model.projection.EquivalenceView;
import com.claro.configurationmanagement.repository.DocumentTypeEquivalenceRepository;
import com.claro.configurationmanagement.service.impl.ConfigurationManagementServiceImpl;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.util.Collections;
import java.util.Optional;

import static com.claro.configurationmanagement.utils.TestUtils.ABBREVIATION;
import static com.claro.configurationmanagement.utils.TestUtils.APP;
import static com.claro.configurationmanagement.utils.TestUtils.CRM_DOC_TYPE_CODE;
import static com.claro.configurationmanagement.utils.TestUtils.DESCRIPTION;
import static com.claro.configurationmanagement.utils.TestUtils.LEGACY_APP_NAME;
import static com.claro.configurationmanagement.utils.TestUtils.LEGACY_DOC_TYPE_CODE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ConfigurationManagementServiceTest {

    @Mock
    private DocumentTypeEquivalenceRepository documentTypeEquivalenceRepository;

    @Mock
    private EquivalenceView equivalenceView;
    @InjectMocks
    private ConfigurationManagementServiceImpl service;

    @Test
    @DisplayName("getDocumentTypeEquivalence returns equivalence")
    void whenGetDocumentTypeEquivalenceFound() {
        when(this.equivalenceView.getLegacyDocTypeCode()).thenReturn(LEGACY_DOC_TYPE_CODE);
        when(this.equivalenceView.getCrmDocTypeCode()).thenReturn(CRM_DOC_TYPE_CODE);
        when(this.equivalenceView.getDescription()).thenReturn(DESCRIPTION);
        when(this.equivalenceView.getAbbreviation()).thenReturn(ABBREVIATION);
        when(this.equivalenceView.getLegacyAppName()).thenReturn(LEGACY_APP_NAME);

        var singleton = Optional.of(Collections.singletonList(this.equivalenceView));

        when(this.documentTypeEquivalenceRepository.findEquivalenceByAbbreviationAndApp(ABBREVIATION, APP)).thenReturn(singleton);

        var response = this.service.getDocumentTypeEquivalence(ABBREVIATION, APP);
        assertEquals(HttpStatus.OK.value(), response.code());
    }

    @Test
    @DisplayName("getDocumentTypeEquivalence not found")
    void whenGetDocumentTypeEquivalenceNotFound() {
        when(this.documentTypeEquivalenceRepository.findEquivalenceByAbbreviationAndApp(ABBREVIATION, APP)).thenReturn(Optional.empty());
        assertThrows(ConfigurationManagementException.class, () -> {
            this.service.getDocumentTypeEquivalence(ABBREVIATION, APP);
        });
    }

    @Test
    @DisplayName("getDocumentTypeEquivalence not found with empty list")
    void whenGetDocumentTypeEquivalenceNotFoundWithEmptyList() {
        when(this.documentTypeEquivalenceRepository.findEquivalenceByAbbreviationAndApp(ABBREVIATION, APP)).thenReturn(Optional.of(Collections.emptyList()));
        assertThrows(ConfigurationManagementException.class, () -> this.service.getDocumentTypeEquivalence(ABBREVIATION, APP));
    }

    @Test
    @DisplayName("getDocumentTypeEquivalence with only abbreviation returns equivalence")
    void whenGetDocumentTypeEquivalenceWithOnlyAbbreviationFound() {
        when(this.equivalenceView.getLegacyDocTypeCode()).thenReturn(LEGACY_DOC_TYPE_CODE);
        when(this.equivalenceView.getCrmDocTypeCode()).thenReturn(CRM_DOC_TYPE_CODE);
        when(this.equivalenceView.getDescription()).thenReturn(DESCRIPTION);
        when(this.equivalenceView.getAbbreviation()).thenReturn(ABBREVIATION);
        when(this.equivalenceView.getLegacyAppName()).thenReturn(LEGACY_APP_NAME);

        var singleton = Optional.of(Collections.singletonList(this.equivalenceView));

        when(this.documentTypeEquivalenceRepository.findEquivalenceByAbbreviation(ABBREVIATION, null)).thenReturn(singleton);

        var response = this.service.getDocumentTypeEquivalence(ABBREVIATION, null);
        assertEquals(HttpStatus.OK.value(), response.code());
    }

    @Test
    @DisplayName("getDocumentTypeEquivalence with only abbreviation not found")
    void whenGetDocumentTypeEquivalenceWithOnlyAbbreviationNotFound() {
        when(this.documentTypeEquivalenceRepository.findEquivalenceByAbbreviation(ABBREVIATION, null)).thenReturn(Optional.empty());
        assertThrows(ConfigurationManagementException.class, () -> this.service.getDocumentTypeEquivalence(ABBREVIATION, null));
    }

    @Test
    @DisplayName("getDocumentTypeEquivalence with only abbreviation not found with empty list")
    void whenGetDocumentTypeEquivalenceWithOnlyAbbreviationNotFoundWithEmptyList() {
        when(this.documentTypeEquivalenceRepository.findEquivalenceByAbbreviation(ABBREVIATION, null)).thenReturn(Optional.of(Collections.emptyList()));
        assertThrows(ConfigurationManagementException.class, () -> this.service.getDocumentTypeEquivalence(ABBREVIATION, null));
    }

    @Test
    @DisplayName("getDocumentTypeEquivalence with only app returns equivalence")
    void whenGetDocumentTypeEquivalenceWithOnlyAppFound() {
        when(this.equivalenceView.getLegacyDocTypeCode()).thenReturn(LEGACY_DOC_TYPE_CODE);
        when(this.equivalenceView.getCrmDocTypeCode()).thenReturn(CRM_DOC_TYPE_CODE);
        when(this.equivalenceView.getDescription()).thenReturn(DESCRIPTION);
        when(this.equivalenceView.getAbbreviation()).thenReturn(ABBREVIATION);
        when(this.equivalenceView.getLegacyAppName()).thenReturn(LEGACY_APP_NAME);

        var singleton = Optional.of(Collections.singletonList(this.equivalenceView));

        when(this.documentTypeEquivalenceRepository.findEquivalenceByApp(null, APP)).thenReturn(singleton);

        var response = this.service.getDocumentTypeEquivalence(null, APP);
        assertEquals(HttpStatus.OK.value(), response.code());
    }

    @Test
    @DisplayName("getDocumentTypeEquivalence with only app not found")
    void whenGetDocumentTypeEquivalenceWithOnlyAppNotFound() {
        when(this.documentTypeEquivalenceRepository.findEquivalenceByApp(null, APP)).thenReturn(Optional.empty());
        assertThrows(ConfigurationManagementException.class, () -> this.service.getDocumentTypeEquivalence(null, APP));
    }

    @Test
    @DisplayName("getDocumentTypeEquivalence with only app not found with empty list")
    void whenGetDocumentTypeEquivalenceWithOnlyAppNotFoundWithEmptyList() {
        when(this.documentTypeEquivalenceRepository.findEquivalenceByApp(null, APP)).thenReturn(Optional.of(Collections.emptyList()));
        assertThrows(ConfigurationManagementException.class, () -> this.service.getDocumentTypeEquivalence(null, APP));
    }

    @Test
    @DisplayName("getDocumentTypeEquivalence with no params throws bad request")
    void whenGetDocumentTypeEquivalenceWithNoParams() {
        assertThrows(ConfigurationManagementException.class, () -> this.service.getDocumentTypeEquivalence(null, null));
    }
}
