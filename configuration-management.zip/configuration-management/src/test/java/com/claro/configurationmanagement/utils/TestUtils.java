package com.claro.configurationmanagement.utils;

public class TestUtils {
    public static final String ABBREVIATION = "DNI";
    public static final String APP = "PVU";
    public static final String LEGACY_DOC_TYPE_CODE = "01";
    public static final String CRM_DOC_TYPE_CODE = "DNI";
    public static final String DESCRIPTION = "DOCUMENTO NACIONAL DE IDENTIDAD";
    public static final String LEGACY_APP_NAME = "PVU";
    public static final int DEFAULT_TIME_MILLISECONDS = 10000;


}
