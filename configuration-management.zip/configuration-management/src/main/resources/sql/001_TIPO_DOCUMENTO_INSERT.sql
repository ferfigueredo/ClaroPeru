﻿insert into TIPO_DOCUMENTO (id_tipodocumento, descripcion_td, abreviatura_td, estado_td, fecha_creacion, usuario_creacion, fecha_modificacion, usuario_modifico)
values (1, 'DOCUMENTO NACIONAL DE IDENTIDAD', 'DNI', 'A', to_date('19-07-2024 18:41:08', 'dd-mm-yyyy hh24:mi:ss'), 'CRM', null, null);
insert into TIPO_DOCUMENTO (id_tipodocumento, descripcion_td, abreviatura_td, estado_td, fecha_creacion, usuario_creacion, fecha_modificacion, usuario_modifico)
values (2, 'CARNET DE EXTRANJERÍA', 'CE', 'A', to_date('19-07-2024 18:41:08', 'dd-mm-yyyy hh24:mi:ss'), 'CRM', null, null);
insert into TIPO_DOCUMENTO (id_tipodocumento, descripcion_td, abreviatura_td, estado_td, fecha_creacion, usuario_creacion, fecha_modificacion, usuario_modifico)
values (3, 'CIP', 'CIP', 'A', to_date('19-07-2024 18:41:08', 'dd-mm-yyyy hh24:mi:ss'), 'CRM', null, null);
insert into TIPO_DOCUMENTO (id_tipodocumento, descripcion_td, abreviatura_td, estado_td, fecha_creacion, usuario_creacion, fecha_modificacion, usuario_modifico)
values (4, 'REGISTRO ÚNICO DEL CONTRIBUYENTE', 'RUC', 'A', to_date('19-07-2024 18:41:08', 'dd-mm-yyyy hh24:mi:ss'), 'CRM', null, null);
insert into TIPO_DOCUMENTO (id_tipodocumento, descripcion_td, abreviatura_td, estado_td, fecha_creacion, usuario_creacion, fecha_modificacion, usuario_modifico)
values (5, 'PASAPORTE', 'PASAPORTE', 'A', to_date('19-07-2024 18:41:08', 'dd-mm-yyyy hh24:mi:ss'), 'CRM', null, null);
insert into TIPO_DOCUMENTO (id_tipodocumento, descripcion_td, abreviatura_td, estado_td, fecha_creacion, usuario_creacion, fecha_modificacion, usuario_modifico)
values (6, 'CARNET IDENTIDAD EMITIDO POR RELACIONES EXTERIORES', 'CIRE', 'A', to_date('19-07-2024 18:41:08', 'dd-mm-yyyy hh24:mi:ss'), 'CRM', null, null);
insert into TIPO_DOCUMENTO (id_tipodocumento, descripcion_td, abreviatura_td, estado_td, fecha_creacion, usuario_creacion, fecha_modificacion, usuario_modifico)
values (7, 'DOCUMENTO DE IDENTIDAD EXTRANJERO', 'CIE', 'A', to_date('19-07-2024 18:41:08', 'dd-mm-yyyy hh24:mi:ss'), 'CRM', null, null);
insert into TIPO_DOCUMENTO (id_tipodocumento, descripcion_td, abreviatura_td, estado_td, fecha_creacion, usuario_creacion, fecha_modificacion, usuario_modifico)
values (8, 'CARNET TEMPORAL DE PERMANENCIA', 'CPP', 'A', to_date('19-07-2024 18:41:08', 'dd-mm-yyyy hh24:mi:ss'), 'CRM', null, null);
insert into TIPO_DOCUMENTO (id_tipodocumento, descripcion_td, abreviatura_td, estado_td, fecha_creacion, usuario_creacion, fecha_modificacion, usuario_modifico)
values (9, 'CARNET TEMPORAL MIGRATORIO', 'CTM', 'A', to_date('19-07-2024 18:41:08', 'dd-mm-yyyy hh24:mi:ss'), 'CRM', null, null);
commit;
