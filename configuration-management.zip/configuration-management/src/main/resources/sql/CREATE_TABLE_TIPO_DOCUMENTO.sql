﻿create table TIPO_DOCUMENTO
(
  id_tipodocumento   NUMBER not null,
  descripcion_td     VARCHAR2(100),
  abreviatura_td     VARCHAR2(20),
  estado_td          VARCHAR2(1),
  fecha_creacion     DATE default SYSDATE not null,
  usuario_creacion   VARCHAR2(20) default USER not null,
  fecha_modificacion DATE,
  usuario_modifico   VARCHAR2(20)
);
