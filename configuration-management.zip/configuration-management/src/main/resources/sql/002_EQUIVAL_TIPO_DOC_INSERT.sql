﻿insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (30, 'EAIATENCIONES', '2', 1, 'CRM', to_date('12-11-2025 09:04:31', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (31, 'EAIATENCIONES', '4', 2, 'CRM', to_date('12-11-2025 09:04:31', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (32, 'EAIATENCIONES', '6', 4, 'CRM', to_date('12-11-2025 09:04:31', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (33, 'SGA', '002', 1, 'CRM', to_date('12-11-2025 09:04:31', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (20, 'CLIENTE_UNICO', '2', 1, 'CRM', to_date('12-11-2025 08:52:43', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (21, 'CLIENTE_UNICO', '4', 2, 'CRM', to_date('12-11-2025 08:52:43', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (22, 'CLIENTE_UNICO', '5', 3, 'CRM', to_date('12-11-2025 08:52:43', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (23, 'CLIENTE_UNICO', '6', 4, 'CRM', to_date('12-11-2025 08:52:43', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (24, 'CLIENTE_UNICO', '1', 5, 'CRM', to_date('12-11-2025 08:52:43', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (25, 'CLIENTE_UNICO', '8', 6, 'CRM', to_date('12-11-2025 08:52:43', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (26, 'CLIENTE_UNICO', '7', 7, 'CRM', to_date('12-11-2025 08:52:43', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (27, 'CLIENTE_UNICO', '9', 8, 'CRM', to_date('12-11-2025 08:52:43', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (28, 'CLIENTE_UNICO', '10', 9, 'CRM', to_date('12-11-2025 08:52:43', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (29, 'EAIATENCIONES', '1', 5, 'CRM', to_date('12-11-2025 09:04:31', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (1, 'PVU', '01', 1, 'CRM', to_date('19-07-2024 18:41:21', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (2, 'PVU', '02', 3, 'CRM', to_date('19-07-2024 18:41:21', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (3, 'PVU', '14', 9, 'CRM', to_date('19-07-2024 18:41:21', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (4, 'PVU', '06', 4, 'CRM', to_date('19-07-2024 18:41:21', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (5, 'PVU', '07', 5, 'CRM', to_date('19-07-2024 18:41:21', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (6, 'PVU', '08', 1, 'CRM', to_date('19-07-2024 18:41:21', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (7, 'PVU', '09', 1, 'CRM', to_date('19-07-2024 18:41:21', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (8, 'PVU', '11', 6, 'CRM', to_date('19-07-2024 18:41:21', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (9, 'PVU', '12', 7, 'CRM', to_date('19-07-2024 18:41:22', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (10, 'PVU', '13', 8, 'CRM', to_date('19-07-2024 18:41:22', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (11, 'PVU', '04', 2, 'CRM', to_date('19-07-2024 18:41:22', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (12, 'TIMPROD', 'DNI', 1, 'CRM', to_date('19-07-2024 18:41:22', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (13, 'TIMPROD', 'RUC', 4, 'CRM', to_date('19-07-2024 18:41:22', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (14, 'TIMPROD', 'CIE', 7, 'CRM', to_date('19-07-2024 18:41:22', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (15, 'TIMPROD', 'CE', 2, 'CRM', to_date('19-07-2024 18:41:23', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (16, 'TIMPROD', 'CARNET EXTRANJERÍA', 2, 'CRM', to_date('19-07-2024 18:41:24', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (17, 'TIMPROD', 'PASAPORTE', 5, 'CRM', to_date('19-07-2024 18:41:24', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (18, 'TIMPROD', 'CPP', 8, 'CRM', to_date('19-07-2024 18:41:24', 'dd-mm-yyyy hh24:mi:ss'), null, null);
insert into EQUIVAL_TIPO_DOC (id_registro, aplicacion, tipo_doc_leg, tipo_documento_crm, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion)
values (19, 'TIMPROD', 'CIRE', 6, 'CRM', to_date('19-07-2024 18:41:24', 'dd-mm-yyyy hh24:mi:ss'), null, null);
commit;
