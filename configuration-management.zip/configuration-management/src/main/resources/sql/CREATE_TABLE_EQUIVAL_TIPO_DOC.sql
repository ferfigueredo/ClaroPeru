﻿create table EQUIVAL_TIPO_DOC
(
  id_registro          NUMBER not null,
  aplicacion           VARCHAR2(30) not null,
  tipo_doc_leg         VARCHAR2(50) not null,
  tipo_documento_crm   NUMBER not null,
  usuario_creacion     VARCHAR2(20) default USER not null,
  fecha_creacion       DATE default SYSDATE not null,
  usuario_modificacion VARCHAR2(20),
  fecha_modificacion   DATE
);
