package com.claro.configurationmanagement.repository;

import com.claro.configurationmanagement.model.entity.DocumentTypeEquivalenceEntity;
import com.claro.configurationmanagement.model.projection.EquivalenceView;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

import static com.claro.configurationmanagement.utils.ConstantUtils.APP_EQUIVALENCE_QUERY;
import static com.claro.configurationmanagement.utils.ConstantUtils.DOCUMENT_TYPE_AND_APP_EQUIVALENCE_QUERY;
import static com.claro.configurationmanagement.utils.ConstantUtils.DOCUMENT_TYPE_EQUIVALENCE_QUERY;

@Repository
public interface DocumentTypeEquivalenceRepository extends JpaRepository<DocumentTypeEquivalenceEntity, Long> {
    /**
     * Finds the document type equivalence based on the provided abbreviation and application.
     *
     * @param abbreviation the abbreviation of the document type
     * @param app          the application associated with the document type
     * @return an Optional containing the EquivalenceView if found, otherwise empty
     */
    @Query(value = DOCUMENT_TYPE_AND_APP_EQUIVALENCE_QUERY, nativeQuery = true)
    Optional<List<EquivalenceView>> findEquivalenceByAbbreviationAndApp(@Param("abbreviation") String abbreviation, @Param("app") String app);

    @Query(value = DOCUMENT_TYPE_EQUIVALENCE_QUERY, nativeQuery = true)
    Optional<List<EquivalenceView>> findEquivalenceByAbbreviation(@Param("abbreviation") String abbreviation, @Param("app") String app);

    @Query(value = APP_EQUIVALENCE_QUERY, nativeQuery = true)
    Optional<List<EquivalenceView>> findEquivalenceByApp(@Param("abbreviation") String abbreviation, @Param("app") String app);
}
