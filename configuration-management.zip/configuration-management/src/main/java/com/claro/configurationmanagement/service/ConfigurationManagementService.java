package com.claro.configurationmanagement.service;


import com.claro.common.claro.dto.response.Response;
import com.claro.configurationmanagement.model.dto.response.DocumentTypeEquivalenceResponse;
import org.springframework.cache.annotation.Cacheable;


public interface ConfigurationManagementService {
    /**
     * Retrieves the document type equivalence based on the provided abbreviation and application.
     *
     * @param abbreviation the abbreviation of the document type
     * @param app          the application associated with the document type
     * @return a Response containing the DocumentTypeEquivalenceResponse
     */
    @Cacheable(value = "document-type-equivalence", key = "#abbreviation +'-'+ #app")
    Response<DocumentTypeEquivalenceResponse> getDocumentTypeEquivalence(String abbreviation, String app);
}
