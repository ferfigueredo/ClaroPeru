package com.claro.configurationmanagement.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Setter
@Getter
@Builder
@Entity
@Table(name = "TIPO_DOCUMENTO")
@AllArgsConstructor
@NoArgsConstructor
public class DocumentTypeEntity {
    @Id
    @Column(name = "ID_TIPODOCUMENTO")
    private Long id;

    @Column(name = "DESCRIPCION_TD")
    private String description;

    @Column(name = "ABREVIATURA_TD")
    private String abbreviation;

    @Column(name = "ESTADO_TD")
    private String status;

    @Column(name = "FECHA_CREACION")
    private Date createdAt;

    @Column(name = "USUARIO_CREACION")
    private String createdBy;

    @Column(name = "FECHA_MODIFICACION")
    private Date modifiedAt;

    @Column(name = "USUARIO_MODIFICO")
    private String modifiedBy;
}
