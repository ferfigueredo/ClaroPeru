package com.claro.configurationmanagement.filter;

import com.claro.configurationmanagement.service.JwtValidatorService;
import io.jsonwebtoken.Claims;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;


/**
 * Filtro que intercepta todas las peticiones para validar el token JWT.
 * Extiende de OncePerRequestFilter para asegurar que se ejecuta solo una vez por petición.
 */
@Component
public class JwtRequestFilter extends OncePerRequestFilter {

    public static final String AUTHORIZATION_HEADER = "Authorization";
    public static final String BEARER_PREFIX = "Bearer ";

    // UserDetailsService es la interfaz estándar de Spring Security
    // para cargar los detalles del usuario (roles, permisos, etc.)
    //@Autowired
    //private UserDetailsService userDetailsService; // Deberás implementar esta interfaz
    private static final Logger F_LOGGER = LoggerFactory.getLogger(JwtRequestFilter.class);
    @Autowired
    private JwtValidatorService jwtValidatorService;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {
        try {
            String jwt = extractJwtFromRequest(request);

            if (StringUtils.hasText(jwt) && jwtValidatorService.validateToken(jwt)) {

                // 1. Obtener TODOS los claims del token
                Claims claims = jwtValidatorService.getClaimsFromToken(jwt);

                // 2. Extraer el username (subject)
                String username = claims.getSubject();

                // 3. ¡EXTRAER LOS ROLES DEL TOKEN!
                // Asume que el claim se llama "roles" y es una Lista de Strings
                @SuppressWarnings("unchecked")
                List<String> roles = claims.get("roles", List.class);

                Collection<GrantedAuthority> authorities = roles.stream()
                        .map(SimpleGrantedAuthority::new) // Convierte "ROLE_ADMIN" a objeto GrantedAuthority
                        .collect(Collectors.toList());

                // 4. Cargar los detalles del usuario (opcional, si solo necesitas el username)
                // UserDetails userDetails = userDetailsService.loadUserByUsername(username); // <-- YA NO HACEMOS ESTO

                // 5. Crear la "Autenticación" usando los roles DEL TOKEN
                UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
                        username, // El Principal ahora es solo el string del username
                        null,
                        authorities // ¡Usamos las autoridades del token!
                );

                authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                // 6. Establecer el usuario autenticado en el Contexto de Seguridad
                SecurityContextHolder.getContext().setAuthentication(authentication);
            }
        } catch (Exception e) {
            F_LOGGER.error("No se pudo establecer la autenticación del usuario: {}", e.getMessage());
        }

        filterChain.doFilter(request, response);
    }

    /**
     * Helper para extraer el token del "Authorization Header".
     */
    private String extractJwtFromRequest(HttpServletRequest request) {
        String bearerToken = request.getHeader(AUTHORIZATION_HEADER);
        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith(BEARER_PREFIX)) {
            return bearerToken.substring(BEARER_PREFIX.length());
        }
        return null;
    }
}
