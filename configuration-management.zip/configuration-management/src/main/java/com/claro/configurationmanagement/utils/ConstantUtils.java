package com.claro.configurationmanagement.utils;

public class ConstantUtils {
    public static final String DOCUMENT_TYPE_AND_APP_EQUIVALENCE_QUERY =
            "SELECT edp.TIPO_DOC_LEG AS legacyDocTypeCode, "
                    + "edp.TIPO_DOCUMENTO_CRM AS crmDocTypeCode, "
                    + "td.DESCRIPCION_TD AS description, "
                    + "td.ABREVIATURA_TD AS abbreviation, "
                    + "edp.APLICACION AS legacyAppName "
                    + "FROM TIPO_DOCUMENTO TD "
                    + "INNER JOIN EQUIVAL_TIPO_DOC edp "
                    + "ON td.ID_TIPODOCUMENTO = edp.TIPO_DOCUMENTO_CRM "
                    + "WHERE td.ABREVIATURA_TD = :abbreviation "
                    + "AND edp.APLICACION = :app";


    public static final String DOCUMENT_TYPE_EQUIVALENCE_QUERY =
            "SELECT edp.TIPO_DOC_LEG AS legacyDocTypeCode, "
                    + "edp.TIPO_DOCUMENTO_CRM AS crmDocTypeCode, "
                    + "td.DESCRIPCION_TD AS description, "
                    + "td.ABREVIATURA_TD AS abbreviation, "
                    + "edp.APLICACION AS legacyAppName "
                    + "FROM TIPO_DOCUMENTO TD "
                    + "INNER JOIN EQUIVAL_TIPO_DOC edp "
                    + "ON td.ID_TIPODOCUMENTO = edp.TIPO_DOCUMENTO_CRM "
                    + "WHERE td.ABREVIATURA_TD = :abbreviation ";

    public static final String APP_EQUIVALENCE_QUERY =
            "SELECT edp.TIPO_DOC_LEG AS legacyDocTypeCode, "
                    + "edp.TIPO_DOCUMENTO_CRM AS crmDocTypeCode, "
                    + "td.DESCRIPCION_TD AS description, "
                    + "td.ABREVIATURA_TD AS abbreviation, "
                    + "edp.APLICACION AS legacyAppName "
                    + "FROM TIPO_DOCUMENTO TD "
                    + "INNER JOIN EQUIVAL_TIPO_DOC edp "
                    + "ON td.ID_TIPODOCUMENTO = edp.TIPO_DOCUMENTO_CRM "
                    + "WHERE edp.APLICACION = :app";

}
