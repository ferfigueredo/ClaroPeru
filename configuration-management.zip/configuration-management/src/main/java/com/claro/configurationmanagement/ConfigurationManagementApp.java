package com.claro.configurationmanagement;

import com.claro.common.commonlogger.scan.EnableClaroCommonLoggerComponentScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableClaroCommonLoggerComponentScan
@EnableCaching
public class ConfigurationManagementApp extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(ConfigurationManagementApp.class, args);
    }
}
