package com.claro.configurationmanagement.model.projection;

public interface EquivalenceView {
    String getLegacyDocTypeCode();

    String getCrmDocTypeCode();

    String getDescription();

    String getAbbreviation();

    String getLegacyAppName();
}
