package com.claro.configurationmanagement.controller.impl;

import com.claro.common.claro.dto.response.Response;
import com.claro.configurationmanagement.controller.ConfigurationManagementController;
import com.claro.configurationmanagement.model.dto.response.DocumentTypeEquivalenceResponse;
import com.claro.configurationmanagement.service.ConfigurationManagementService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;


@Slf4j
@RestController
@Tag(name = "ConfigurationManagement", description = "Get document type equivalence")
@RequiredArgsConstructor
public class ConfigurationManagementControllerImpl implements ConfigurationManagementController {

    private final ConfigurationManagementService service;

    /**
     * See {@link ConfigurationManagementController#getDocumentTypeEquivalence(String, String, String, String, String, String)}
     */
    @Override
    public ResponseEntity<Response<DocumentTypeEquivalenceResponse>> getDocumentTypeEquivalence(
            String abbreviation,
            String app,
            String authorization,
            String xRequestId,
            String xCorrelationId,
            String xClientVersionId) {
        return new ResponseEntity<>(service.getDocumentTypeEquivalence(abbreviation, app), HttpStatus.OK);
    }

}
