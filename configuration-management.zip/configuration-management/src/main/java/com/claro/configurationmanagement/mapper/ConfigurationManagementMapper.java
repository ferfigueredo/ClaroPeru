package com.claro.configurationmanagement.mapper;

import com.claro.configurationmanagement.model.dto.response.DocumentTypeEquivalenceResponse;
import com.claro.configurationmanagement.model.projection.EquivalenceView;

public class ConfigurationManagementMapper {
    public static DocumentTypeEquivalenceResponse toDocumentTypeEquivalenceResponse(EquivalenceView entity) {
        return DocumentTypeEquivalenceResponse.builder()
                .legacyDocTypeCode(entity.getLegacyDocTypeCode())
                .crmDocTypeCode(entity.getCrmDocTypeCode())
                .description(entity.getDescription())
                .abbreviation(entity.getAbbreviation())
                .legacyAppName(entity.getLegacyAppName())
                .build();
    }
}
