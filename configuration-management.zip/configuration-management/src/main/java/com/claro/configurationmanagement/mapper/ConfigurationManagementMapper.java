package com.claro.configurationmanagement.mapper;

import com.claro.configurationmanagement.model.dto.response.DocumentTypeEquivalenceResponse;
import com.claro.configurationmanagement.model.projection.EquivalenceView;

import java.util.List;
import java.util.stream.Collectors;

public class ConfigurationManagementMapper {
    public static List<DocumentTypeEquivalenceResponse> toDocumentTypeEquivalenceResponse(List<EquivalenceView> entities) {
        return entities.stream().map(entity -> DocumentTypeEquivalenceResponse.builder()
                .legacyDocTypeCode(entity.getLegacyDocTypeCode())
                .crmDocTypeCode(entity.getCrmDocTypeCode())
                .description(entity.getDescription())
                .abbreviation(entity.getAbbreviation())
                .legacyAppName(entity.getLegacyAppName())
                .build()).collect(Collectors.toList());
    }
}
