package com.claro.configurationmanagement.service.impl;

import com.claro.common.claro.dto.response.Response;
import com.claro.common.claro.exceptions.dto.ErrorDTO;
import com.claro.configurationmanagement.exception.ConfigurationManagementException;
import com.claro.configurationmanagement.model.dto.response.DocumentTypeEquivalenceResponse;
import com.claro.configurationmanagement.model.projection.EquivalenceView;
import com.claro.configurationmanagement.repository.DocumentTypeEquivalenceRepository;
import com.claro.configurationmanagement.service.ConfigurationManagementService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

import static com.claro.configurationmanagement.exception.ConfigurationManagementExceptionHandler.SERVICE_ERROR;
import static com.claro.configurationmanagement.mapper.ConfigurationManagementMapper.toDocumentTypeEquivalenceResponse;

@Slf4j
@Service
@RequiredArgsConstructor
public class ConfigurationManagementServiceImpl implements ConfigurationManagementService {

    private final DocumentTypeEquivalenceRepository documentTypeEquivalenceRepository;

    /**
     * See {@link ConfigurationManagementService#getDocumentTypeEquivalence(String, String)}
     */
    @Override
    public Response<List<DocumentTypeEquivalenceResponse>> getDocumentTypeEquivalence(String abbreviation, String app) {
        var optEquiv = getEquivalenceView(abbreviation, app);
        return new Response<>(HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.value(), toDocumentTypeEquivalenceResponse(optEquiv));
    }

    private List<EquivalenceView> getEquivalenceView(String abbreviation, String app) {
        log.info("::: getDocumentTypeEquivalence: abbreviation={}, app={} :::", abbreviation, app);

        if (StringUtils.hasText(abbreviation) && StringUtils.hasText(app)) {
            return this.documentTypeEquivalenceRepository.findEquivalenceByAbbreviationAndApp(abbreviation.toUpperCase(), app.toUpperCase())
                    .filter(list -> !list.isEmpty())
                    .orElseThrow(() -> {
                        log.error("::: Document type equivalence not found for abbreviation={} and app={} :::", abbreviation, app);
                        return new ConfigurationManagementException(
                                ErrorDTO.builder().code(HttpStatus.NOT_FOUND.value()).status(HttpStatus.NOT_FOUND.name())
                                        .message(SERVICE_ERROR).detail("DocumentType equivalence not found")
                                        .subType("IDF3").type("DocumentEquivalenceNotFoundException").build());
                    });
        } else if (StringUtils.hasText(abbreviation)) {
            return this.documentTypeEquivalenceRepository.findEquivalenceByAbbreviation(abbreviation.toUpperCase(), null)
                    .filter(list -> !list.isEmpty())
                    .orElseThrow(() -> {
                        log.error("::: Document type equivalence not found for abbreviation={} :::", abbreviation);
                        return new ConfigurationManagementException(
                                ErrorDTO.builder().code(HttpStatus.NOT_FOUND.value()).status(HttpStatus.NOT_FOUND.name())
                                        .message(SERVICE_ERROR).detail("DocumentType equivalence not found")
                                        .subType("IDF3").type("DocumentEquivalenceNotFoundException").build());
                    });
        } else if (StringUtils.hasText(app)) {
            return this.documentTypeEquivalenceRepository.findEquivalenceByApp(null, app.toUpperCase())
                    .filter(list -> !list.isEmpty())
                    .orElseThrow(() -> {
                        log.error("::: Document type equivalence not found for app={} :::", app);
                        return new ConfigurationManagementException(
                                ErrorDTO.builder().code(HttpStatus.NOT_FOUND.value()).status(HttpStatus.NOT_FOUND.name())
                                        .message(SERVICE_ERROR).detail("DocumentType equivalence not found").subType("IDF3")
                                        .type("DocumentEquivalenceNotFoundException").build());
                    });
        } else {
            log.error("::: Abbreviation and app are required :::");
            throw new ConfigurationManagementException(
                    ErrorDTO.builder().code(HttpStatus.BAD_REQUEST.value()).status(HttpStatus.BAD_REQUEST.name())
                            .message(SERVICE_ERROR).detail("Abbreviation and app are required")
                            .subType("IDF3").type("BadRequestException").build());
        }
    }
}
