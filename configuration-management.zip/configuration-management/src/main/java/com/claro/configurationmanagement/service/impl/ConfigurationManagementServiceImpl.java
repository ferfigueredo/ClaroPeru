package com.claro.configurationmanagement.service.impl;

import com.claro.common.claro.dto.response.Response;
import com.claro.common.claro.exceptions.dto.ErrorDTO;
import com.claro.configurationmanagement.exception.ConfigurationManagementException;
import com.claro.configurationmanagement.model.dto.response.DocumentTypeEquivalenceResponse;
import com.claro.configurationmanagement.model.projection.EquivalenceView;
import com.claro.configurationmanagement.repository.DocumentTypeEquivalenceRepository;
import com.claro.configurationmanagement.service.ConfigurationManagementService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import static com.claro.configurationmanagement.exception.ConfigurationManagementExceptionHandler.SERVICE_ERROR;
import static com.claro.configurationmanagement.mapper.ConfigurationManagementMapper.toDocumentTypeEquivalenceResponse;

@Slf4j
@Service
@RequiredArgsConstructor
public class ConfigurationManagementServiceImpl implements ConfigurationManagementService {

    private final DocumentTypeEquivalenceRepository documentTypeEquivalenceRepository;

    /**
     * See {@link ConfigurationManagementService#getDocumentTypeEquivalence(String, String)}
     */
    @Override
    public Response<DocumentTypeEquivalenceResponse> getDocumentTypeEquivalence(String abbreviation, String app) {
        var optEquiv = getEquivalenceView(abbreviation, app);
        return new Response<>(HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.value(), toDocumentTypeEquivalenceResponse(optEquiv));
    }

    private EquivalenceView getEquivalenceView(String abbreviation, String app) {
        log.info("::: getDocumentTypeEquivalence: abbreviation={}, app={} :::", abbreviation, app);
        var optEquiv = documentTypeEquivalenceRepository.findEquivalenceByAbbreviationAndApp(abbreviation, app).orElseThrow(() -> {
            log.error("::: Document type equivalence not found for abbreviation={} and app={} :::", abbreviation, app);
            throw new ConfigurationManagementException(
                    ErrorDTO.builder().code(HttpStatus.NOT_FOUND.value()).status(HttpStatus.NOT_FOUND.name()).message(SERVICE_ERROR).detail("DocumentType equivalence not found").subType("IDF3").type("DocumentEquivalenceNotFoundException").build());
        });
        log.info("::: Document type equivalence found :::");
        return optEquiv;
    }
}
