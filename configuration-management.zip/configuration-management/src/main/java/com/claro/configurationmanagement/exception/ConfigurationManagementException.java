package com.claro.configurationmanagement.exception;

import com.claro.common.claro.exceptions.dto.ErrorDTO;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import static com.claro.configurationmanagement.exception.ConfigurationManagementExceptionHandler.ERROR;
import static com.claro.configurationmanagement.exception.ConfigurationManagementExceptionHandler.SERVICE_ERROR;

@Getter
@Setter
public class ConfigurationManagementException extends RuntimeException {
    private final ErrorDTO errorDTO;

    public ConfigurationManagementException(ErrorDTO errorDTO) {
        super(errorDTO.getMessage());
        this.errorDTO = errorDTO;
    }

    public ConfigurationManagementException() {
        super("ConfigurationManagement Exception");
        this.errorDTO = ErrorDTO.builder().code(HttpStatus.INTERNAL_SERVER_ERROR.value()).detail("There is an internal problem").message(SERVICE_ERROR).status(HttpStatus.INTERNAL_SERVER_ERROR.name()).subType(ERROR).build();
    }
}
