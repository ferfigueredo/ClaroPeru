package com.claro.configurationmanagement.model.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class DocumentTypeEquivalenceResponse {
    private String legacyDocTypeCode;
    private String crmDocTypeCode;
    private String description;
    private String abbreviation;
    private String legacyAppName;
}
