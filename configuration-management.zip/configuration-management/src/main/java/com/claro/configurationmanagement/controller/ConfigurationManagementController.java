package com.claro.configurationmanagement.controller;

import com.claro.common.claro.dto.response.Response;
import com.claro.configurationmanagement.model.dto.response.DocumentTypeEquivalenceResponse;
import com.claro.configurationmanagement.model.dto.response.ErrorResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

public interface ConfigurationManagementController {
    /**
     * GET /configuration-management/api/v1/equivalence : Get document type equivalence
     * Get document type equivalence by abbreviation and legacy app name.
     *
     * @param abbreviation     Abbreviation of the document type to query. For example: DNI for National Identity Document.
     * @param app              Name of the legacy application associated with the document type. For example: PVU.
     * @param authorization    Bearer authentication token.
     * @param xRequestId       For logging and debugging security events.
     * @param xCorrelationId   For tracing security requests.
     * @param xClientVersionId For auditing and controlling client versions.
     * @return Document type equivalence retrieved successfully (status code 200)
     * or Bad request (status code 400)
     * or Unauthorized (status code 401)
     * or Resource not found (status code 404)
     * or Internal server error (status code 500)
     */
    @Operation(
            summary = "Get document type equivalence",
            description = "Get document type equivalence by abbreviation and legacy app name.",
            parameters = {@Parameter(name = "abbreviation", description = "Abbreviation of the document type to query. For example: DNI for National Identity Document.", example = "DNI", schema = @Schema(minLength = 1)),
                    @Parameter(name = "app", description = "Name of the legacy application associated with the document type. For example: PVU.", example = "PVU", schema = @Schema(minLength = 1)),
                    @Parameter(name = "Authorization",
                            description = "Bearer authentication token. Example: Bearer <JWT>",
                            required = true, example = "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwicm9sZXMiOlsiUk9MRV9VU0VSIiw"
                            + "iUk9MRV9BRE1JTiJdLCJuYW1lIjoiSm9obiBEb2UiLCJpYXQiOjE3NjE4MjcyMjMsImV4cCI6MTc2OTYwMzIyM30.JmP-zqe5MmN9YhDN6MdbCz6IVi07MdIpetAXOTtCNHs"),
                    @Parameter(name = "x-request-id",
                            description = "For logging and debugging security events.",
                            required = true,
                            example = "3a16264f-fcd4-4b41-8a5d-61509395642e"),
                    @Parameter(
                            name = "x-correlation-id",
                            description = "For tracing security requests.",
                            required = true,
                            example = "29db9cb2-f77a-478e-829f-3c6ba60acb76"),
                    @Parameter(name = "x-client-version-id",
                            description = "For auditing and controlling client versions.",
                            required = true,
                            example = "1.0.0")
            },
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = DocumentTypeEquivalenceResponse.class), examples = @ExampleObject(value = "{\n  \"code\": 200,\n  \"message\": \"Success\",\n  "
                                    + "\"data\": {\n    \"legacyDocTypeCode\": \"01\",\n    \"crmDocTypeCode\": \"1\",\n    \"description\": \"DOCUMENTO NACIONAL DE IDENTIDAD\",\n    "
                                    + "\"abbreviation\": \"DNI\",\n    \"legacyAppName\": \"PVU\"\n  }\n}"))),
                    @ApiResponse(
                            responseCode = "400",
                            description = "Bad request",
                            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
                    @ApiResponse(
                            responseCode = "401",
                            description = "Unauthorized",
                            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
                    @ApiResponse(
                            responseCode = "404",
                            description = "Resource not found",
                            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
                    @ApiResponse(
                            responseCode = "500",
                            description = "Internal server error",
                            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
            }
    )
    @GetMapping(value = "/configuration-management/api/v1/equivalence", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Response<List<DocumentTypeEquivalenceResponse>>> getDocumentTypeEquivalence(@RequestParam(name = "abbreviation", required = false) String abbreviation,
                                                                                              @RequestParam(name = "app", required = false) String app, @RequestHeader(name = "Authorization") String authorization,
                                                                                              @RequestHeader(name = "x-request-id") String xRequestId, @RequestHeader(name = "x-correlation-id") String xCorrelationId,
                                                                                              @RequestHeader(name = "x-client-version-id") String xClientVersionId);

}
