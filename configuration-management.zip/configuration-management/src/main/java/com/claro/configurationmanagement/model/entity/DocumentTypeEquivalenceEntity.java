package com.claro.configurationmanagement.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Setter
@Getter
@Builder
@Entity
@Table(name = "EQUIVAL_TIPO_DOC")
@AllArgsConstructor
@NoArgsConstructor
public class DocumentTypeEquivalenceEntity {
    @Id
    @Column(name = "ID_REGISTRO")
    private Long id;

    @Column(name = "APLICACION")
    private String application;

    @Column(name = "TIPO_DOC_LEG")
    private String legacyDocumentTypeCode;

    @Column(name = "TIPO_DOCUMENTO_CRM")
    private Long crmDocumentTypeCode;

    @Column(name = "USUARIO_CREACION")
    private String createdBy;

    @Column(name = "FECHA_CREACION")
    private Date createdAt;

    @Column(name = "USUARIO_MODIFICACION")
    private String modifiedBy;

    @Column(name = "FECHA_MODIFICACION")
    private Date modifiedAt;
}
