import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';

import { TableCustomer } from './table-customer';
import { Customer } from '../services/customer';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { provideZonelessChangeDetection } from '@angular/core';

describe('TableCustomer', () => {
  let component: TableCustomer;
  let fixture: ComponentFixture<TableCustomer>;

  // Mock del servicio Customer
  const mockCustomer = {
    getCustomers: () => of([
      {name: 'Hydrogen', typeID: 'RUC 1232123', lineNumber: '555-802-4693'},
      {name: 'Helium', typeID: '', lineNumber: '555-802-4693'},
      {name: 'Lithium', typeID: '', lineNumber: '555-802-4693'},
      {name: 'Beryllium', typeID: '', lineNumber: '555-802-4693'},
      {name: 'Boron', typeID: '', lineNumber: '555-802-4693'},
      {name: 'Carbon', typeID: '', lineNumber: '555-802-4693'},
      {name: 'Nitrogen', typeID: 'DNI 91827364', lineNumber: '555-802-4693'},
      {name: 'Oxygen', typeID: '', lineNumber: '555-802-4693'},
      {name: 'Fluorine', typeID: '', lineNumber: '555-802-4693'},
      {name: 'Neon', typeID: 'Pasaporte GG4668204', lineNumber: '555-802-4693'},
    ])
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TableCustomer, NoopAnimationsModule, FormsModule],
      providers: [
        { provide: Customer, useValue: mockCustomer },
        provideZonelessChangeDetection()
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TableCustomer);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should render all customer rows', async () => {
    await fixture.whenStable();
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    const cells = compiled.querySelectorAll('td[mat-cell]');
    
    expect(Math.round(cells.length / 4)).toBe(10);
  });

  it('should filter customers by name', async () => {
    component.selectedFilterField = 'name';
    component.filterInputValue = 'Hydrogen';
    component.applyFilter();
    await fixture.whenStable();
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    const cells = compiled.querySelectorAll('td[mat-cell]');

    expect(Math.round(cells.length / 4)).toBe(1);
    expect(compiled.textContent).toContain('Hydrogen');
  });
});
