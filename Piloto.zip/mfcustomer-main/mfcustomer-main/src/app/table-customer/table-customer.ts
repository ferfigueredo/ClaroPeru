import { Component, OnInit, ChangeDetectorRef, signal, inject, computed } from '@angular/core';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { Customer, Customers } from '../services/customer';
import { FormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { MatOptionModule } from '@angular/material/core';
import { Shared } from 'shared-kit';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-table-customer',
  standalone: true,
  templateUrl: './table-customer.html',
  styleUrls: ['./table-customer.scss'],
  imports: [
    MatFormFieldModule,
    MatInputModule,
    MatTableModule,
    MatSelectModule,
    MatOptionModule,
    FormsModule
  ],
})
export class TableCustomer implements OnInit {


  readonly Shared = inject(Shared);

  title = signal('Clientes').asReadonly();
  remoteUrl: string = environment.remoteUrl;

  displayedColumns: string[] = ['icon', 'name', 'typeID', 'lineNumber'];
  customersData: Customers[] = [];
  dataSource = new MatTableDataSource(this.customersData);

  selectedFilterField: keyof Customers = 'name';
  filterValue: string = '';
  filterInputValue: string = '';

  constructor(
    private readonly http: HttpClient,
    private readonly customerService: Customer,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.customerService.getCustomers().subscribe(customers => {
      this.customersData = customers;
      this.dataSource.data = this.customersData;
      this.setFilterPredicate();
    });
    this.title = computed(() => {
      return 'Clientes - ' + this.Shared.sharedMessage();
    })
  }

  setFilterPredicate() {
    this.dataSource.filterPredicate = (data: Customers, filter: string) => {
      const field = this.selectedFilterField;
      return (data[field] || '').toLowerCase().includes(filter);
    };
    if (this.filterValue) {
      this.dataSource.filter = this.filterValue;
    }
    this.cdr.detectChanges();
  }

  onFilterFieldChange(field: keyof Customers) {
    this.selectedFilterField = field;
    this.setFilterPredicate();
  }

  applyFilter() {
    this.filterValue = (this.filterInputValue || '').trim().toLowerCase();
    this.dataSource.filter = this.filterValue;
  }
}
