import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Customer, Customers } from './customer';
import { provideZonelessChangeDetection } from '@angular/core';

describe('Customer Service', () => {
  let service: Customer;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [Customer, provideZonelessChangeDetection()]
    });
    service = TestBed.inject(Customer);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should fetch customers from API', () => {
    const mockCustomers: Customers[] = [
      { name: 'Hydrogen', typeID: 'RUC 1232123', lineNumber: '555-802-4693' },
      { name: 'Helium', typeID: '', lineNumber: '555-802-4693' }
    ];

    service.getCustomers().subscribe(customers => {
      expect(customers.length).toBe(2);
      expect(customers).toEqual(mockCustomers);
    });

    const req = httpMock.expectOne('http://localhost:3000/customers');
    expect(req.request.method).toBe('GET');
    req.flush(mockCustomers);
  });
});
