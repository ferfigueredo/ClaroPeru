import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface Customers {
  name: string;
  typeID: string;
  lineNumber: string;
}

@Injectable({
  providedIn: 'root',
})
export class Customer {
  constructor(private readonly http: HttpClient) {}

  getCustomers(): Observable<Customers[]> {
    return this.http.get<Customers[]>('http://localhost:3000/customers');
  }
}
