export const environment = {
  production: false,
  remoteUrl: 'http://localhost:4201'
};