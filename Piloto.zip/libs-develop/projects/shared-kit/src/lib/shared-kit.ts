import { Component } from '@angular/core';

@Component({
  selector: 'lib-shared-kit',
  imports: [],
  template: `
    <p>
      shared-kit works!
    </p>
  `,
  styles: ``,
})
export class SharedKit {

}
