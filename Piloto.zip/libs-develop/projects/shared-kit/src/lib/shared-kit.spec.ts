import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SharedKit } from './shared-kit';

describe('SharedKit', () => {
  let component: SharedKit;
  let fixture: ComponentFixture<SharedKit>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SharedKit]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SharedKit);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
