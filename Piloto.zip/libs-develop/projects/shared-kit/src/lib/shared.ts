import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Shared {
  readonly #sharedMessage = signal('Mensaje desde Shared Service');

  get sharedMessage() {
    return this.#sharedMessage.asReadonly();
  }

  updateSharedMessage(newMessage: string): void {
    this.#sharedMessage.set(newMessage);
  }
}
