import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { delay, tap } from 'rxjs/operators';

export interface AuthToken {
  token: string;
  username: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private storageKey = 'auth';


  login(username: string, password: string): Observable<AuthToken> {
    if (!username || !password) {
      return throwError(() => new Error('Usuario y contraseña son requeridos.'));
    }

    const fakeToken: AuthToken = {
      token: btoa(`dummy-jwt-token-${username}-${Date.now()}`),
      username
    };

    return of(fakeToken).pipe(
      delay(200),
      tap(t => {
        localStorage.setItem(this.storageKey, JSON.stringify(t));
      })
    );
  }

  logout() {
    localStorage.removeItem(this.storageKey);
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem(this.storageKey);
  }

  get token(): AuthToken | null {
    const json = localStorage.getItem(this.storageKey);
    return json ? JSON.parse(json) : null;
  }
}
