import { generateCorrelationId } from './correlation';

describe('generateCorrelationId', () => {
  it('should generate a valid UUID v4 string', () => {
    const id = generateCorrelationId();

    const uuidV4Regex =
      /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

    expect(typeof id).toBe('string');
    expect(id).toMatch(uuidV4Regex);
  });

  it('should generate different UUIDs each time', () => {
    const id1 = generateCorrelationId();
    const id2 = generateCorrelationId();
    expect(id1).not.toBe(id2);
  });
});
