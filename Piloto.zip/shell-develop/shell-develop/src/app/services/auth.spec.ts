import { AuthService } from './auth';

describe('AuthService (standalone, zoneless)', () => {
  let service: AuthService;

  beforeEach(() => {
    localStorage.clear();
    service = new AuthService();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should login and set token', async () => {
    let receivedToken: any;

    await new Promise<void>(resolve => {
      service.login('user', 'pass').subscribe(token => {
        receivedToken = token;
        resolve();
      });
    });

    expect(receivedToken).toBeTruthy();
    expect(receivedToken.username).toBe('user');
    expect(typeof receivedToken.token).toBe('string');
    expect(service.isLoggedIn()).toBeTrue();
    expect(service.token).toEqual(receivedToken);
  });

  it('should logout and clear token', async () => {
    await new Promise<void>(resolve => {
      service.login('user', 'pass').subscribe(() => resolve());
    });

    expect(service.isLoggedIn()).toBeTrue();

    service.logout();

    expect(service.isLoggedIn()).toBeFalse();
    expect(service.token).toBeNull();
  });

  it('isLoggedIn should return false when token is null', () => {
    service.logout();
    expect(service.isLoggedIn()).toBeFalse();
  });

  it('isLoggedIn should return true when token is set', async () => {
    await new Promise<void>(resolve => {
      service.login('user', 'pass').subscribe(() => resolve());
    });

    expect(service.isLoggedIn()).toBeTrue();
  });
});
