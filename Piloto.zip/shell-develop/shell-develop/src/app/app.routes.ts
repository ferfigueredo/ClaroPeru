import { Routes } from '@angular/router';
import { LoginComponent } from './login/login';
import { MainLayoutComponent } from './core/main-layout/main-layout';
import { authGuard } from './guards/auth-guard';
import { loadRemoteWithRxRetry } from './utils/utilities';

export const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: '',
    redirectTo: 'customer',
    pathMatch: 'full'
  },
  {
    path: '',
    component: MainLayoutComponent,
    canActivate: [authGuard],  // Protege las rutas privadas
    children: [
      {
        path: 'customer',
        loadComponent: () =>
          loadRemoteWithRxRetry<any>({
            remoteName: 'mfcustomer',
            exposedModule: './Component'
          })
          .then(m => m.App)
          .catch(() =>
            import('./core/fallback/fallback').then(m => m.Fallback))
      },
      {
        path: 'perfil',
        loadComponent: () =>
          loadRemoteWithRxRetry<any>({
            remoteName: 'mfperfil',
            exposedModule: './Component'
          })
          .then(m => m.App)
          .catch(() =>
            import('./core/fallback/fallback').then(m => m.Fallback))
      }
    ]
  }
];
