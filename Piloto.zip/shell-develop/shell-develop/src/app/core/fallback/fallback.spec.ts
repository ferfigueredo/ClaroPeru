import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Fallback } from './fallback';
import { provideZonelessChangeDetection } from '@angular/core';

describe('Fallback Component', () => {
  let component: Fallback;
  let fixture: ComponentFixture<Fallback>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Fallback],
      providers: [provideZonelessChangeDetection()]
    }).compileComponents();

    fixture = TestBed.createComponent(Fallback);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should render fallback message', () => {
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('h2')?.textContent).toContain('Este modulo no se encuentra disponible en este momento');
    expect(compiled.querySelector('p')?.textContent).toContain('Por favor, recargue la página o inténtelo nuevamente más tarde.');
  });
});