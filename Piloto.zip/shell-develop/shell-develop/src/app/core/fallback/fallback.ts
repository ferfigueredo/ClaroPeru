import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-fallback',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './fallback.html',
  styleUrls: ['./fallback.scss']
})
export class Fallback {}