import { HttpInterceptorFn } from '@angular/common/http';
import { generateCorrelationId } from '../../../services/correlation';

export const correlationInterceptor: HttpInterceptorFn = (req, next) => {
  const correlationId = generateCorrelationId();
  const clonedReq = req.clone({
    setHeaders: { 'X-Correlation-ID': correlationId },
  });
  
  return next(clonedReq);
};