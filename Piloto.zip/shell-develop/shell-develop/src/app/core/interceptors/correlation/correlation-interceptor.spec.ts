import { HttpRequest } from '@angular/common/http';
import { correlationInterceptor } from './correlation-interceptor';

describe('correlationInterceptor', () => {

  it('should add X-Correlation-ID header', (done) => {
    const req = new HttpRequest('GET', '/api/data');

    const next = jasmine.createSpy('next').and.callFake((r: HttpRequest<any>) => {
      const header = r.headers.get('X-Correlation-ID');

      expect(header).toBeTruthy();
      expect(header?.length).toBeGreaterThan(0);

      done();
    });

    correlationInterceptor(req, next);
  });
});
