import { TestBed } from '@angular/core/testing';
import { AuthInterceptor } from './auth-interceptor';


describe('AuthInterceptor', () => {
  let service: any;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AuthInterceptor]
    });
    service = TestBed.inject(AuthInterceptor);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
