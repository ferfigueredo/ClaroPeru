import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { catchError, throwError } from 'rxjs';
import { MatSnackBar } from '@angular/material/snack-bar';
import { inject } from '@angular/core';

export const AuthInterceptor: HttpInterceptorFn = (req, next) => {
  const snackBar = inject(MatSnackBar);
  const token = localStorage.getItem('token');

  const authReq = token ? req.clone({
    setHeaders: {
      Authorization: `Bearer ${token}`
    }
  }) : req;

  return next(authReq).pipe(
    catchError((error: HttpErrorResponse) => {
      snackBar.open('Error de autenticación: ' + (error.statusText || error.message), 'Cerrar', { duration: 4000 });
      if (error.status === 401) {
        snackBar.open('Acceso no autorizado - Redirigiendo al login.', 'Cerrar');
        // Aquí podrías redirigir al login si lo deseas
      }
      if (error.status === 403) {
        snackBar.open('Acceso prohibido - No tienes permiso para acceder a este recurso.', 'Cerrar');
      }

      if (error.status === 404) {
        snackBar.open('Recurso no encontrado.', 'Cerrar');
      }

      return throwError(() => error);
    })
  );
};