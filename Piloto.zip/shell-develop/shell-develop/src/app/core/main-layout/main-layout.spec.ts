import { MainLayoutComponent } from './main-layout';
import { Router, NavigationEnd } from '@angular/router';
import { Injector, EnvironmentInjector, runInInjectionContext } from '@angular/core';
import { Subject } from 'rxjs';
import { AuthService } from '../../services/auth';

describe('MainLayoutComponent (Angular 20, standalone, zoneless)', () => {
  let component: MainLayoutComponent;
  let routerMock: any;
  let authServiceMock: any;
  let injector: Injector;
  let envInjector: EnvironmentInjector;
  let routerEvents$: Subject<any>;

  beforeEach(() => {
    routerEvents$ = new Subject<any>();

    routerMock = {
      navigate: jasmine.createSpy('navigate'),
      navigateByUrl: jasmine.createSpy('navigateByUrl'),
      events: routerEvents$.asObservable(),
      url: '/customer'
    };

    authServiceMock = {
      logout: jasmine.createSpy('logout')
    };

    envInjector = Injector.create({ providers: [] }) as EnvironmentInjector;

    injector = Injector.create({
      providers: [
        { provide: Router, useValue: routerMock },
        { provide: AuthService, useValue: authServiceMock },
        { provide: EnvironmentInjector, useValue: envInjector }
      ]
    });

    component = runInInjectionContext(injector, () => new MainLayoutComponent());
    component.ngOnInit();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set initial activeButton based on router.url', () => {
    expect(component.activeButton).toBe('/customer');
  });

  it('should update activeButton on navigation events', () => {
    routerEvents$.next(new NavigationEnd(1, '/perfil', '/perfil'));
    expect(component.activeButton).toBe('/perfil');
  });

  it('should navigate when navigateTo is called', () => {
    component.navigateTo('/perfil');

    expect(routerMock.navigate).toHaveBeenCalledWith(['/perfil']);

    routerEvents$.next(new NavigationEnd(1, '/perfil', '/perfil'));

    expect(component.activeButton).toBe('/perfil');
  });

  it('should logout and navigate to login', () => {
    component.logout();

    expect(authServiceMock.logout).toHaveBeenCalled();
    expect(routerMock.navigateByUrl).toHaveBeenCalledWith('/login');
  });
});
