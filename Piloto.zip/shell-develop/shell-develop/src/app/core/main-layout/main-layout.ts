import { Component, inject, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { RouterOutlet } from '@angular/router';
import { AuthService } from '../../services/auth';

@Component({
  selector: 'app-main-layout',
  standalone: true,
  templateUrl: './main-layout.html',
  styleUrls: ['./main-layout.scss'],
  imports: [
    MatSidenavModule,
    MatIconModule,
    MatButtonModule,
    RouterOutlet
  ]
})
export class MainLayoutComponent implements OnInit {
  private router = inject(Router);
  private authService = inject(AuthService);

  activeButton: string = '';

  ngOnInit() {

    this.setActiveButton(this.router.url);

    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: any) => {
        this.setActiveButton(event.urlAfterRedirects);
      });
  }

  private setActiveButton(url: string) {
    if (url.startsWith('/customer')) {
      this.activeButton = '/customer';
    } else if (url.startsWith('/perfil')) {
      this.activeButton = '/perfil';
    } else {
      this.activeButton = '';
    }
  }

  navigateTo(route: string) {
    this.router.navigate([route]);
  }

  logout() {
    this.authService.logout();
    this.router.navigateByUrl('/login');
  }
}
