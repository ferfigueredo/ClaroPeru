import { Injector, runInInjectionContext } from '@angular/core';
import { LoginComponent } from './login';
import { AuthService, AuthToken } from '../services/auth';
import { Router } from '@angular/router';
import { of, throwError } from 'rxjs';

describe('LoginComponent (Angular 20, standalone, zoneless)', () => {
  let component: LoginComponent;
  let injector: Injector;
  let authServiceSpy: jasmine.SpyObj<AuthService>;
  let routerSpy: jasmine.SpyObj<Router>;

  beforeEach(() => {
    authServiceSpy = jasmine.createSpyObj('AuthService', ['login']);
    routerSpy = jasmine.createSpyObj('Router', ['navigateByUrl']);

    injector = Injector.create({
      providers: [
        { provide: AuthService, useValue: authServiceSpy },
        { provide: Router, useValue: routerSpy }
      ]
    });

    runInInjectionContext(injector, () => {
      component = new LoginComponent();
    });
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize empty fields', () => {
    expect(component.username).toBe('');
    expect(component.password).toBe('');
    expect(component.error).toBe('');
  });

  it('should login successfully and navigate', (done) => {
  const fakeToken: AuthToken = { token: 'fake-token', username: 'user' };
  authServiceSpy.login.and.returnValue(of(fakeToken));

  spyOnProperty(history, 'state', 'get').and.returnValue({});

  component.username = 'user';
  component.password = 'pass';

  component.login();

  authServiceSpy.login.calls.mostRecent().returnValue.subscribe(() => {
    expect(authServiceSpy.login).toHaveBeenCalledWith('user', 'pass');
    expect(routerSpy.navigateByUrl).toHaveBeenCalledWith('/customer');
    expect(component.error).toBe('');
    done();
  });
});

  it('should show error when login fails', (done) => {
    const error = new Error('Invalid credentials');
    authServiceSpy.login.and.returnValue(throwError(() => error));

    component.username = 'user';
    component.password = 'wrong';

    component.login();

    authServiceSpy.login.calls.mostRecent().returnValue.subscribe({
      error: () => {
        expect(authServiceSpy.login).toHaveBeenCalledWith('user', 'wrong');
        expect(routerSpy.navigateByUrl).not.toHaveBeenCalled();
        expect(component.error).toBe('Invalid credentials');
        done();
      }
    });
  });
});
