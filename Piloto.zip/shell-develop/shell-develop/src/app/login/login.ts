import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { AuthService } from '../services/auth';
import { Shared } from 'shared-kit';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.html',
  styleUrls: ['./login.scss'],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatButtonModule
  ],
})
export class LoginComponent {
  username = '';
  password = '';
  error = '';

  private authService = inject(AuthService);
  private router = inject(Router);
  readonly Shared = inject(Shared);

  login() {
    this.authService.login(this.username, this.password).subscribe({
      next: () => {
        this.Shared.updateSharedMessage(this.username);
        const redirectUrl = history.state.redirectUrl || '/customer';
        this.router.navigateByUrl(redirectUrl);
      },
      error: err => {
        this.error = err.message;
      }
    });
  }
}
