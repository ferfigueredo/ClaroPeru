import { loadRemoteModule } from '@angular-architects/native-federation';
import { delay, from, lastValueFrom, of, catchError, retry } from 'rxjs';

export const loadRemoteWithRxRetry = async function loadRemoteWithRxRetry<T>(options: any, retries = 3, delayMs = 1500
): Promise<T> {
  const obs$ = from(loadRemoteModule(options)).pipe(
    retry({
      count: retries - 1,
      delay: (error, retryCount) => {
        console.warn(`🔁 Reintentando carga de ${options.remoteName} (${retryCount}/${retries})`, error);
        return of(null).pipe(delay(delayMs));
      }
    }),
    catchError(err => {
      console.error(`❌ Falló la carga de ${options.remoteName} después de ${retries} intentos`, err);
      throw err;
    })
  );
  return await lastValueFrom(obs$);
}