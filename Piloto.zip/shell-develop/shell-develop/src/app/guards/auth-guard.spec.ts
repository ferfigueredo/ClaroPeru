import { Injector, runInInjectionContext } from '@angular/core';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from '../services/auth';
import { authGuard } from './auth-guard';

describe('authGuard (Angular 20, standalone, zoneless)', () => {
  let injector: Injector;
  let authServiceSpy: jasmine.SpyObj<AuthService>;
  let routerSpy: jasmine.SpyObj<Router>;

  beforeEach(() => {
    authServiceSpy = jasmine.createSpyObj('AuthService', ['isLoggedIn']);
    routerSpy = jasmine.createSpyObj('Router', ['navigateByUrl']);

    injector = Injector.create({
      providers: [
        { provide: AuthService, useValue: authServiceSpy },
        { provide: Router, useValue: routerSpy }
      ]
    });
  });

  function runGuard(route: Partial<ActivatedRouteSnapshot>, state: Partial<RouterStateSnapshot>) {
    return runInInjectionContext(injector, () =>
      authGuard(route as ActivatedRouteSnapshot, state as RouterStateSnapshot)
    );
  }

  it('should allow access when logged in', () => {
    authServiceSpy.isLoggedIn.and.returnValue(true);

    const result = runGuard({}, { url: '/customer' });

    expect(result).toBeTrue();
    expect(routerSpy.navigateByUrl).not.toHaveBeenCalled();
  });

  it('should redirect to /login when not logged in', () => {
    authServiceSpy.isLoggedIn.and.returnValue(false);

    const result = runGuard({}, { url: '/customer' });

    expect(result).toBeFalse();
    expect(routerSpy.navigateByUrl).toHaveBeenCalledWith('/login', {
      state: { redirectUrl: '/customer' }
    });
  });
});
