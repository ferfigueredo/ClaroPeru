package ${package}.configuration.security;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import ${package}.security.filter.JwtRequestFilter;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true) // Habilita @PreAuthorize, @PostAuthorize
public class SecurityConfig {

    @Autowired
    private JwtRequestFilter jwtRequestFilter;
    
    // (Opcional, pero recomendado) Manejador para errores 401
    // @Autowired
    // private JwtAuthenticationEntryPoint unauthorizedHandler; 

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
        return authConfig.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        
        // 1. Desactivar CSRF (no es necesario para APIs stateless JWT)
        //http.csrf(csrf -> csrf.disable()).sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
        //.authorizeHttpRequests(authz -> authz.requestMatchers("/api/auth/**").permitAll().requestMatchers("/swagger-ui/**", "/v3/api-docs/**").permitAll().anyRequest().authenticated());
                    // Rutas públicas (ej. login, registro, swagger)
                    
                    
                    // 4. ¡Todas las demás rutas requieren autenticación!
                    
               
        // (Opcional) Manejar errores de autenticación
        // .exceptionHandling(ex -> ex.authenticationEntryPoint(unauthorizedHandler))

        // 2. Configurar la gestión de sesiones como STATELESS (sin estado)
        // Spring Security no creará ni usará sesiones HTTP.
        

        // 3. Definir reglas de autorización
        

        // 5. ¡Añadir nuestro filtro JWT personalizado!
        // Le decimos a Spring que use nuestro filtro ANTES del filtro estándar de username/password.


        //------------------------------

        http.csrf(csrf -> csrf.disable())
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)).authorizeHttpRequests(authz -> authz.requestMatchers("/api/auth/**")
                .permitAll().requestMatchers("/v3/api-docs/**","/swagger-ui/**","/swagger-ui.html").permitAll().anyRequest().authenticated());
                
                // --- RUTAS PÚBLICAS ---x|x|
                
                // Autenticación
                
                // --- SWAGGER UI (springdoc-openapi) ---
                // Esta es la parte clave.
                // Necesitas permitir el acceso a la documentación JSON Y a la UI web.
                
                // El archivo HTML principal de la UI
                // --- RUTAS PRIVADAS ---
                // Todas las demás peticiones requieren autenticación
                
            
        http.addFilterBefore(jwtRequestFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
