package ${package}.kafka.service.impl;

import ${package}.kafka.dto.KFKDummyDTO;
import ${package}.kafka.dto.KFKMessageHeader;
import ${package}.kafka.service.KafkaConsumerService;
import io.micrometer.observation.annotation.Observed;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;


@Slf4j
@Service
@Observed(name = "kafkaConsumerServiceImpl")
@RequiredArgsConstructor
public class KafkaConsumerServiceImpl implements KafkaConsumerService {

    //private final MyService myService;
    public static final String MESSAGE_SUCCESS = "Mensaje Procesado: {} ";
    public static final String ERROR_PROCESING_MESSAGE = "Error al procesar el mensaje : {}.";

    @KafkaListener(topics = "${kafka.mobiquity.topic.name}", groupId = "${kafka.mobiquity.group.id}",
            containerFactory = "kfkDummyDtoKafkaListenerContainerFactory")
    @KafkaHandler
    public void retentionConsumer(@Payload KFKDummyDTO consumerRecord, Acknowledgment ack) {
        try {
            log.info("Consumer record : {}", consumerRecord);
           
            final KFKMessageHeader kfkMessageHeader = consumerRecord.getKfkMessageHeader().getFirst();
          
            //Aqui se debe invocar al Service que ejecute la accion deseada con el mensaje recibido
            //this.myService.doAction(kfkMessageHeader);

            log.info(MESSAGE_SUCCESS, consumerRecord);
           
        } catch (Exception e) {
            log.error(ERROR_PROCESING_MESSAGE, consumerRecord, e.getMessage());
        } finally {
            log.info("Execute manual commit");
            ack.acknowledge();
        }
    }
}
