package ${package}.security.service.impl;

import ${package}.security.service.JwtValidatorService;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.security.Keys;
import io.jsonwebtoken.security.SignatureException;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;



import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;

/**
 * Componente de Spring para validar tokens JWT.
 * Maneja la validación de la firma y la expiración del token.
 */
@Component
public class JwtValidatorServiceImpl implements JwtValidatorService {

    private static final Logger JWTVALIDATIONLOGGER = LoggerFactory.getLogger(JwtValidatorServiceImpl.class);

    // Inyecta el secreto desde application.properties/yml
    @Value("${security.jwt.secret-key}")
    private String jwtSecretString;

    private SecretKey secretKey;
    private JwtParser jwtParser;

    /**
     * PostConstruct se ejecuta después de la inyección de dependencias
     * (cuando jwtSecretString ya tiene su valor).
     */
    @PostConstruct
    public void init() {
        // 1. Convierte el String secreto a una clave criptográfica (SecretKey)
        // Asegúrate de que tu secreto sea lo suficientemente largo para el algoritmo (ej. HS256)
        this.secretKey = Keys.hmacShaKeyFor(jwtSecretString.getBytes(StandardCharsets.UTF_8));
        
        // 2. Construye el "parser" (analizador) de JWTs
        // Este parser se reutiliza y es thread-safe.
        this.jwtParser = Jwts.parserBuilder()
                .setSigningKey(secretKey)
                .build();
    }

    /**
     * Valida un token JWT.
     *
     * @param token El string del JWT (sin el prefijo "Bearer ").
     * @return true si el token es válido (firma correcta Y no expirado), false en caso contrario.
     */
    public boolean validateToken(String token) {
        try {
            // El método parseClaimsJws valida la firma y la expiración.
            // Si tiene éxito, el token es válido.
            jwtParser.parseClaimsJws(token);
            return true;
            
        } catch (SignatureException e) {
            JWTVALIDATIONLOGGER.error("Error de validación JWT: Firma inválida -> {}", e.getMessage());
        } catch (MalformedJwtException e) {
            JWTVALIDATIONLOGGER.error("Error de validación JWT: Token malformado -> {}", e.getMessage());
        //} catch (ExpiredJwtException e) {
        //    JWTVALIDATIONLOGGER.warn("Error de validación JWT: Token expirado -> {}", e.getMessage());
        } catch (UnsupportedJwtException e) {
            JWTVALIDATIONLOGGER.error("Error de validación JWT: Token no soportado -> {}", e.getMessage());
        } catch (IllegalArgumentException e) {
            JWTVALIDATIONLOGGER.error("Error de validación JWT: Claims vacíos -> {}", e.getMessage());
        }

        return false;
    }

    /**
     * Método de utilidad (opcional) para obtener los "claims" si el token es válido.
     * Si la validación falla (ej. expirado), lanzará la excepción correspondiente.
     *
     * @param token El string del JWT.
     * @return El objeto Claims que contiene (subject, roles, etc.)
     * @throws ExpiredJwtException Si el token está expirado.
     * @throws SignatureException Si la firma es incorrecta.
     */
    public Claims getClaimsFromToken(String token) throws ExpiredJwtException, SignatureException {
        Jws<Claims> jwsClaims = jwtParser.parseClaimsJws(token);
        return jwsClaims.getBody();
    }
}
