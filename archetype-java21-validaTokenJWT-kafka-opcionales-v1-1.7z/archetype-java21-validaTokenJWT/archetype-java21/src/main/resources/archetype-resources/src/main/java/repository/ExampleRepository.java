#if( $includeDB == 'true' )
package ${package}.repository;

import ${package}.model.Example;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ExampleRepository extends JpaRepository<Example, Integer> {

    Optional<Example> findOneByPhoneNumber(String phoneNumber);
}
#end