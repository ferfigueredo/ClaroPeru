package ${package}.service.impl;

// Import condicional del cliente REST
#if( $includeRestClient == 'true' )
import ${package}.client.UserClient;
#end
import ${package}.dto.request.${classPrefix}Request;
import ${package}.dto.response.ResultDto;

// Imports condicionales de Base de Datos
#if( $includeDB == 'true' )
import ${package}.model.Example;
import ${package}.repository.ExampleRepository;
import java.util.Optional;
#end

import ${package}.service.${classPrefix}Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import com.claro.common.claro.dto.response.Response;
import org.springframework.stereotype.Service;
import org.springframework.http.HttpStatus;



@Slf4j
@Service
@RequiredArgsConstructor
public class ${classPrefix}ServiceImpl implements ${classPrefix}Service {

    // INYECCION CONDICIONAL DE CLIENTE REST
    #if( $includeRestClient == 'true' )
    private final UserClient userClient;
    #end
	// INYECCION CONDICIONAL DE REPOSITORIO (DB)
    #if( $includeDB == 'true' )
    private final ExampleRepository exampleRepository;
    #end

    public Response<ResultDto> example(final ${classPrefix}Request request) {
        log.info("::::: starting example: {} :::::", request);

        // LÓGICA CONDICIONAL DE LA BASE DE DATOS
        #if( $includeDB == 'true' )
        Optional<Example> exampleOptional = this.exampleRepository.findOneByPhoneNumber(request.getCellularNumber());
        if (exampleOptional.isPresent()) {
            var result = new ResultDto(exampleOptional.get().getPhoneNumber());
            return new Response<>(HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.value(), result);
        }
        #end
        
        // LÓGICA CONDICIONAL DEL CLIENTE REST (BFF)
        #if( $includeRestClient == 'true' )
        return this.userClient.getResponseFromIntegration(request.getCellularNumber());
        #else
        // Este es el caso por defecto (NO DB, NO CLIENTE REST)
        log.warn("::::: No hay Base de Datos ni Cliente REST. Devolviendo respuesta estática (MOCK). :::::");
        var result = new ResultDto(request.getCellularNumber());
        return new Response<>(HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.value(), result);
		#end
    }	 
}