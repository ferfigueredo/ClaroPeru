package ${package}.exception;

public class ${classPrefix}Exception extends RuntimeException {
    public ${classPrefix}Exception(String errorMessage) {
        super(errorMessage);
    }
}