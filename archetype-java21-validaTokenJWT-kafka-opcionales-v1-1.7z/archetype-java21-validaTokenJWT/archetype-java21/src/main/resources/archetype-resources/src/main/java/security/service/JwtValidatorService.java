package ${package}.security.service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.security.SignatureException;


public interface JwtValidatorService {

    public boolean validateToken(String token); 

    public Claims getClaimsFromToken(String token) throws ExpiredJwtException, SignatureException;
}

