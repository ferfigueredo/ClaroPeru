package ${package}.service;


import ${package}.dto.request.${classPrefix}Request;
import ${package}.dto.response.ResultDto;
import com.claro.common.claro.dto.response.Response;


public interface ${classPrefix}Service {

    public Response<ResultDto> example(final ${classPrefix}Request request);
   
}