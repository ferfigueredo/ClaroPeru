import java.nio.file.Files
import java.nio.file.Paths
import java.io.File

// --- 1. OBTENCIÓN DE DATOS ---
// request.getProperties() devuelve un LinkedHashMap, no un objeto Properties.
def properties = request.getProperties()

def artifactId = request.getArtifactId()
def packageName = request.getPackage()
def outputDirectory = request.getOutputDirectory()

// --- 2. CONFIGURACIÓN DE RUTAS ---
File projectDir = new File(outputDirectory, artifactId)
String packagePath = packageName.replace(".", "/")
File srcMainJava = new File(projectDir, "src/main/java/" + packagePath)

// --- 3. LOGGER ---
File logFile = new File(projectDir, "LOG_POST_GEN.txt")
StringBuilder log = new StringBuilder()
log.append("=== INICIO SCRIPT ===\n")

// --- 4. LEER TUS VARIABLES (CORREGIDO) ---
// Usamos .get() porque 'properties' es un Mapa
boolean isTrue(def map, String key) {
    def val = map.get(key)
    return val != null && (val.toString().equalsIgnoreCase("true") || val.toString().equalsIgnoreCase("y"))
}

boolean includeDB         = isTrue(properties, "includeDB")
boolean includeKafka      = isTrue(properties, "includeKafka")
boolean validateJwt       = isTrue(properties, "validateJwt")
boolean includeRestClient = isTrue(properties, "includeRestClient")

log.append("Configuración detectada:\n")
log.append(" - includeDB: " + includeDB + "\n")
log.append(" - includeKafka: " + includeKafka + "\n")
log.append(" - validateJwt: " + validateJwt + "\n")
log.append(" - includeRestClient: " + includeRestClient + "\n")

// --- 5. FUNCIÓN DE BORRADO ---
def borrar(File base, String carpeta, StringBuilder logger) {
    File target = new File(base, carpeta)
    if (target.exists()) {
        logger.append("Borrando carpeta: " + target.getName() + " ... ")
        // Intento de borrado robusto
        boolean borrado = target.deleteDir()
        if (!borrado) {
             // Si falla, vaciamos y borramos
             target.eachFileRecurse { f -> f.delete() }
             target.delete()
        }
        logger.append("OK\n")
    }
}

// --- 6. EJECUCIÓN ---

if (!includeKafka) {
    borrar(srcMainJava, "kafka", log)
}

if (!validateJwt) {
    borrar(srcMainJava, "security", log)
    borrar(srcMainJava, "configuration/security", log)
}

if (!includeRestClient) {
    borrar(srcMainJava, "client", log)
}

if (!includeDB) {
    borrar(srcMainJava, "model", log)
    borrar(srcMainJava, "repository", log)
}

// Guardar log
log.append("=== FIN SCRIPT ===\n")
logFile.write(log.toString())