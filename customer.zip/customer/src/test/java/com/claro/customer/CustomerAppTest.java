package com.claro.customer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerAppTest {

    @Test
    @SuppressWarnings("squid:S2699")
    void contextLoads() {
    }
}