package com.claro.customer.utils;

import com.claro.common.claro.dto.response.PageResponse;
import com.claro.common.claro.dto.response.Response;
import com.claro.customer.model.dto.customer.CustomerDto;
import com.claro.customer.model.dto.product.LineDto;
import com.claro.customer.model.dto.product.ProductDto;

import java.util.List;

public class TestUtils {
    public static final String LINE_NUMBER = "123456789";
    public static final String CUSTOMER_ID = "1";
    public static final String PIMARY_SYSTEM_VALUE = "BSCS";
    public static final String SECONDARY_SYSTEM_VALUE = "BSCSIX";
    public static final String DOCUMENT_NUMBER = "12345678";
    public static final Integer DOCUMENT_TYPE = 1;
    public static final String ID = "1";

    public static final int PAGE_NUMBER = 0;
    public static final int PAGE_SIZE = 10;
    public static final String ALIAS = "Alias";
    public static final String ADDRESS = "Address";

    public static CustomerDto buildCustomerDto() {
        return CustomerDto.builder().id("1").build();
    }

    public static Response<CustomerDto> buildGetCustomerInfoResponse() {
        return Response.<CustomerDto>builder().code(200).message("Operación exitosa").data(buildCustomerDto()).build();
    }

    public static PageResponse<List<CustomerDto>> buildGetAllCustomersInfoResponse() {

        return PageResponse.<List<CustomerDto>>builder().code(200).message("Operación exitosa").data(List.of(buildCustomerDto())).build();
    }

    public static PageResponse<List<ProductDto>> buildGetAllProductsInfoResponse() {
        return PageResponse.<List<ProductDto>>builder().code(200).message("Operación exitosa").data(List.of(buildProductDto())).build();
    }

    public static ProductDto buildProductDto() {
        return ProductDto.builder().customerId("1").line(buildLineDto()).build();
    }

    private static LineDto buildLineDto() {
        return LineDto.builder().lineNumber(LINE_NUMBER).planDescription("Plan Description").coId("CO123").build();
    }
}
