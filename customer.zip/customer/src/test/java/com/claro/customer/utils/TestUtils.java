package com.claro.customer.utils;

import com.claro.common.claro.dto.response.Response;
import com.claro.customer.dto.customer.CustomerDto;
import com.claro.customer.dto.equivalence.EquivalenceData;
import com.claro.customer.dto.equivalence.EquivalenceResponse;

import java.util.List;

public class TestUtils {

    public static final String CUSTOMER_ID = "1";
    public static final String DOCUMENT_NUMBER = "12345678";
    public static final String DOCUMENT_TYPE = "DNI";
    public static final String ID = "1";

    public static final int DEFAULT_TIME_MILLISECONDS = 10000;

    public static CustomerDto buildCustomerDto() {
        return CustomerDto.builder().id("1").build();
    }

    public static Response<List<CustomerDto>> buildGetListCustomerInfoResponse() {
        return Response.<List<CustomerDto>>builder()
                .code(200)
                .message("Operación exitosa")
                .data(List.of(buildCustomerDto()))
                .build();
    }

    public static Response<CustomerDto> buildGetCustomerInfoResponse() {
        return Response.<CustomerDto>builder().code(200).message("Operación exitosa").data(buildCustomerDto()).build();
    }

    public static EquivalenceResponse buildEquivalenceResponse() {
        return EquivalenceResponse.builder()
                .code(200)
                .message("Operación exitosa")
                .data(EquivalenceData.builder()
                        .legacyDocTypeCode("DNI")
                        .crmDocTypeCode("1")
                        .description("DOCUMENTO NACIONAL DE IDENTIDAD")
                        .abbreviation("DNI")
                        .legacyAppName("TIMPROD")
                        .build())
                .build();
    }

}
