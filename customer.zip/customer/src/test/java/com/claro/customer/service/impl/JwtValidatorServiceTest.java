package com.claro.customer.service.impl;

import com.claro.customer.utils.TestUtils;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import io.jsonwebtoken.security.SignatureException;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class JwtValidatorServiceTest {

    private JwtValidatorServiceImpl jwtValidatorService;
    private SecretKey secretKey;

    @BeforeAll
    void setUp() throws Exception {
        jwtValidatorService = new JwtValidatorServiceImpl();
        var secretField = JwtValidatorServiceImpl.class.getDeclaredField("jwtSecretString");
        secretField.setAccessible(true);
        var secret = "12345678901234567890123456789012";
        secretField.set(jwtValidatorService, secret);
        jwtValidatorService.init();
        secretKey = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }

    @Test
    void validateTokenShouldReturnTrueForValidToken() {
        var token = Jwts.builder()
                .setSubject("test")
                .setExpiration(new Date(System.currentTimeMillis() + TestUtils.DEFAULT_TIME_MILLISECONDS))
                .signWith(secretKey, SignatureAlgorithm.HS256)
                .compact();

        assertTrue(jwtValidatorService.validateToken(token));
    }

    @Test
    void validateTokenShouldReturnFalseForInvalidToken() {
        var invalidToken = "invalid.token.value";
        assertFalse(jwtValidatorService.validateToken(invalidToken));
    }

    @Test
    void validateTokenShouldReturnFalseForExpiredToken() {
        var token = Jwts.builder()
                .setSubject("test")
                .setExpiration(new Date(System.currentTimeMillis() - TestUtils.DEFAULT_TIME_MILLISECONDS))
                .signWith(secretKey, SignatureAlgorithm.HS256)
                .compact();

        assertFalse(jwtValidatorService.validateToken(token));
    }

    @Test
    void getClaimsFromTokenShouldReturnClaimsForValidToken() {
        var token = Jwts.builder()
                .setSubject("testSubject")
                .setExpiration(new Date(System.currentTimeMillis() + TestUtils.DEFAULT_TIME_MILLISECONDS))
                .signWith(secretKey, SignatureAlgorithm.HS256)
                .compact();

        var claims = jwtValidatorService.getClaimsFromToken(token);
        assertAll(
                () -> assertEquals("testSubject", claims.getSubject()),
                () -> assertNotNull(claims.getExpiration())
        );
    }

    @Test
    void getClaimsFromTokenShouldThrowExpiredJwtExceptionForExpiredToken() {
        var expiredToken = Jwts.builder()
                .setSubject("expired")
                .setExpiration(new Date(System.currentTimeMillis() - TestUtils.DEFAULT_TIME_MILLISECONDS))
                .signWith(secretKey, SignatureAlgorithm.HS256)
                .compact();

        assertThrows(ExpiredJwtException.class, () -> jwtValidatorService.getClaimsFromToken(expiredToken));
    }

    @Test
    void getClaimsFromTokenShouldThrowSignatureExceptionForInvalidSignature() {
        var otherSecretKey = Keys.hmacShaKeyFor("othersecretkeyothersecretkey1234".getBytes(StandardCharsets.UTF_8));
        var invalidSignatureToken = Jwts.builder()
                .setSubject("invalidSignature")
                .setExpiration(new Date(System.currentTimeMillis() + TestUtils.DEFAULT_TIME_MILLISECONDS))
                .signWith(otherSecretKey, SignatureAlgorithm.HS256)
                .compact();

        assertThrows(SignatureException.class, () -> jwtValidatorService.getClaimsFromToken(invalidSignatureToken));
    }

}
