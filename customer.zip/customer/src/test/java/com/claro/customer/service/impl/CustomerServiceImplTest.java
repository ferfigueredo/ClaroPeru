package com.claro.customer.service.impl;

import com.claro.common.claro.dto.response.Response;
import com.claro.customer.exception.CustomerException;
import com.claro.customer.mapper.CustomerMapper;
import com.claro.customer.model.dto.customer.CustomerDto;
import com.claro.customer.projection.CustomerView;
import com.claro.customer.repository.CustomerRepository;
import com.claro.customer.utils.TestUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static com.claro.customer.utils.TestUtils.CUSTOMER_ID;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CustomerServiceImplTest {

    @Mock
    private CustomerRepository customerRepository;

    @Mock
    private CustomerMapper customerMapper;

    @InjectMocks
    private CustomerServiceImpl customerService;

    @Mock
    private CustomerView customerView;
    private CustomerDto customerDto;
    private Response<CustomerDto> getCustomerInfoResponse;

    @BeforeEach
    void setUp() {
        customerDto = TestUtils.buildCustomerDto();
        getCustomerInfoResponse = TestUtils.buildGetCustomerInfoResponse();
    }

    @Test
    void testGetCustomerByIdSuccess() {
        when(customerRepository.findByCustomerId(any())).thenReturn(Optional.of(customerView));
        when(customerMapper.toCustomerDto(any())).thenReturn(customerDto);
        when(customerMapper.toGetCustomerInfoResponse(any())).thenReturn(getCustomerInfoResponse);

        var response = customerService.getCustomerById(CUSTOMER_ID);

        assertNotNull(response);
        verify(customerRepository, times(1)).findByCustomerId(any());
    }

    @Test
    void testGetCustomerByIdNotFound() {
        when(customerRepository.findByCustomerId(any())).thenReturn(Optional.empty());

        assertThrows(CustomerException.class, () -> customerService.getCustomerById(TestUtils.ID));
        verify(customerRepository, times(1)).findByCustomerId(any());
    }

    /*
    @Test
    void testGetAllCustomersInfo() {
        when(customerRepository.findByDocumentTypeAndDocumentNumber(any(), any())).thenReturn(Optional.of(customerView));
        when(customerMapper.toGetCustomerByDniResponse(any())).thenReturn(getCustomerInfoResponse);

        var response = customerService.getCustomerByDocument(TestUtils.DOCUMENT_TYPE, TestUtils.DOCUMENT_NUMBER);

        assertNotNull(response);
        verify(customerRepository, times(1)).findByDocumentTypeAndDocumentNumber(any(), any());
    }

    @Test
    void testGetCustomerByDocumentNotFound() {
        when(customerRepository.findByDocumentTypeAndDocumentNumber(any(), any())).thenReturn(Optional.empty());

        assertThrows(CustomerException.class, () -> customerService.getCustomerByDocument(TestUtils.DOCUMENT_TYPE, TestUtils.DOCUMENT_NUMBER));
        verify(customerRepository, times(1)).findByDocumentTypeAndDocumentNumber(any(), any());
    }*/
}
