package com.claro.customer.service.impl;

import com.claro.common.claro.dto.response.Response;
import com.claro.customer.client.ConfigurationManagerClient;
import com.claro.customer.dto.customer.CustomerDto;
import com.claro.customer.exception.CustomerException;
import com.claro.customer.mapper.CustomerMapper;
import com.claro.customer.projection.CustomerView;
import com.claro.customer.repository.CustomerRepository;
import com.claro.customer.utils.TestUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static com.claro.customer.utils.TestUtils.CUSTOMER_ID;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CustomerServiceImplTest {

    @Mock
    private CustomerRepository customerRepository;

    @Mock
    private CustomerMapper customerMapper;

    @Mock
    private ConfigurationManagerClient configurationManagerClient;

    @InjectMocks
    private CustomerServiceImpl customerService;

    @Mock
    private CustomerView customerView;
    private CustomerDto customerDto;
    private Response<CustomerDto> getCustomerInfoResponse;

    @BeforeEach
    void setUp() {
        customerDto = TestUtils.buildCustomerDto();
        getCustomerInfoResponse = TestUtils.buildGetCustomerInfoResponse();
    }

    @Test
    void testGetCustomerByIdSuccess() {
        when(customerRepository.findByCustomerId(any())).thenReturn(Optional.of(customerView));
        when(customerMapper.toCustomerDto(any())).thenReturn(customerDto);
        when(customerMapper.toGetCustomerInfoResponse(any())).thenReturn(getCustomerInfoResponse);

        var response = customerService.getCustomerById(CUSTOMER_ID);

        assertNotNull(response);
        verify(customerRepository, times(1)).findByCustomerId(any());
    }

    @Test
    void testGetCustomerByIdNotFound() {
        when(customerRepository.findByCustomerId(any())).thenReturn(Optional.empty());

        assertThrows(CustomerException.class, () -> customerService.getCustomerById(TestUtils.ID));
        verify(customerRepository, times(1)).findByCustomerId(any());
    }

    @Test
    void testGetAllCustomersInfo() {
        when(configurationManagerClient.getResponseFromEquivalence(any(), any()))
                .thenReturn(TestUtils.buildEquivalenceResponse());
        when(customerRepository.findByDocumentTypeAndDocumentNumber(any(), any()))
                .thenReturn(List.of(customerView));

        when(customerMapper.toGetCustomersByDniResponse(any()))
                .thenReturn(TestUtils.buildGetListCustomerInfoResponse());

        var response = customerService.getCustomerByDocument(TestUtils.DOCUMENT_TYPE, TestUtils.DOCUMENT_NUMBER);

        assertNotNull(response);
        verify(customerRepository, times(1)).findByDocumentTypeAndDocumentNumber(any(), any());
    }

    @Test
    void testGetCustomerByDocumentSuccess() {
        when(configurationManagerClient.getResponseFromEquivalence(any(), any()))
                .thenReturn(TestUtils.buildEquivalenceResponse());
        when(customerRepository.findByDocumentTypeAndDocumentNumber(any(), any()))
                .thenReturn(List.of(customerView));
        when(customerMapper.toGetCustomersByDniResponse(any()))
                .thenReturn(TestUtils.buildGetListCustomerInfoResponse());

        var response = customerService.getCustomerByDocument(TestUtils.DOCUMENT_TYPE, TestUtils.DOCUMENT_NUMBER);

        assertNotNull(response);
        verify(configurationManagerClient, times(1)).getResponseFromEquivalence(any(), any());
        verify(customerRepository, times(1)).findByDocumentTypeAndDocumentNumber(any(), any());
    }

    @Test
    void testGetCustomerByDocumentInvalidDocumentType() {
        when(configurationManagerClient.getResponseFromEquivalence(any(), any()))
                .thenReturn(null);

        assertThrows(CustomerException.class, () ->
                customerService.getCustomerByDocument(TestUtils.DOCUMENT_TYPE, TestUtils.DOCUMENT_NUMBER));
        verify(configurationManagerClient, times(1)).getResponseFromEquivalence(any(), any());
        verify(customerRepository, times(0)).findByDocumentTypeAndDocumentNumber(any(), any());
    }

    @Test
    void testGetCustomerByDocumentInvalidResponseData() {
        var invalidResponse = TestUtils.buildEquivalenceResponse();
        invalidResponse.setData(null);

        when(configurationManagerClient.getResponseFromEquivalence(any(), any()))
                .thenReturn(invalidResponse);

        assertThrows(CustomerException.class, () ->
                customerService.getCustomerByDocument(TestUtils.DOCUMENT_TYPE, TestUtils.DOCUMENT_NUMBER));
        verify(configurationManagerClient, times(1)).getResponseFromEquivalence(any(), any());
        verify(customerRepository, times(0)).findByDocumentTypeAndDocumentNumber(any(), any());
    }

}
