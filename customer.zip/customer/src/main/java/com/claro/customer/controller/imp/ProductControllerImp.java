package com.claro.customer.controller.imp;


import com.claro.common.claro.dto.response.PageResponse;
import com.claro.common.claro.exceptions.dto.ErrorDTO;
import com.claro.customer.controller.ProductController;
import com.claro.customer.model.dto.product.ProductDto;
import com.claro.customer.service.ProductService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

@Slf4j
@Tag(name = "Product")
@RestController
@RequiredArgsConstructor
@RequestMapping("${app.api}")
public class ProductControllerImp implements ProductController {

    private final ProductService service;

    /**
     * See {@link ProductController#getAllProducts(Integer, Integer, String, String, UUID)}
     */
    @Operation(operationId = "getAllProducts", summary = "Lista paginada de productos/líneas del cliente", responses = {@ApiResponse(responseCode = "200", description = "OK", useReturnTypeSchema = true),
            @ApiResponse(responseCode = "400", description = "Solicitud incorrecta", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))}),
            @ApiResponse(responseCode = "401", description = "No autorizado", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))}),
            @ApiResponse(responseCode = "404", description = "Recurso no encontrado", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))}),
            @ApiResponse(responseCode = "500", description = "ErrorDTO interno del servidor", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))})})
    @GetMapping(value = "/api/v1/products", produces = {"application/json"})
    @Override
    public ResponseEntity<PageResponse<List<ProductDto>>> getAllProducts(
            @Min(0) @Parameter(name = "page-number", description = "Número de página (primer página basada en 0)", in = ParameterIn.QUERY) @Valid @RequestParam(value = "page-number", required = false, defaultValue = "0") Integer pageNumber,
            @Min(1) @Parameter(name = "page-size", description = "Tamaño de página", in = ParameterIn.QUERY) @Valid @RequestParam(value = "page-size", required = false, defaultValue = "10") Integer pageSize,
            @Parameter(name = "line-number", description = "", in = ParameterIn.QUERY) @Valid @RequestParam(value = "line-number", required = false) String lineNumber,
            @Parameter(name = "customer-id", description = "", in = ParameterIn.QUERY) @Valid @RequestParam(value = "customer-id", required = false) String customerId,
            @Parameter(name = "x-request-id", description = "ID de correlación que se devuelve también en la respuesta.", in = ParameterIn.HEADER) @RequestHeader(value = "x-request-id", required = false) UUID xRequestId) {
        return new ResponseEntity<>(service.getAllProducts(lineNumber, customerId, PageRequest.of(pageNumber, pageSize)), HttpStatus.OK);
    }
}
