package com.claro.customer.dto.equivalence;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EquivalenceData {
    private String legacyDocTypeCode;
    private String crmDocTypeCode;
    private String description;
    private String abbreviation;
    private String legacyAppName;
}
