package com.claro.customer.client;

import com.claro.customer.configuration.restclient.RestClientCustom;
import com.claro.customer.dto.equivalence.EquivalenceResponse;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.hc.client5.http.HttpRoute;
import org.apache.hc.client5.http.config.ConnectionConfig;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.core5.function.Resolver;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.Map;

@Slf4j
@Component
public class ConfigurationManagerClient {

    private final RestClient restClient;
    private final Map<String, Resolver<HttpRoute, ConnectionConfig>> resolverMap;
    private final PoolingHttpClientConnectionManager connectionManager;

    private final int readTimeout;
    private final int connectTimeout;
    private final int maxPerRoute;
    private final String path;
    private final String host;

    public ConfigurationManagerClient(RestClient restClient, Map<String, Resolver<HttpRoute, ConnectionConfig>> resolverMap, PoolingHttpClientConnectionManager connectionManager,
                                      @Value("${configuration-manager.rest-client.read-timeout}") int readTimeout,
                                      @Value("${configuration-manager.rest-client.connect-timeout}") int connectTimeout,
                                      @Value("${configuration-manager.rest-client.max-per-route}") int maxPerRoute,
                                      @Value("${configuration-manager.path}") String path,
                                      @Value("${configuration-manager.url}") String host) {
        this.restClient = restClient;
        this.resolverMap = resolverMap;
        this.connectionManager = connectionManager;
        this.readTimeout = readTimeout;
        this.connectTimeout = connectTimeout;
        this.maxPerRoute = maxPerRoute;
        this.path = path;
        this.host = host;
    }

    @PostConstruct
    public void initialize() {
        RestClientCustom.chargeCustomRoute(host + path, maxPerRoute, readTimeout, connectTimeout, resolverMap, connectionManager);
    }

    public EquivalenceResponse getResponseFromEquivalence(String abbreviation, String app) {
        var response = restClient.get()
                .uri(uriBuilder -> {
                    var uri = uriBuilder
                            .path(path)
                            .queryParam("abbreviation", abbreviation)
                            .queryParam("app", app)
                            .build();
                    log.info(":::::: Configuration Management URI: {} ::::::", uri);
                    return uri;
                })
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .body(new ParameterizedTypeReference<EquivalenceResponse>() {
                });
        log.info(":::::: Configuration Management Response: {} ::::::", response);
        return response;
    }

}