package com.claro.customer.projection;

public interface CustomerView {

    String getId();

    String getExternalCode();

    String getDocumentType();

    String getDocumentNumber();

    String getAlias();

    String getBillingAddress();
}
