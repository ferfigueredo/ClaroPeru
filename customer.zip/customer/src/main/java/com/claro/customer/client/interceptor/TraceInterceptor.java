package com.claro.customer.client.interceptor;

import com.claro.customer.utils.ConstantUtils;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Slf4j
@Component
public class TraceInterceptor implements ClientHttpRequestInterceptor {

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
        request.getHeaders().setBearerAuth(MDC.get("token"));
        request.getHeaders().set(ConstantUtils.X_REQUEST_ID, MDC.get(ConstantUtils.X_REQUEST_ID));
        request.getHeaders().set(ConstantUtils.X_CORRELATION_ID, MDC.get(ConstantUtils.X_CORRELATION_ID));
        request.getHeaders().set(ConstantUtils.X_CLIENT_VERSION_ID, MDC.get(ConstantUtils.X_CLIENT_VERSION_ID));
        return execution.execute(request, body);
    }

}
