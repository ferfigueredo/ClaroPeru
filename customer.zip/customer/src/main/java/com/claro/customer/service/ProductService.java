package com.claro.customer.service;

import com.claro.common.claro.dto.response.PageResponse;
import com.claro.customer.model.dto.product.ProductDto;
import org.springframework.data.domain.PageRequest;

import java.util.List;

public interface ProductService {
    /**
     * Get all products by line number or customer id.
     * One of the parameters must be provided, but not both.
     *
     * @param lineNumber  Line number.
     * @param customerId  Customer id.
     * @param pageRequest Page request.
     * @return PageResponse with list of ProductDto.
     */
    PageResponse<List<ProductDto>> getAllProducts(String lineNumber, String customerId, PageRequest pageRequest);
}
