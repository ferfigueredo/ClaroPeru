package com.claro.customer.service.impl;

import com.claro.common.claro.dto.response.Response;
import com.claro.common.claro.exceptions.dto.ErrorDTO;
import com.claro.customer.exception.CustomerException;
import com.claro.customer.mapper.CustomerMapper;
import com.claro.customer.model.dto.customer.CustomerDto;
import com.claro.customer.projection.CustomerView;
import com.claro.customer.repository.CustomerRepository;
import com.claro.customer.service.CustomerService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.claro.customer.exception.CustomerExceptionHandler.SERVICE_ERROR;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;
    private final CustomerMapper customerMapper;

    /**
     * See {@link CustomerService#getCustomerById(String)}
     */
    @Override
    public Response<CustomerDto> getCustomerById(String id) {
        var customerDto = customerMapper.toCustomerDto(findCustomerById(id));
        return customerMapper.toGetCustomerInfoResponse(customerDto);
    }

    private CustomerView findCustomerById(String id) {
        log.info("::: Finding customer by id: {} :::", id);
        var customer = customerRepository.findByCustomerId(id).orElseThrow(() -> {
                    log.error("::: Customer with id {} not found :::", id);
            throw new CustomerException(ErrorDTO.builder().code(HttpStatus.NOT_FOUND.value()).status(HttpStatus.NOT_FOUND.name()).message(SERVICE_ERROR).detail("Customer not found").subType("IDF3").type("CustomerNotFoundException").build());
                }
        );
        log.info("::: Customer with id {} successfully found :::", id);
        return customer;
    }

    /**
     * See {@link CustomerService#getCustomerByDocument(Integer, String)}
     */
    @Override
    public Response<List<CustomerDto>> getCustomerByDocument(@Valid Integer documentType, String documentNumber) {
        var customers = getCustomerByDocumentTypeAndNumber(String.valueOf(documentType), documentNumber);
        return customerMapper.toGetCustomersByDniResponse(customers);
    }

    private List<CustomerView> getCustomerByDocumentTypeAndNumber(String documentType, String documentNumber) {
        log.info("::: Retrieving customers by documentType:{} and documentNumber: {} :::", documentType, documentNumber);
        List<CustomerView> customers;
        try {
            customers = customerRepository.findByDocumentTypeAndDocumentNumber(documentType, documentNumber);
        } catch (Exception e) {
            log.error("::: Customer with document type: {} and number: {} not found :::", documentType, documentNumber);
            throw new CustomerException(ErrorDTO.builder().code(HttpStatus.NOT_FOUND.value()).status(HttpStatus.NOT_FOUND.name()).message(SERVICE_ERROR).detail("Customer not found").subType("IDF3").type("CustomerNotFoundException").build());
        }
        log.info("::: Customer successfully retrieved :::");
        return customers;
    }
}
