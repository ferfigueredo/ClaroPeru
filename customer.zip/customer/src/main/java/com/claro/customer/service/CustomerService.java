package com.claro.customer.service;

import com.claro.common.claro.dto.response.Response;
import com.claro.customer.dto.customer.CustomerDto;

import java.util.List;

public interface CustomerService {

    /**
     * Get customer by id.
     *
     * @param id Customer id.
     * @return CustomerDto
     */
    Response<CustomerDto> getCustomerById(String id);

    /**
     * Get customer by document type and number.
     *
     * @param documentType   Document type.
     * @param documentNumber Document number.
     * @return CustomerDto
     */
    Response<List<CustomerDto>> getCustomerByDocument(String documentType, String documentNumber);
}
