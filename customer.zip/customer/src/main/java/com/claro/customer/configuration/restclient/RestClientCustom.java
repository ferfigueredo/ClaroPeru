package com.claro.customer.configuration.restclient;

import org.apache.hc.client5.http.HttpRoute;
import org.apache.hc.client5.http.config.ConnectionConfig;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.core5.function.Resolver;
import org.apache.hc.core5.http.HttpHost;
import org.apache.hc.core5.http.URIScheme;
import org.apache.hc.core5.util.Timeout;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import static java.util.Objects.nonNull;

@Configuration
public class RestClientCustom {
    
    private static final String PORTPATTERN = ":(\\d{2,4})";
    private static final Pattern PATTERN = Pattern.compile(PORTPATTERN);
    private static final int DEFAULTHTTPSPORT = 443;
    private static final int DEFAULTHTTPPORT = 80;
    
    /*
     * defaultConnectTimeout: Time out de conexion por default para cada ruta en caso de no existir alguna configuracion especifica.
     * defaultReadTimeout: Time out de lectura de respuesta. Tiempo maximo que se esperará una respuesta en caso de no existir alguna configuracion especifica.
     * maxTotal: maximo de conexiones simultaneas.
     * defaultMaxPerRoute: Maxima cantidad de conexiones simultaneas por ruta, en caso de no existir alguna configuracion especifica.
     */

    @Value("${rest-client.default.connect-timeout}")
    private int defaultConnectTimeout;
    
    @Value("${rest-client.default.read-timeout}")
    private int defaultReadTimeout;
    
    @Value("${rest-client.default.max.total}")
    private int maxTotal;
    
    @Value("${rest-client.default.max-per-route}")
    private int maxPerRoute;
        
    @Bean
    public Map<String, Resolver<HttpRoute, ConnectionConfig>> resolverMap() {
        return new HashMap<>();
    }

    @Bean
    public PoolingHttpClientConnectionManager getPooling() {
        var defaultConnectionConfig = ConnectionConfig.custom()
                .setConnectTimeout(Timeout.ofSeconds(defaultConnectTimeout))
                .setSocketTimeout(Timeout.ofSeconds(defaultReadTimeout))
                .build();
        var connectionManager = new PoolingHttpClientConnectionManager();
        connectionManager.setMaxTotal(maxTotal);
        connectionManager.setDefaultMaxPerRoute(maxPerRoute);
        connectionManager.setConnectionConfigResolver((HttpRoute route) -> {
            var keyRoute = searchKey(route.getTargetHost().getHostName(), resolverMap().keySet());
            return nonNull(keyRoute) ? resolverMap().get(keyRoute).resolve(route) : defaultConnectionConfig;
        });
        return connectionManager;
    }
    
    private static String searchKey(String target, Set<String> keys) {
        return keys.stream().filter(key -> key.contains(target)).findFirst().orElse(null);
    }
    
    /*
     * Este metodo permite custmomizar una configuracion especifica de max per route, readTimeOut y connectTimeout para un host determinado
     * En el caso de no ser custimzado se aplican los valor por default
     */
    public static void chargeCustomRoute(String address, int maxPerRoute, int readTimeOutMills, int connectTimeout,
            Map<String, Resolver<HttpRoute, ConnectionConfig>> resolverMap, PoolingHttpClientConnectionManager connectionManager) {
        Resolver<HttpRoute, ConnectionConfig> connectionConfigResolver = (HttpRoute route) -> 
                ConnectionConfig.custom()
                .setConnectTimeout(Timeout.ofSeconds(connectTimeout))
                .setSocketTimeout(Timeout.ofSeconds(readTimeOutMills))
                .build();
        var route = createRoute(address);
        resolverMap.put(route.getTargetHost().getHostName(), connectionConfigResolver);
        connectionManager.setMaxPerRoute(route, maxPerRoute);
    }
        
    private static HttpRoute createRoute(String address)  {
        var isHttps = address.contains(URIScheme.HTTPS.name());
        var matcher = PATTERN.matcher(address);
        var stringPort = matcher.matches() ? matcher.group(1) : null;
        var defaultPort = isHttps ? DEFAULTHTTPSPORT : DEFAULTHTTPPORT;
        var port = nonNull(stringPort) ? Integer.valueOf(stringPort.substring(1)) : defaultPort;
        var protocol = isHttps ? URIScheme.HTTPS.name() : URIScheme.HTTP.name();
        return new HttpRoute(new HttpHost(protocol, address, port));
    }
}
