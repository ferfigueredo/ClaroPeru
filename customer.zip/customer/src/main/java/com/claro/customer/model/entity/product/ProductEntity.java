package com.claro.customer.model.entity.product;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "CU_PRODUCTO")
public class ProductEntity {

    @Id
    @Column(name = "PRODUCTO_ID")
    private String id;

    @Column(name = "CODIGO_ORIGEN")
    private String originCode;

    @Column(name = "CODIGO_EXTERNO")
    private String externalCode;

    @Column(name = "FECHA_ACTIVACION")
    private LocalDateTime activationDate;

    @Column(name = "SISTEMA_ORIGEN")
    private String sourceSystem;

    @Column(name = "FECHA_REGISTRO")
    private LocalDateTime registrationDate;

    @Column(name = "USUARIO_REGISTRO")
    private String registeredBy;

    @Column(name = "FECHA_MODIFICACION")
    private LocalDateTime modificationDate;

    @Column(name = "USUARIO_MODIFICACION")
    private String modifiedBy;

    @Column(name = "ALIAS")
    private String alias;
}
