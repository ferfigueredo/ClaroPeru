package com.claro.customer.mapper;


import com.claro.common.claro.dto.response.Page;
import com.claro.common.claro.dto.response.PageResponse;
import com.claro.customer.model.dto.product.LineDto;
import com.claro.customer.model.dto.product.ProductDto;
import com.claro.customer.projection.ProductView;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ProductMapper {

    public static final String CODE_ORIGIN_REGEX = "^[^-]*-";

    public PageResponse<List<ProductDto>> toGetAllProductsResponse(org.springframework.data.domain.Page<ProductView> entity) {
        var products = entity.stream().map(this::customerProductPlanDTOtoProductDto).toList();
        var page = Page.builder().size(entity.getSize()).totalElements((int) entity.getTotalElements()).totalPages(entity.getTotalPages()).build();
        return PageResponse.<List<ProductDto>>builder().code(HttpStatus.OK.value()).message("Operación exitosa").data(products).page(page).build();
    }

    public ProductDto customerProductPlanDTOtoProductDto(ProductView entity) {
        var line = LineDto.builder().lineNumber(entity.getLineNumber()).planDescription(entity.getDescriptionPlan()).coId(entity.getProductOriginCode()).planCode(entity.getLinePlanCode()).type(entity.getLineType()).alias(entity.getAlias()).build();
        return ProductDto.builder().customerId(entity.getCustomerId().replaceFirst(CODE_ORIGIN_REGEX, "")).line(line).build();
    }
}
