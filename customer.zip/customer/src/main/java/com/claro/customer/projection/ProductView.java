package com.claro.customer.projection;

public interface ProductView {

    String getCustomerId();

    String getProductId();

    String getLineNumber();

    String getProductOriginCode();

    String getDescriptionPlan();

    String getLineType();

    String getLinePlanCode();

    String getAlias();

}
