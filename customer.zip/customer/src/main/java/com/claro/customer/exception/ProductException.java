package com.claro.customer.exception;

import com.claro.common.claro.exceptions.dto.ErrorDTO;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import static com.claro.customer.exception.CustomerExceptionHandler.ERROR;
import static com.claro.customer.exception.CustomerExceptionHandler.SERVICE_ERROR;

@Getter
@Setter
public class ProductException extends RuntimeException {

    private final ErrorDTO errorDTO;

    public ProductException(ErrorDTO errorDTO) {
        super(errorDTO.getMessage());
        this.errorDTO = errorDTO;
    }

    public ProductException() {
        super("Customer Exception");
        this.errorDTO = ErrorDTO.builder().code(HttpStatus.INTERNAL_SERVER_ERROR.value()).detail("There is an internal problem").message(SERVICE_ERROR).status(HttpStatus.INTERNAL_SERVER_ERROR.name()).subType(ERROR).build();
    }
}
