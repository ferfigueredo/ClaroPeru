package com.claro.customer.enums;

import com.claro.common.claro.exceptions.dto.ErrorDTO;
import com.claro.customer.exception.CustomerException;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

import static com.claro.customer.exception.CustomerExceptionHandler.SERVICE_ERROR;

@Getter
@Slf4j
public enum DocumentType {
    PASAPORTE(1),
    DNI(2),
    CARNET_EXTRANJERIA(4),
    CIP(5),
    RUC(6),
    CIE(7),
    CIRE(8),
    CPP(9),
    CTM(10);

    private static final Set<Integer> VALID_CODES =
            Arrays.stream(values())
                    .map(DocumentType::getCode)
                    .collect(Collectors.toUnmodifiableSet());

    private final Integer code;

    DocumentType(Integer code) {
        this.code = code;
    }

    public static void isValidOrThrows(Integer documentType) {
        if (!isValid(documentType)) {
            log.error("::: Invalid document-type: {} :::", documentType);
            throw new CustomerException(
                    ErrorDTO.builder().code(HttpStatus.BAD_REQUEST.value()).status(HttpStatus.BAD_REQUEST.name()).message(SERVICE_ERROR).detail("Invalid document type: %s".formatted(documentType)).subType("IDF6").type("InvalidDocumentType").build());

        }
    }

    public static boolean isValid(Integer code) {
        return code != null && VALID_CODES.contains(code);
    }


}
