package com.claro.customer.model.dto.customer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CustomerDto {

    private String id;

    private String externalCode;

    private String alias;

    private CustomerDocument document;

    private String billingAddress;


}
