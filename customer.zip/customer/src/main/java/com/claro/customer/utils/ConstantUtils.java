package com.claro.customer.utils;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ConstantUtils {

    public static final String X_REQUEST_ID = "x-request-id";
    public static final String X_CORRELATION_ID = "x-correlation-id";
    public static final String X_CLIENT_VERSION_ID = "x-client-version-id";

    public static final String FIND_CUSTOMER_BY_DOCUMENT_TYPE_AND_NUMBER = """
             SELECT
                  cli.CLIENTE_ID        AS id,
                  cli.CODIGO_EXTERNO    AS externalCode,
                  prt.NUMERO_DOCUMENTO  AS documentNumber,
                  prt.TIPO_DOCUMENTO    AS documentType,
                  prt.ALIAS             AS alias,
                  fac.DIRECCION_FACTURACION AS billingAddress
             FROM CU_PARTICIPANTE prt
                   JOIN CU_TIPO_DOCUMENTO tipdoc ON prt.TIPO_DOCUMENTO = tipdoc.TIPO_DOCUMENTO_ID
                   JOIN CU_CLIENTE cli ON prt.PARTICIPANTE_ID = cli.PARTICIPANTE_ID
                   LEFT JOIN CU_CUENTA_FACTURACION fac ON fac.CLIENTE_ID = cli.CLIENTE_ID
             WHERE
                   prt.NUMERO_DOCUMENTO = :documentNumber
                   AND prt.TIPO_DOCUMENTO = :documentType
            """;
    public static final String FIND_CUSTOMER_BY_ID = """
            SELECT
                 cli.CLIENTE_ID        AS id,
                 cli.CODIGO_EXTERNO    AS externalCode,
                 prt.NUMERO_DOCUMENTO  AS documentNumber,
                 prt.TIPO_DOCUMENTO    AS documentType,
                 prt.ALIAS             AS alias,
                 fac.DIRECCION_FACTURACION AS billingAddress
            FROM CU_PARTICIPANTE prt
                  JOIN CU_TIPO_DOCUMENTO tipdoc ON prt.TIPO_DOCUMENTO = tipdoc.TIPO_DOCUMENTO_ID
                  JOIN CU_CLIENTE cli ON prt.PARTICIPANTE_ID = cli.PARTICIPANTE_ID
                  LEFT JOIN CU_CUENTA_FACTURACION fac ON fac.CLIENTE_ID = cli.CLIENTE_ID
            WHERE
                  cli.CLIENTE_ID = :id
            """;

}
