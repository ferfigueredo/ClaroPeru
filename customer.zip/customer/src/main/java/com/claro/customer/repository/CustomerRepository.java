package com.claro.customer.repository;

import com.claro.customer.entity.CustomerEntity;
import com.claro.customer.projection.CustomerView;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

import static com.claro.customer.utils.ConstantUtils.FIND_CUSTOMER_BY_DOCUMENT_TYPE_AND_NUMBER;
import static com.claro.customer.utils.ConstantUtils.FIND_CUSTOMER_BY_ID;

public interface CustomerRepository extends JpaRepository<CustomerEntity, String> {
    /**
     * Find customer by id.
     *
     * @param id Customer id.
     * @return Optional of CustomerView.
     */
    @Query(value = FIND_CUSTOMER_BY_ID, nativeQuery = true)
    Optional<CustomerView> findByCustomerId(@Param("id") String id);

    /**
     * Find customer by document type and number.
     *
     * @param documentType   Document type.
     * @param documentNumber Document number.
     * @return Optional of CustomerView.
     */
    @Query(value = FIND_CUSTOMER_BY_DOCUMENT_TYPE_AND_NUMBER, nativeQuery = true)
    List<CustomerView> findByDocumentTypeAndDocumentNumber(@Param("documentType") String documentType, @Param("documentNumber") String documentNumber);

}
