package com.claro.customer.controller;

import com.claro.common.claro.dto.response.Response;
import com.claro.common.claro.exceptions.dto.ErrorDTO;
import com.claro.customer.dto.customer.CustomerDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

public interface CustomerController {

    /**
     * GET /api/v1/customers/documents : Obtener información filtrada de clientes
     * Devuelve los datos del/los cliente/s correspondientes al identificador proporcionado.
     *
     * @param documentType     Tipo de documento del cliente (requerido)
     * @param documentNumber   Número de documento del cliente (requerido)
     * @param xRequestId       ID de correlación para trazabilidad (requerido)
     * @param xCorrelationId   ID de correlación para trazabilidad (requerido)
     * @param xClientVersionId Versión del cliente (requerido)
     * @return Cliente encontrado exitosamente (código 200)
     * o Solicitud incorrecta (código 400)
     * o No autorizado (código 401)
     * o Recurso no encontrado (código 404)
     * o Error interno del servidor (código 500)
     */
    @Operation(
            operationId = "getCustomerByDocument",
            summary = "Obtener información filtrada de clientes",
            description = "Devuelve los datos del/los cliente/s correspondientes al identificador proporcionado.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Cliente encontrado exitosamente", useReturnTypeSchema = true),
                    @ApiResponse(responseCode = "400", description = "Solicitud incorrecta", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))}),
                    @ApiResponse(responseCode = "401", description = "No autorizado", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))}),
                    @ApiResponse(responseCode = "404", description = "Recurso no encontrado", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))}),
                    @ApiResponse(responseCode = "500", description = "ErrorDTO interno del servidor", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))})
            })
    @GetMapping(value = "/api/v1/customers/documents", produces = {"application/json"})
    ResponseEntity<Response<List<CustomerDto>>> getCustomerByDocumentTypeAndNumber(
            @Parameter(
                    name = "type",
                    description = "Tipo de documento del cliente",
                    in = ParameterIn.QUERY
            )
            @RequestParam(value = "type", required = true) String documentType,
            @Parameter(
                    name = "number",
                    description = "Número de documento del cliente",
                    in = ParameterIn.QUERY
            )
            @RequestParam(value = "number", required = true) String documentNumber,
            @Parameter(
                    name = "x-request-id",
                    description = "ID de correlación para trazabilidad",
                    required = true,
                    example = "3a16264f-fcd4-4b41-8a5d-61509395642e"
            )
            @RequestHeader("x-request-id") String xRequestId,
            @Parameter(
                    name = "x-correlation-id",
                    description = "ID de correlación para trazabilidad",
                    required = true,
                    example = "29db9cb2-f77a-478e-829f-3c6ba60acb76"
            )
            @RequestHeader("x-correlation-id") String xCorrelationId,
            @Parameter(
                    name = "x-client-version-id",
                    description = "Versión del cliente",
                    required = true,
                    example = "1.0.0"
            )
            @RequestHeader("x-client-version-id") String xClientVersionId

    );

    /**
     * GET /api/v1/customers/{id} : Consulta la información del cliente por id
     *
     * @param id               Identificador del cliente (requerido)
     * @param xRequestId       ID de correlación para trazabilidad (requerido)
     * @param xCorrelationId   ID de correlación para trazabilidad (requerido)
     * @param xClientVersionId Versión del cliente (requerido)
     * @return Cliente encontrado exitosamente (código 200)
     * o Solicitud incorrecta (código 400)
     * o No autorizado (código 401)
     * o Recurso no encontrado (código 404)
     * o Error interno del servidor (código 500)
     */
    @Operation(
            operationId = "getCustomerById",
            summary = "Consulta la información del cliente por id",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Cliente encontrado exitosamente", useReturnTypeSchema = true),
                    @ApiResponse(responseCode = "400", description = "Solicitud incorrecta", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))}),
                    @ApiResponse(responseCode = "401", description = "No autorizado", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))}),
                    @ApiResponse(responseCode = "404", description = "Recurso no encontrado", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))}),
                    @ApiResponse(responseCode = "500", description = "ErrorDTO interno del servidor", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))})
            })
    @GetMapping(value = "/api/v1/customers/{id}", produces = {"application/json"})
    ResponseEntity<Response<CustomerDto>> getCustomerById(
            @Parameter(
                    name = "id",
                    description = "",
                    required = true,
                    in = ParameterIn.PATH
            )
            @PathVariable("id") String id,
            @Parameter(
                    name = "x-request-id",
                    description = "ID de correlación para trazabilidad",
                    required = true,
                    example = "3a16264f-fcd4-4b41-8a5d-61509395642e"
            )
            @RequestHeader("x-request-id") String xRequestId,
            @Parameter(
                    name = "x-correlation-id",
                    description = "ID de correlación para trazabilidad",
                    required = true,
                    example = "29db9cb2-f77a-478e-829f-3c6ba60acb76"
            )
            @RequestHeader("x-correlation-id") String xCorrelationId,
            @Parameter(
                    name = "x-client-version-id",
                    description = "Versión del cliente",
                    required = true,
                    example = "1.0.0"
            )
            @RequestHeader("x-client-version-id") String xClientVersionId
    );

}
