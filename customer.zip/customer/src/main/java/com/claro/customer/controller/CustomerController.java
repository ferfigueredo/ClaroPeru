package com.claro.customer.controller;

import com.claro.common.claro.dto.response.Response;
import com.claro.common.claro.exceptions.dto.ErrorDTO;
import com.claro.customer.model.dto.customer.CustomerDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.UUID;

public interface CustomerController {

    /**
     * GET /v1/customers/documents : Obtener información filtrada de clientes
     * Devuelve los datos del/los cliente/s correspondientes al identificador proporcionado.
     *
     * @param documentType   Tipo de documento del cliente (optional)
     * @param documentNumber Número de documento del cliente (optional)
     * @param xRequestId     ID de correlación que se devuelve también en la respuesta. (optional)
     * @return Cliente encontrado exitosamente (status code 200)
     * or Solicitud incorrecta (status code 400)
     * or No autorizado (status code 401)
     * or Recurso no encontrado (status code 404)
     * or ErrorDTO interno del servidor (status code 500)
     */
    @Operation(operationId = "getCustomerByDocument", summary = "Obtener información filtrada de clientes", description = "Devuelve los datos del/los cliente/s correspondientes al identificador proporcionado.", responses = {
            @ApiResponse(responseCode = "200", description = "Cliente encontrado exitosamente", useReturnTypeSchema = true),
            @ApiResponse(responseCode = "400", description = "Solicitud incorrecta", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))}),
            @ApiResponse(responseCode = "401", description = "No autorizado", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))}),
            @ApiResponse(responseCode = "404", description = "Recurso no encontrado", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))}),
            @ApiResponse(responseCode = "500", description = "ErrorDTO interno del servidor", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))})})
    @GetMapping(value = "/api/v1/customers/documents", produces = {"application/json"})
    ResponseEntity<Response<List<CustomerDto>>> getCustomerByDocumentTypeAndNumber(@Parameter(name = "type", description = "Tipo de documento del cliente", in = ParameterIn.QUERY)
                                                                                   @Valid @RequestParam(value = "type", required = true) Integer documentType,
                                                                                   @Parameter(name = "number", description = "Número de documento del cliente", in = ParameterIn.QUERY)
                                                                                   @Valid @RequestParam(value = "number", required = true) String documentNumber,
                                                                                   @Parameter(name = "x-request-id", description = "ID de correlación que se devuelve también en la respuesta.", in = ParameterIn.HEADER)
                                                                                   @RequestHeader(value = "x-request-id", required = false)
                                                                                   /**
                                                                                    * GET /v1/customers/{id} : Consulta la información del cliente por id
                                                                                    *
                                                                                    * @param id         (required)
                                                                                    * @param xRequestId ID de correlación que se devuelve también en la respuesta. (optional)
                                                                                    * @return Cliente encontrado exitosamente (status code 200)
                                                                                    * or Solicitud incorrecta (status code 400)
                                                                                    * or No autorizado (status code 401)
                                                                                    * or Recurso no encontrado (status code 404)
                                                                                    * or ErrorDTO interno del servidor (status code 500)
                                                                                    */UUID xRequestId);

    /**
     * GET /v1/customers/{id} : Consulta la información del cliente por id
     *
     * @param id         (required)
     * @param xRequestId ID de correlación que se devuelve también en la respuesta. (optional)
     * @return Cliente encontrado exitosamente (status code 200)
     * or Solicitud incorrecta (status code 400)
     * or No autorizado (status code 401)
     * or Recurso no encontrado (status code 404)
     * or ErrorDTO interno del servidor (status code 500)
     */
    @Operation(operationId = "getCustomerById", summary = "Consulta la información del cliente por id", responses = {
            @ApiResponse(responseCode = "200", description = "Cliente encontrado exitosamente", useReturnTypeSchema = true),
            @ApiResponse(responseCode = "400", description = "Solicitud incorrecta", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))}),
            @ApiResponse(responseCode = "401", description = "No autorizado", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))}),
            @ApiResponse(responseCode = "404", description = "Recurso no encontrado", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))}),
            @ApiResponse(responseCode = "500", description = "ErrorDTO interno del servidor", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))})})
    @GetMapping(value = "/api/v1/customers/{id}", produces = {"application/json"})
    ResponseEntity<Response<CustomerDto>> getCustomerById(@Parameter(name = "id", description = "", required = true, in = ParameterIn.PATH) @PathVariable("id") String id,
                                                          @Parameter(name = "x-request-id", description = "ID de correlación que se devuelve también en la respuesta.", in = ParameterIn.HEADER) @RequestHeader(value = "x-request-id", required = false)
                                                          UUID xRequestId);
}
