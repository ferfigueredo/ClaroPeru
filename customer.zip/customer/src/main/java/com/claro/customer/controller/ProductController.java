package com.claro.customer.controller;

import com.claro.common.claro.dto.response.PageResponse;
import com.claro.common.claro.exceptions.dto.ErrorDTO;
import com.claro.customer.model.dto.product.ProductDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.UUID;

public interface ProductController {
    /**
     * GET /v1/products : Lista paginada de productos/líneas del cliente
     *
     * @param pageNumber Número de página (primer página basada en 0) (optional, default to 0)
     * @param pageSize   Tamaño de página (optional, default to 10)
     * @param lineNumber (optional)
     * @param customerId (optional)
     * @param xRequestId ID de correlación que se devuelve también en la respuesta. (optional)
     * @return OK (status code 200)
     * or Solicitud incorrecta (status code 400)
     * or No autorizado (status code 401)
     * or Recurso no encontrado (status code 404)
     * or ErrorDTO interno del servidor (status code 500)
     */
    @Operation(operationId = "getAllProducts", summary = "Lista paginada de productos/líneas del cliente", responses = {@ApiResponse(responseCode = "200", description = "OK", useReturnTypeSchema = true),
            @ApiResponse(responseCode = "400", description = "Solicitud incorrecta", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))}),
            @ApiResponse(responseCode = "401", description = "No autorizado", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))}),
            @ApiResponse(responseCode = "404", description = "Recurso no encontrado", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))}),
            @ApiResponse(responseCode = "500", description = "ErrorDTO interno del servidor", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))})})
    @GetMapping(value = "/api/v1/products", produces = {"application/json"})
    ResponseEntity<PageResponse<List<ProductDto>>> getAllProducts(
            @Min(0) @Parameter(name = "page-number", description = "Número de página (primer página basada en 0)", in = ParameterIn.QUERY) @Valid @RequestParam(value = "page-number", required = false, defaultValue = "0") Integer pageNumber,
            @Min(1) @Parameter(name = "page-size", description = "Tamaño de página", in = ParameterIn.QUERY) @Valid @RequestParam(value = "page-size", required = false, defaultValue = "10") Integer pageSize,
            @Parameter(name = "line-number", description = "", in = ParameterIn.QUERY) @Valid @RequestParam(value = "line-number", required = false) String lineNumber,
            @Parameter(name = "customer-id", description = "", in = ParameterIn.QUERY) @Valid @RequestParam(value = "customer-id", required = false) String customerId,
            @Parameter(name = "x-request-id", description = "ID de correlación que se devuelve también en la respuesta.", in = ParameterIn.HEADER) @RequestHeader(value = "x-request-id", required = false) UUID xRequestId);
}
