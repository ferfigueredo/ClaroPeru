package com.claro.customer.mapper;


import com.claro.common.claro.dto.response.Response;
import com.claro.customer.dto.customer.CustomerDocument;
import com.claro.customer.dto.customer.CustomerDto;
import com.claro.customer.projection.CustomerView;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CustomerMapper {
    public Response<CustomerDto> toGetCustomerInfoResponse(CustomerDto data) {
        return Response.<CustomerDto>builder().code(HttpStatus.OK.value()).message("Operación exitosa").data(data).build();
    }

    public CustomerDto toCustomerDto(CustomerView entity) {
        var document = CustomerDocument.builder().type(entity.getDocumentType()).number(entity.getDocumentNumber()).build();
        return CustomerDto.builder().id(entity.getId()).externalCode(entity.getExternalCode()).document(document).alias(entity.getAlias()).billingAddress(entity.getBillingAddress()).build();
    }

    public Response<List<CustomerDto>> toGetCustomersByDniResponse(List<CustomerView> entities) {
        List<CustomerDto> dtos = entities.stream()
                .map(this::toCustomerDto)
                .toList();
        return Response.<List<CustomerDto>>builder()
                .code(HttpStatus.OK.value())
                .message("Operación exitosa")
                .data(dtos)
                .build();
    }

}
