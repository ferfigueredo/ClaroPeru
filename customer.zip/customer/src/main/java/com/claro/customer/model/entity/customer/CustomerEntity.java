package com.claro.customer.model.entity.customer;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "CU_CLIENTE")
public class CustomerEntity {

    @Id
    @Column(name = "CLIENTE_ID")
    private String id;

    @Column(name = "CODIGO_ORIGEN")
    private String originCode;

    @Column(name = "PARTICIPANTE_ID")
    private Integer participantId;

    @Column(name = "CODIGO_EXTERNO")
    private String externalCode;

    @Column(name = "CLIENTE_ASOCIADO_ID")
    private String associatedCustomerId;

    @Column(name = "ESTADO")
    private Integer status;

    @Column(name = "FECHA_ACTIVACION")
    private LocalDateTime activationDate;

    @Column(name = "SISTEMA_ORIGEN")
    private String sourceSystem;

    @Column(name = "FECHA_REGISTRO")
    private LocalDateTime registrationDate;

    @Column(name = "USUARIO_REGISTRO")
    private String registeredBy;

    @Column(name = "FECHA_MODIFICACION")
    private LocalDateTime modificationDate;

    @Column(name = "USUARIO_MODIFICACION")
    private String modifiedBy;

    @Column(name = "LIMITE_CREDITO")
    private Double creditLimit;

    @Column(name = "SALDO_LIMITE_CREDITO")
    private Double creditLimitBalance;

}
