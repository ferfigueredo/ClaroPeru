package com.claro.customer.controller.imp;

import com.claro.common.claro.dto.response.Response;
import com.claro.customer.controller.CustomerController;
import com.claro.customer.dto.customer.CustomerDto;
import com.claro.customer.service.CustomerService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@Tag(name = "Customer")
@RestController
@RequiredArgsConstructor
@RequestMapping("${app.api}")
public class CustomerControllerImp implements CustomerController {

    private final CustomerService service;

    /**
     * {@inheritDoc}
     */
    @Override
    public ResponseEntity<Response<List<CustomerDto>>> getCustomerByDocumentTypeAndNumber(String documentType, String documentNumber, String xRequestId, String xCorrelationId, String xClientVersionId) {
        return new ResponseEntity<>(service.getCustomerByDocument(documentType, documentNumber), HttpStatus.OK);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ResponseEntity<Response<CustomerDto>> getCustomerById(String id, String xRequestId, String xCorrelationId, String xClientVersionId) {
        return new ResponseEntity<>(service.getCustomerById(id), HttpStatus.OK);
    }

}
