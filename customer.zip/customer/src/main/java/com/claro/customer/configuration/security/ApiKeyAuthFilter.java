package com.claro.customer.configuration.security;

import com.claro.common.claro.exceptions.dto.ErrorDTO;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;

import java.io.IOException;

import static com.claro.customer.exception.CustomerExceptionHandler.SERVICE_ERROR;

@RequiredArgsConstructor
public class ApiKeyAuthFilter implements Filter {

    private final String apiKeyHeader;
    private final String apiKeyValue;

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        String providedApiKey = httpRequest.getHeader(this.apiKeyHeader);

        if (providedApiKey != null && providedApiKey.equals(this.apiKeyValue)) {
            chain.doFilter(request, response);
        } else {
            var errorResponse = ErrorDTO.builder()
                    .code(HttpStatus.UNAUTHORIZED.value())
                    .detail("Invalid or missing API Key")
                    .message(SERVICE_ERROR)
                    .status(HttpStatus.UNAUTHORIZED.name())
                    .subType("IDF1")
                    .build();

            httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            httpResponse.setContentType("application/json");
            new ObjectMapper().writeValue(httpResponse.getWriter(), errorResponse);
        }
    }
}
