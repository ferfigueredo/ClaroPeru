-- Create table
create table PERU.CU_CLIENTE
(
  cliente_id           VARCHAR2(20) not null,
  codigo_origen        VARCHAR2(30) not null,
  participante_id      INTEGER,
  codigo_externo       VARCHAR2(20),
  cliente_asociado_id  VARCHAR2(20),
  estado               INTEGER,
  fecha_activacion     DATE,
  sistema_origen       VARCHAR2(20),
  fecha_registro       DATE default SYSDATE,
  usuario_registro     VARCHAR2(25) default USER,
  fecha_modificacion   DATE default SYSDATE,
  usuario_modificacion VARCHAR2(25) default USER,
  limite_credito       FLOAT,
  saldo_limite_credito FLOAT
)
-- Create/Recreate indexes 
create index PERU.IDX_CU_CLIENTE_1 on PERU.CU_CLIENTE (PARTICIPANTE_ID);
create index PERU.IDX_CU_CLIENTE_2 on PERU.CU_CLIENTE (SISTEMA_ORIGEN);
create index PERU.IDX_CU_CLIENTE_3 on PERU.CU_CLIENTE (CODIGO_ORIGEN);
create index PERU.IDX_CU_CLIENTE_4 on PERU.CU_CLIENTE (CODIGO_ORIGEN, SISTEMA_ORIGEN);
create index PERU.IDX_CU_CLIENTE_5 on PERU.CU_CLIENTE (FECHA_MODIFICACION, SISTEMA_ORIGEN);
create index PERU.IDX_CU_CLIENTE_6 on PERU.CU_CLIENTE (CLIENTE_ID, SISTEMA_ORIGEN);


-- Create/Recreate primary, unique and foreign key constraints 
alter table PERU.CU_CLIENTE
  add constraint XPKCU_CLIENTE primary key (CLIENTE_ID);
  
alter table PERU.CU_CLIENTE
  add constraint CU_CLIENTE_FK_PARTICIPANTE foreign key (PARTICIPANTE_ID)
  references PERU.CU_PARTICIPANTE (PARTICIPANTE_ID) on delete set null;
-- Grant/Revoke object privileges 
grant select, insert, update, delete on PERU.CU_CLIENTE to USER_READER;
