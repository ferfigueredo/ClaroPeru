create table PERU.CU_PRODUCTO_ESTADO
(
  PRODUCTO_ID           VARCHAR2(25) not null,
  ESTADO_ID             INTEGER not null,
  SECUENCIAL            VARCHAR2(20),
  ESTADO                VARCHAR2(20),
  FECHA_INICIO          DATE,
  FECHA_FIN             DATE,
  FLAG_ACTIVO           INTEGER default 1,
  SISTEMA_ORIGEN        VARCHAR2(25),
  FECHA_REGISTRO        DATE  default SYSDATE,
  USUARIO_REGISTRO      VARCHAR2(25) default USER,
  FECHA_MODIFICACION    DATE  default SYSDATE,
  USUARIO_MODIFICACION  VARCHAR2(25) default USER,
  MOTIVO_ID             NUMBER
);


