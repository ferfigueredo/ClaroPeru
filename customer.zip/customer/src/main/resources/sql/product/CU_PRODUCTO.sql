-- Create table
create table PERU.CU_PRODUCTO
(
  producto_id              VARCHAR2(25) not null,
  codigo_origen            VARCHAR2(30) not null,
  codigo_externo           VARCHAR2(25),
  fecha_activacion         DATE,
  fecha_desactivacion      DATE,
  sistema_origen           VARCHAR2(25),
  fecha_registro           DATE default SYSDATE,
  usuario_registro         VARCHAR2(25) default USER,
  fecha_modificacion       DATE default SYSDATE,
  usuario_modificacion     VARCHAR2(25) default USER,
  codigo_sucursal          VARCHAR2(25),
  producto_id_anterior     VARCHAR2(25),
  fecha_activacion_inicial DATE,
  producto_id_rel          VARCHAR2(25)
);
-- Create/Recreate indexes 
create index PERU.IDX_CU_PRODUCTO_1 on PERU.CU_PRODUCTO (SISTEMA_ORIGEN);
create index PERU.IDX_CU_PRODUCTO_2 on PERU.CU_PRODUCTO (CODIGO_ORIGEN);
create index PERU.IDX_CU_PRODUCTO_3 on PERU.CU_PRODUCTO (FECHA_ACTIVACION);
create index PERU.IDX_CU_PRODUCTO_4 on PERU.CU_PRODUCTO (CODIGO_ORIGEN, SISTEMA_ORIGEN);
create index PERU.IDX_CU_PRODUCTO_5 on PERU.CU_PRODUCTO (SISTEMA_ORIGEN, NVL(FECHA_DESACTIVACION,TO_DATE(' 9999-12-31 00:00:00', 'syyyy-mm-dd hh24:mi:ss')));
create index PERU.IDX_CU_PRODUCTO_6 on PERU.CU_PRODUCTO (SISTEMA_ORIGEN, FECHA_MODIFICACION);
create index PERU.IDX_CU_PRODUCTO_7 on PERU.CU_PRODUCTO (FECHA_ACTIVACION, SISTEMA_ORIGEN);

-- Create/Recreate primary, unique and foreign key constraints 
alter table PERU.CU_PRODUCTO
  add constraint XPKCU_PRODUCTO1 primary key (PRODUCTO_ID);