-- Create table
create table PERU.CU_ESTADOS_PRODUCTO
(
  estado_id            INTEGER not null,
  descripcion          VARCHAR2(20),
  flag_activo          INTEGER default 1,
  sistema_origen       VARCHAR2(25),
  fecha_registro       DATE default SYSDATE,
  usuario_registro     VARCHAR2(25) default USER,
  fecha_modificacion   DATE default SYSDATE,
  usuario_modificacion VARCHAR2(25) default USER
);
-- Grant/Revoke object privileges 
grant select on PERU.CU_ESTADOS_PRODUCTO to USER_READER;
