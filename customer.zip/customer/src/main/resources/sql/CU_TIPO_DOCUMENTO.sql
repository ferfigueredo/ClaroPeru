-- Create table
create table PERU.CU_TIPO_DOCUMENTO
(
  tipo_documento_id    INTEGER not null,
  nombre               VARCHAR2(50),
  descripcion          VARCHAR2(50),
  flag_activo          INTEGER default 1,
  fecha_creacion       DATE default SYSDATE,
  usuario_creacion     VARCHAR2(25) default USER,
  fecha_modificacion   DATE default SYSDATE,
  usuario_modificacion VARCHAR2(25) default USER
);
-- Create/Recreate primary, unique and foreign key constraints 
alter table PERU.CU_TIPO_DOCUMENTO
add constraint XPKCU_TIPO_DOCUMENTO primary key (TIPO_DOCUMENTO_ID);