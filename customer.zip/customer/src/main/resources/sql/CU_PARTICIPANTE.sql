-- Create table
create table PERU.CU_PARTICIPANTE
(
  participante_id          INTEGER not null,
  codigo_cliente_unico     VARCHAR2(25) not null,
  estado_id                INTEGER,
  tipo_persona             VARCHAR2(2),
  nombres                  VARCHAR2(150),
  apellido_paterno         VARCHAR2(150),
  apellido_materno         VARCHAR2(150),
  razon_social             VARCHAR2(250),
  nombre_comercial         VARCHAR2(250),
  codigo_aplicacion        VARCHAR2(100),
  fecha_nacimiento         DATE,
  pais_nacimiento          VARCHAR2(150),
  estado_civil_id          INTEGER,
  sexo                     VARCHAR2(2),
  tipo_documento           INTEGER not null,
  numero_documento         VARCHAR2(20) not null,
  fecha_creacion_prospecto DATE,
  fecha_creacion_cliente   DATE,
  clasificacion_mercado    VARCHAR2(20),
  sector_comercial         INTEGER,
  segmento_comercial       INTEGER,
  correo_electronico       VARCHAR2(100),
  departamento             VARCHAR2(150),
  provincia                VARCHAR2(250),
  distrito                 VARCHAR2(250),
  urbanizacion             VARCHAR2(250),
  referencia_direccion     VARCHAR2(500),
  codigo_postal            VARCHAR2(20),
  pais_legal               VARCHAR2(150),
  direccion                VARCHAR2(500),
  ubigeo                   VARCHAR2(20),
  nacionalidad_id          INTEGER,
  telefono_referencia      VARCHAR2(50),
  telefono_referencia_2    VARCHAR2(50),
  sistema_origen           VARCHAR2(25),
  fecha_registro           DATE default SYSDATE,
  usuario_registro         VARCHAR2(25) default USER,
  fecha_modificacion       DATE default SYSDATE,
  usuario_modificacion     VARCHAR2(25) default USER,
  limite_credito           FLOAT,
  saldo_limite_credito     FLOAT
);

-- Create/Recreate indexes 
create index PERU.IDX_CU_PARTICIPANTE_1 on PERU.CU_PARTICIPANTE (NUMERO_DOCUMENTO);
create index PERU.IDX_CU_PARTICIPANTE_10 on PERU.CU_PARTICIPANTE (FECHA_MODIFICACION);
create index PERU.IDX_CU_PARTICIPANTE_11 on PERU.CU_PARTICIPANTE (FECHA_REGISTRO);
create index PERU.IDX_CU_PARTICIPANTE_2 on PERU.CU_PARTICIPANTE (TIPO_DOCUMENTO, NUMERO_DOCUMENTO);
create index PERU.IDX_CU_PARTICIPANTE_3 on PERU.CU_PARTICIPANTE (NOMBRES);
create index PERU.IDX_CU_PARTICIPANTE_4 on PERU.CU_PARTICIPANTE (APELLIDO_PATERNO);
create index PERU.IDX_CU_PARTICIPANTE_5 on PERU.CU_PARTICIPANTE (APELLIDO_MATERNO);
create index PERU.IDX_CU_PARTICIPANTE_8 on PERU.CU_PARTICIPANTE (RAZON_SOCIAL);
create index PERU.IDX_CU_PARTICIPANTE_9 on PERU.CU_PARTICIPANTE (UPPER(RAZON_SOCIAL));

-- Create/Recreate primary, unique and foreign key constraints 
alter table PERU.CU_PARTICIPANTE
  add constraint XPKCU_PARTICIPANTE primary key (PARTICIPANTE_ID);
alter table PERU.CU_PARTICIPANTE
  add constraint XAK1CU_PARTICIPANTE unique (CODIGO_CLIENTE_UNICO);
alter table PERU.CU_PARTICIPANTE
  add constraint CU_PARTICIPANTE_FK_CU_NACIONALIDAD foreign key (NACIONALIDAD_ID)
  references PERU.CU_NACIONALIDAD (NACIONALIDAD_ID) on delete set null;
alter table PERU.CU_PARTICIPANTE
  add constraint CU_PARTICIPANTE_FK_ESTADO_CIVIL foreign key (ESTADO_CIVIL_ID)
  references PERU.CU_ESTADO_CIVIL (ESTADO_CIVIL_ID) on delete set null;
alter table PERU.CU_PARTICIPANTE
  add constraint CU_PARTICIPANTE_FK_TIPO_DOCUMENTO foreign key (TIPO_DOCUMENTO)
  references PERU.CU_TIPO_DOCUMENTO (TIPO_DOCUMENTO_ID) on delete set null;