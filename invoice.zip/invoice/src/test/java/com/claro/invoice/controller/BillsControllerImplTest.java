package com.claro.invoice.controller;

import com.claro.common.claro.dto.response.Response;
import com.claro.invoice.controller.impl.BillsControllerImpl;
import com.claro.invoice.dto.request.BillSearchCriteria;
import com.claro.invoice.dto.response.BillsDetailResponse;
import com.claro.invoice.service.BillsService;
import com.claro.invoice.validation.DocumentTypeAndLineNumberValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static com.claro.invoice.utils.TestUtils.DEFAULT_HISTORY_MONTHS;
import static com.claro.invoice.utils.TestUtils.DEFAULT_RECORDS_COUNT;
import static com.claro.invoice.utils.TestUtils.INVOICE_SUCCESS_CODE;
import static com.claro.invoice.utils.TestUtils.INVOICE_SUCCESS_MESSAGE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class BillsControllerImplTest {

    private BillsControllerImpl billsControllerImpl;
    private BillsService billsService;
    private DocumentTypeAndLineNumberValidator validator;

    @BeforeEach
    void setUp() {
        this.billsService = mock(BillsService.class);
        this.validator = mock(DocumentTypeAndLineNumberValidator.class);
        this.billsControllerImpl = new BillsControllerImpl(this.billsService, this.validator);
    }

    @Test
    void invoiceApiV1BillsGetShouldReturnResponseFromService() {
        String xCorrelationId = "123-456-789";
        String xRequestId = "123-456-789";
        String xClientVersionId = "1.0.0";
        BillSearchCriteria billSearchCriteria = BillSearchCriteria.builder()
                .lineNumber("12345678")
                .historyMonths(DEFAULT_HISTORY_MONTHS)
                .pendingRecordsCount(DEFAULT_RECORDS_COUNT)
                .historicalRecordsCount(DEFAULT_RECORDS_COUNT)
                .build();

        var mockResponse = Response.<BillsDetailResponse>builder()
                .code(INVOICE_SUCCESS_CODE)
                .message(INVOICE_SUCCESS_MESSAGE)
                .build();
        doNothing().when(this.validator).validate(anyString(), anyString(), anyString());
        when(this.billsService.findBills(anyString(), anyString(), anyString(), anyInt(), anyInt(), anyInt()))
                .thenReturn(mockResponse);

        var response = this.billsControllerImpl.getBills(billSearchCriteria, xCorrelationId, xRequestId, xClientVersionId);

        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

}

