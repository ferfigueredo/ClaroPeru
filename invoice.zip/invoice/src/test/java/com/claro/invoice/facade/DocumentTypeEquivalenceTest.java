package com.claro.invoice.facade;

import com.claro.invoice.client.ConfigurationManagerClient;
import com.claro.invoice.exception.DocumentTypeInvalidException;
import com.claro.invoice.utils.TestUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DocumentTypeEquivalenceTest {

    @Mock
    private ConfigurationManagerClient configurationManagerClient;

    @InjectMocks
    private DocumentTypeEquivalence documentTypeEquivalence;

    @Test
    void getCodeSuccess() {
        when(configurationManagerClient.getResponseFromEquivalence(any(), any()))
                .thenReturn(TestUtils.buildEquivalenceResponse());
        var result = documentTypeEquivalence.getCode("DNI");
        Assertions.assertEquals(TestUtils.buildEquivalenceResponse().getData().getCrmDocTypeCode(), result);
    }

    @Test
    void getCodeThrowsExceptionWhenResponseIsNull() {
        when(configurationManagerClient.getResponseFromEquivalence(any(), any()))
                .thenReturn(null);
        Assertions.assertThrows(
                DocumentTypeInvalidException.class,
                () -> documentTypeEquivalence.getCode("DNI")
        );
    }

    @Test
    void getCodeThrowsExceptionWhenResponseCodeIsNotOk() {
        var response = TestUtils.buildEquivalenceResponse();
        response.setCode(400); // BAD_REQUEST
        when(configurationManagerClient.getResponseFromEquivalence(any(), any()))
                .thenReturn(response);
        Assertions.assertThrows(
                DocumentTypeInvalidException.class,
                () -> documentTypeEquivalence.getCode("DNI")
        );
    }

    @Test
    void getCodeThrowsExceptionWhenResponseDataIsNull() {
        var response = TestUtils.buildEquivalenceResponse();
        response.setData(null);
        when(configurationManagerClient.getResponseFromEquivalence(any(), any()))
                .thenReturn(response);
        Assertions.assertThrows(
                DocumentTypeInvalidException.class,
                () -> documentTypeEquivalence.getCode("DNI")
        );
    }

}
