package com.claro.invoice.utils;

import com.claro.invoice.dto.equivalence.EquivalenceData;
import com.claro.invoice.dto.equivalence.EquivalenceResponse;

public class TestUtils {

    public static final Integer DEFAULT_HISTORY_MONTHS = 6;
    public static final Integer DEFAULT_RECORDS_COUNT = 10;
    public static final Integer INVOICE_SUCCESS_CODE = 200;
    public static final String INVOICE_SUCCESS_MESSAGE = "Operación exitosa";

    public static final Integer HISTORY_MONTH = 3;

    public static final int DEFAULT_TIME_MILLISECONDS = 10000;

    public static EquivalenceResponse buildEquivalenceResponse() {
        return EquivalenceResponse.builder()
                .code(200)
                .message("Operación exitosa")
                .data(EquivalenceData.builder()
                        .legacyDocTypeCode("DNI")
                        .crmDocTypeCode("1")
                        .description("DOCUMENTO NACIONAL DE IDENTIDAD")
                        .abbreviation("DNI")
                        .legacyAppName("TIMPROD")
                        .build())
                .build();
    }

}
