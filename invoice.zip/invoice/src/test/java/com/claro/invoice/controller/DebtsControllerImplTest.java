package com.claro.invoice.controller;

import com.claro.common.claro.dto.response.Response;
import com.claro.invoice.controller.impl.DebtsControllerImpl;
import com.claro.invoice.dto.request.DebtSearchCriteria;
import com.claro.invoice.dto.response.TotalDebtResponse;
import com.claro.invoice.service.DebtsService;
import com.claro.invoice.validation.DocumentTypeAndLineNumberValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class DebtsControllerImplTest {

    private DebtsControllerImpl debtsControllerImpl;
    private DebtsService debtsService;
    private DocumentTypeAndLineNumberValidator validator;

    public static final Integer INVOICE_SUCCESS_CODE = 200;
    public static final String INVOICE_SUCCESS_MESSAGE = "Operación exitosa";

    @BeforeEach
    void setUp() {
        this.debtsService = mock(DebtsService.class);
        this.validator = mock(DocumentTypeAndLineNumberValidator.class);
        this.debtsControllerImpl = new DebtsControllerImpl(this.debtsService, this.validator);
    }

    @Test
    void invoiceApiV1DebtsGetShouldReturnResponseFromService() {
        String xCorrelationId = "123-456-789";
        String xRequestId = "123-456-789";
        String xClientVersionId = "1.0.0";
        DebtSearchCriteria debtSearchCriteria = DebtSearchCriteria.builder().lineNumber("12345").build();

        Response<TotalDebtResponse> mockDebtResponse = Response.<TotalDebtResponse>builder()
                .code(INVOICE_SUCCESS_CODE)
                .message(INVOICE_SUCCESS_MESSAGE)
                .build();
        when(this.debtsService.findTotalDebt(anyString(), anyString(), anyString()))
                .thenReturn(mockDebtResponse);

        var response = this.debtsControllerImpl.getDebts(debtSearchCriteria, xCorrelationId, xRequestId, xClientVersionId);

        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

}
