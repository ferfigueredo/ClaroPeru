package com.claro.invoice.service.impl;

import com.claro.common.claro.dto.response.Response;
import com.claro.invoice.dto.response.BillsDetailResponse;
import com.claro.invoice.facade.DocumentTypeEquivalence;
import com.claro.invoice.mapper.BillsResponsePageMapper;
import com.claro.invoice.model.BillDetail;
import com.claro.invoice.repository.DebtsDetailRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static com.claro.invoice.utils.TestUtils.DEFAULT_RECORDS_COUNT;
import static com.claro.invoice.utils.TestUtils.HISTORY_MONTH;
import static com.claro.invoice.utils.TestUtils.INVOICE_SUCCESS_CODE;
import static com.claro.invoice.utils.TestUtils.INVOICE_SUCCESS_MESSAGE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class BillsServiceImplTest {

    private BillsServiceImpl billsServiceImpl;
    private DebtsDetailRepository debtsDetailRepository;
    private DocumentTypeEquivalence documentTypeEquivalence;
    private BillsResponsePageMapper mapper;

    @BeforeEach
    void setUp() {
        this.debtsDetailRepository = mock(DebtsDetailRepository.class);
        this.mapper = mock(BillsResponsePageMapper.class);
        this.documentTypeEquivalence = mock(DocumentTypeEquivalence.class);
        this.billsServiceImpl = new BillsServiceImpl(this.documentTypeEquivalence, this.debtsDetailRepository, this.mapper);
    }

    @Test
    void findTotalDebtByLineNumberOrDocumentShouldCallFetchByLineNumber() {

        String lineNumber = "123456789";
        BillDetail billDetail = BillDetail.builder()
                .status("0")
                .message("Exito")
                .build();
        Response<BillsDetailResponse> responsePage = Response.<BillsDetailResponse>builder()
                .code(INVOICE_SUCCESS_CODE)
                .message(INVOICE_SUCCESS_MESSAGE)
                .build();

        when(this.debtsDetailRepository.fetchInvoiceDetailsByLineNumber(anyString(), anyInt(), anyInt(), anyInt())).thenReturn(billDetail);
        when(this.mapper.mapToBillsResponsePage(any())).thenReturn(responsePage);

        var result = billsServiceImpl.findBills(null, null, lineNumber, HISTORY_MONTH, DEFAULT_RECORDS_COUNT, DEFAULT_RECORDS_COUNT);

        assertEquals(INVOICE_SUCCESS_CODE, result.code());
        assertEquals(INVOICE_SUCCESS_MESSAGE, result.message());
    }

    @Test
    void findTotalDebtByLineNumberOrDocumentShouldCallFetchByDocument() {

        String documentType = "DNI";
        String documentNumber = "99999999";
        BillDetail billDetail = BillDetail.builder()
                .status("0")
                .message("Exito")
                .build();
        Response<BillsDetailResponse> responsePage = Response.<BillsDetailResponse>builder()
                .code(INVOICE_SUCCESS_CODE)
                .message(INVOICE_SUCCESS_MESSAGE)
                .build();

        when(this.documentTypeEquivalence.getCode(any())).thenReturn("1");
        when(this.debtsDetailRepository.fetchInvoiceDetailsByDocument(anyString(), anyString(), anyInt(), anyInt(), anyInt())).thenReturn(billDetail);
        when(this.mapper.mapToBillsResponsePage(any())).thenReturn(responsePage);

        var result = this.billsServiceImpl.findBills(documentType, documentNumber, null, HISTORY_MONTH, DEFAULT_RECORDS_COUNT, DEFAULT_RECORDS_COUNT);

        assertEquals(INVOICE_SUCCESS_CODE, result.code());
        assertEquals(INVOICE_SUCCESS_MESSAGE, result.message());
    }

}
