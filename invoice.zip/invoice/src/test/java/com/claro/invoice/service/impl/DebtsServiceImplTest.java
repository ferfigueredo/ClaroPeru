package com.claro.invoice.service.impl;

import com.claro.common.claro.dto.response.Response;
import com.claro.invoice.dto.response.TotalDebtResponse;
import com.claro.invoice.facade.DocumentTypeEquivalence;
import com.claro.invoice.mapper.DebtResponseMapper;
import com.claro.invoice.model.BillDetail;
import com.claro.invoice.repository.DebtsDetailRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class DebtsServiceImplTest {

    private DocumentTypeEquivalence documentTypeEquivalence;
    private DebtsServiceImpl debtsServiceImpl;
    private DebtsDetailRepository debtsDetailRepository;
    private DebtResponseMapper mapper;

    public static final Integer INVOICE_SUCCESS_CODE = 200;
    public static final String INVOICE_SUCCESS_MESSAGE = "Operación exitosa";

    @BeforeEach
    void setUp() {
        this.debtsDetailRepository = mock(DebtsDetailRepository.class);
        this.mapper = mock(DebtResponseMapper.class);
        this.documentTypeEquivalence = mock(DocumentTypeEquivalence.class);
        this.debtsServiceImpl = new DebtsServiceImpl(this.documentTypeEquivalence, this.debtsDetailRepository, this.mapper);
    }

    @Test
    void findTotalDebtByLineNumberOrDocumentShouldCallFetchByLineNumber() {
        String lineNumber = "1234567890";
        BillDetail billDetail = mock(BillDetail.class);
        Response<TotalDebtResponse> debtResponse = Response.<TotalDebtResponse>builder()
                .code(INVOICE_SUCCESS_CODE)
                .message(INVOICE_SUCCESS_MESSAGE)
                .build();

        when(this.debtsDetailRepository.fetchInvoiceDetailsByLineNumber(anyString(), anyInt(), anyInt(), anyInt())).thenReturn(billDetail);
        when(this.mapper.debtDetailToDebtResponse(any())).thenReturn(debtResponse);

        var result = this.debtsServiceImpl.findTotalDebt(null, null, lineNumber);

        assertEquals(INVOICE_SUCCESS_CODE, result.code());
        assertEquals(INVOICE_SUCCESS_MESSAGE, result.message());
    }

    @Test
    void findTotalDebtByLineNumberOrDocumentShouldCallFetchByDocument() {

        String documentType = "DNI";
        String documentNumber = "99999999";
        BillDetail billDetail = mock(BillDetail.class);
        Response<TotalDebtResponse> debtResponse = Response.<TotalDebtResponse>builder()
                .code(INVOICE_SUCCESS_CODE)
                .message(INVOICE_SUCCESS_MESSAGE)
                .build();

        when(this.documentTypeEquivalence.getCode(any())).thenReturn("1");
        when(this.debtsDetailRepository.fetchInvoiceDetailsByDocument(anyString(), anyString(), anyInt(), anyInt(), anyInt())).thenReturn(billDetail);
        when(this.mapper.debtDetailToDebtResponse(any())).thenReturn(debtResponse);

        var result = this.debtsServiceImpl.findTotalDebt(documentType, documentNumber, null);

        assertEquals(INVOICE_SUCCESS_CODE, result.code());
        assertEquals(INVOICE_SUCCESS_MESSAGE, result.message());

    }

}
