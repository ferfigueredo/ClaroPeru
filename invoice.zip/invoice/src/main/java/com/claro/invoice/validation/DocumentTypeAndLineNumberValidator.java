package com.claro.invoice.validation;

import com.claro.invoice.exception.InvalidParameterException;
import com.claro.invoice.exception.MutuallyExclusiveParametersException;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import static com.claro.invoice.utils.ConstantUtils.CODE_ERROR_IDF1;
import static com.claro.invoice.utils.ConstantUtils.CODE_ERROR_IDF5;

@Component
public class DocumentTypeAndLineNumberValidator {

    public void validate(String documentType, String documentNumber, String lineNumber) {
        boolean hasDocumentInfo = StringUtils.hasText(documentType) && StringUtils.hasText(documentNumber);
        boolean hasLineNumber = StringUtils.hasText(lineNumber);

        if (hasDocumentInfo && hasLineNumber) {
            throw new MutuallyExclusiveParametersException("Provide either document info (type and number) or line number, but not both.", CODE_ERROR_IDF5);
        }

        if (!hasDocumentInfo && !hasLineNumber) {
            throw new InvalidParameterException("You must provide either document info (type and number) or a line number.", CODE_ERROR_IDF1);
        }

        if (StringUtils.hasText(documentType) && !StringUtils.hasText(documentNumber)) {
            throw new InvalidParameterException("Document number is required when document type is provided.", CODE_ERROR_IDF1);
        }

        if (!StringUtils.hasText(documentType) && StringUtils.hasText(documentNumber)) {
            throw new InvalidParameterException("Document type is required when document number is provided.", CODE_ERROR_IDF1);
        }

    }

}
