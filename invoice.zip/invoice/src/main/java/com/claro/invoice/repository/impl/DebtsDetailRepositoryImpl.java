package com.claro.invoice.repository.impl;

import com.claro.invoice.exception.StoredProcedureException;
import com.claro.invoice.model.BillDetail;
import com.claro.invoice.model.HistoricalDocument;
import com.claro.invoice.model.PendingDocument;
import com.claro.invoice.repository.DebtsDetailRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static com.claro.invoice.utils.ConstantUtils.CODE_ERROR_IDF3;
import static com.claro.invoice.utils.ConstantUtils.EMISION;
import static com.claro.invoice.utils.ConstantUtils.MESSAGE_OK;
import static com.claro.invoice.utils.ConstantUtils.PN_CANT_REG_HISTORICO;
import static com.claro.invoice.utils.ConstantUtils.PN_CANT_REG_POR_PAGAR;
import static com.claro.invoice.utils.ConstantUtils.STATUS_OK;
import static com.claro.invoice.utils.ConstantUtils.XV_MESSAGE;
import static com.claro.invoice.utils.ConstantUtils.XV_STATUS;

@Repository
public class DebtsDetailRepositoryImpl implements DebtsDetailRepository {

    private final SimpleJdbcCall getDebtDetailByLineNumberProcedure;
    private final SimpleJdbcCall getDebtDetailByDocumentProcedure;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public DebtsDetailRepositoryImpl(DataSource dataSource, @Value("${datasource.schema}") String schema) {
        this.objectMapper.registerModule(new JavaTimeModule());
        this.getDebtDetailByLineNumberProcedure = createSimpleJdbcCall(dataSource, schema, "pr_deuda_oac_v3");
        this.getDebtDetailByDocumentProcedure = createSimpleJdbcCall(dataSource, schema, "pr_deuda_oac_ws");
    }

    private SimpleJdbcCall createSimpleJdbcCall(DataSource dataSource, String schemaName, String procedureName) {
        return new SimpleJdbcCall(dataSource)
                .withSchemaName(schemaName)
                .withProcedureName(procedureName)
                .declareParameters(
                        new SqlParameter("pv_tipo_documento", Types.VARCHAR),
                        new SqlParameter("pv_nro_documento", Types.VARCHAR),
                        new SqlParameter("pv_num_linea", Types.VARCHAR),
                        new SqlParameter(PN_CANT_REG_POR_PAGAR, Types.INTEGER),
                        new SqlParameter(PN_CANT_REG_HISTORICO, Types.INTEGER),
                        new SqlOutParameter("xv_tot_deuda_total", Types.DECIMAL),
                        new SqlOutParameter("xv_mon_deuda_total", Types.VARCHAR),
                        new SqlOutParameter("xv_tipo_documento", Types.VARCHAR),
                        new SqlOutParameter("xv_numero_documento", Types.VARCHAR),
                        new SqlOutParameter("xv_nombres", Types.VARCHAR),
                        new SqlOutParameter("xv_apellidos", Types.VARCHAR),
                        new SqlOutParameter("xv_ciudad", Types.VARCHAR),
                        new SqlOutParameter("xv_direccion", Types.VARCHAR),
                        new SqlOutParameter("xc_DocPorPagar", OracleTypes.CURSOR, (rs, rowNum) -> {
                            PendingDocument doc = new PendingDocument();
                            doc.setDocumentType(rs.getString("tipo_documento"));
                            doc.setDocumentName(rs.getString("nombre_documento"));
                            doc.setDocumentNumber(rs.getString("numero_documento"));
                            if (rs.getDate(EMISION) != null) {
                                doc.setIssueDate(rs.getTimestamp(EMISION).toLocalDateTime());
                            }
                            if (rs.getDate("fecha_vencimiento") != null) {
                                doc.setDueDate(rs.getTimestamp("fecha_vencimiento").toLocalDateTime());
                            }
                            try {
                                doc.setMonth(rs.getString("mes"));
                            } catch (Exception e) {
                                doc.setMonth(null);
                            }
                            doc.setAmount(rs.getBigDecimal("monto"));
                            doc.setCurrency(rs.getString("moneda"));
                            doc.setOrigin(rs.getString("origen"));
                            doc.setAccountCode(rs.getString("cod_cuenta"));
                            return doc;
                        }),
                        new SqlOutParameter("xc_DocHistorico", OracleTypes.CURSOR, (rs, rowNum) -> {
                            HistoricalDocument doc = new HistoricalDocument();
                            doc.setDocumentType(rs.getString("tipo_documento"));
                            doc.setDocumentName(rs.getString("nombre_documento"));
                            doc.setDocumentNumber(rs.getString("numero_documento"));
                            if (rs.getDate(EMISION) != null) {
                                doc.setIssueDate(rs.getTimestamp(EMISION).toLocalDateTime());
                            }
                            if (rs.getDate("fecha_pago") != null) {
                                doc.setPaymentDate(rs.getTimestamp("fecha_pago").toLocalDateTime());
                            }
                            doc.setMonth(rs.getString("mes"));
                            doc.setAmount(rs.getBigDecimal("monto"));
                            doc.setCurrency(rs.getString("moneda"));
                            doc.setAccountCode(rs.getString("cod_cuenta"));
                            return doc;
                        }),
                        new SqlOutParameter(XV_STATUS, Types.VARCHAR),
                        new SqlOutParameter(XV_MESSAGE, Types.VARCHAR)
                );
    }

    @Override
    public BillDetail fetchInvoiceDetailsByLineNumber(String lineNumber, Integer historyMonth,
                                                      Integer pendingRecordsCount, Integer historicalRecordsCount) {
        MapSqlParameterSource in = new MapSqlParameterSource();
        in.addValue("pv_num_linea", lineNumber);
        in.addValue(PN_CANT_REG_POR_PAGAR, pendingRecordsCount);
        in.addValue(PN_CANT_REG_HISTORICO, historicalRecordsCount);

        Map<String, Object> out = this.getDebtDetailByLineNumberProcedure.execute(in);
        if (STATUS_OK.equals(out.get(XV_STATUS)) && MESSAGE_OK.equals(out.get(XV_MESSAGE))) {
            return mapToDebtDetail(out);
        } else {
            throw new StoredProcedureException(HttpStatus.NOT_FOUND, out.get(XV_MESSAGE).toString(), CODE_ERROR_IDF3);
        }
    }

    @Override
    public BillDetail fetchInvoiceDetailsByDocument(String documentType, String documentNumber, Integer historyMonth,
                                                    Integer pendingRecordsCount, Integer historicalRecordsCount) {
        MapSqlParameterSource in = new MapSqlParameterSource();
        in.addValue("pv_tipo_documento", documentType);
        in.addValue("pv_nro_documento", documentNumber);
        in.addValue(PN_CANT_REG_POR_PAGAR, pendingRecordsCount);
        in.addValue(PN_CANT_REG_HISTORICO, historicalRecordsCount);

        Map<String, Object> out = this.getDebtDetailByDocumentProcedure.execute(in);
        if (STATUS_OK.equals(out.get(XV_STATUS)) && MESSAGE_OK.equals(out.get(XV_MESSAGE))) {
            return mapToDebtDetail(out);
        } else {
            throw new StoredProcedureException(HttpStatus.NOT_FOUND, out.get(XV_MESSAGE).toString(), CODE_ERROR_IDF3);
        }
    }

    private BillDetail mapToDebtDetail(Map<String, Object> out) {

        var response = this.objectMapper.convertValue(out, BillDetail.class);

        List<PendingDocument> pendingDocs = this.objectMapper.convertValue(
                out.get("xc_DocPorPagar"),
                new TypeReference<List<PendingDocument>>() {
                }
        );
        response.setPendingDocuments(pendingDocs);

        List<HistoricalDocument> historicalDocs = this.objectMapper.convertValue(
                out.get("xc_DocHistorico"),
                new TypeReference<List<HistoricalDocument>>() {
                }
        );
        response.setHistoricalDocuments(historicalDocs);

        return response;
    }


    public Integer monthNameToNumber(String monthName) {
        if (monthName == null || monthName.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del mes no puede ser nulo o vacío.");
        }
        Locale localeEspanol = new Locale("es", "ES");
        DateTimeFormatter formateador = new DateTimeFormatterBuilder()
                .parseCaseInsensitive()
                .appendPattern("MMMM")
                .toFormatter(localeEspanol);
        try {
            Month mes = Month.from(formateador.parse(monthName.trim()));
            return mes.getValue();
        } catch (java.time.format.DateTimeParseException e) {
            throw new IllegalArgumentException("Nombre de mes no válido: '" + monthName + "'", e);
        }
    }


}
