package com.claro.invoice.controller;

import com.claro.common.claro.dto.response.Response;
import com.claro.common.claro.exceptions.dto.ErrorDTO;
import com.claro.invoice.dto.request.BillSearchCriteria;
import com.claro.invoice.dto.response.BillsDetailResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/invoice/api")
@Tag(name = "bills", description = "The Bills API")
public interface BillsController {


    /**
     * GET /invoice/api/v1/bills: List paid and pending bills
     *
     * @param xCorrelationId     Header x-correlation-id (required)
     * @param xRequestId         Header x-request-id (required)
     * @param billSearchCriteria bill search criteria (optional)
     * @return OK (status code 200)
     *
     */
    @Operation(
            summary = "List paid and pending bills",
            tags = {"bills"},
            responses = {
                    @ApiResponse(responseCode = "200", description = "OK", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = BillsDetailResponse.class),
                                    examples = {
                                            @ExampleObject(name = "Respuesta exitosa.",
                                                    value = """
                                                            {
                                                                "message": "Operación exitosa",
                                                                "code": 200,
                                                                "data": {
                                                                    "totalDebt": 104.5,
                                                                    "currency": "PEN",
                                                                    "paidBills": [
                                                                        {
                                                                            "type": "REC",
                                                                            "number": "SB01-0465448455",
                                                                            "name": "Recibo agosto    ",
                                                                            "amount": 69.9,
                                                                            "paymentDue": "2025-08-14T00:00:00",
                                                                            "lineNumbers": [
                                                                                "001"
                                                                            ]
                                                                        },
                                                                        {
                                                                            "type": "REC",
                                                                            "number": "CVEM-0001234",
                                                                            "name": "Recibo julio     ",
                                                                            "amount": 89.5,
                                                                            "paymentDue": "2025-07-14T00:00:00",
                                                                            "lineNumbers": [
                                                                                "002"
                                                                            ]
                                                                        }
                                                                    ],
                                                                    "pendingBills": [
                                                                        {
                                                                            "type": "REC",
                                                                            "number": "SB01-0465448456",
                                                                            "name": "Recibo septiembre",
                                                                            "amount": 59.5,
                                                                            "dueDate": "2025-09-14T00:00:00",
                                                                            "lineNumbers": [
                                                                                "001"
                                                                            ]
                                                                        },
                                                                        {
                                                                            "type": "FIN",
                                                                            "number": "FIN000012345",
                                                                            "name": "Cuota financiamiento",
                                                                            "amount": 45,
                                                                            "dueDate": "2025-09-20T00:00:00",
                                                                            "lineNumbers": [
                                                                                "003"
                                                                            ]
                                                                        }
                                                                    ]
                                                                }
                                                            }
                                                            """)
                                    })}),

                    @ApiResponse(responseCode = "400", description = "Validation error on parameters", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class),
                                    examples = {
                                            @ExampleObject(name = "Invalid parameter - IDF1", value = """
                                                    {
                                                          "code": 400,
                                                          "detail": "You must provide either document info (type and number) or a line number.",
                                                          "message": "INVOICE_ERROR",
                                                          "status": "BAD_REQUEST",
                                                          "subType": "IDF1",
                                                          "type": "InvalidParameterException"
                                                      }
                                                    """),
                                            @ExampleObject(name = "Invalid parameter - IDF5", value = """
                                                    {
                                                          "code": 400,
                                                          "detail": "Provide either document info (type and number) or line number, but not both.",
                                                          "message": "INVOICE_ERROR",
                                                          "status": "BAD_REQUEST",
                                                          "subType": "IDF5",
                                                          "type": "MutuallyExclusiveParametersException"
                                                      }
                                                    """),
                                            @ExampleObject(name = "Invalid parameter - IDF6", value = """
                                                    {
                                                          "code": 400,
                                                          "detail": "Invalid document type provided: 'DNI2'.",
                                                          "message": "INVOICE_ERROR",
                                                          "status": "BAD_REQUEST",
                                                          "subType": "IDF6",
                                                          "type": "DocumentTypeInvalidException"
                                                      }
                                                    """)
                                    })}),
                    @ApiResponse(responseCode = "401", description = "Unauthorized", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class),
                                    examples = {
                                            @ExampleObject(name = "Requiere api-key", value = """
                                                    {
                                                        "code": 401,
                                                        "detail": "Invalid or missing API Key",
                                                        "message": "INVOICE_ERROR",
                                                        "status": "UNAUTHORIZED",
                                                        "subType": "IDF1",
                                                        "type": null
                                                    }
                                                    """),
                                    })}),
                    @ApiResponse(responseCode = "404", description = "Resource not found", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class),
                                    examples = {
                                            @ExampleObject(name = "Resource not found - IDF3", value = """
                                                    {
                                                        "code": 404,
                                                        "detail": "No Existe Cliente",
                                                        "message": "INVOICE_ERROR",
                                                        "status": "NOT_FOUND",
                                                        "subType": "IDF3",
                                                        "type": "StoredProcedureException"
                                                    }
                                                    """),
                                            @ExampleObject(name = "Resource not found", value = """
                                                    {
                                                        "code": 404,
                                                        "detail": "No static resource for GET invoice/api/v1/billss",
                                                        "message": "RESOURCE_NOT_FOUND",
                                                        "status": "NOT_FOUND",
                                                        "subType": null,
                                                        "type": "NoResourceFoundException"
                                                    }
                                                    """)
                                    })}),
                    @ApiResponse(responseCode = "500", description = "Internal server error", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class),
                                    examples = {
                                            @ExampleObject(name = "Error interno del servidor.",
                                                    value = """
                                                            {
                                                            
                                                            "code": 500,
                                                            "detail": "There is an internal problem."
                                                            "message": "INVOICE_ERROR",
                                                            "status": "INTERNAL_SERVER_ERROR",
                                                            "subType": "ERROR",
                                                            "type": "ClientException"
                                                             }
                                                            """)
                                    })
                    })})
    @GetMapping(value = "/v1/bills", produces = {"application/json"})
    ResponseEntity<Response<BillsDetailResponse>> getBills(
            @Valid @ModelAttribute @ParameterObject BillSearchCriteria billSearchCriteria,
            @Parameter(
                    name = "x-request-id",
                    description = "ID de correlación para trazabilidad",
                    required = true,
                    example = "3a16264f-fcd4-4b41-8a5d-61509395642e"
            )
            @RequestHeader("x-request-id") String xRequestId,
            @Parameter(
                    name = "x-correlation-id",
                    description = "ID de correlación para trazabilidad",
                    required = true,
                    example = "29db9cb2-f77a-478e-829f-3c6ba60acb76"
            )
            @RequestHeader("x-correlation-id") String xCorrelationId,
            @Parameter(
                    name = "x-client-version-id",
                    description = "Versión del cliente",
                    required = true,
                    example = "1.0.0"
            )
            @RequestHeader("x-client-version-id") String xClientVersionId);
}
