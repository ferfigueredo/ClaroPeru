package com.claro.invoice.dto.request;

import com.claro.common.commonlogger.utils.redaction.Redactable;
import com.claro.common.commonlogger.utils.redaction.Redacted;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.BindParam;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Objects;

@Data
@NoArgsConstructor
@SuperBuilder
public class DebtSearchCriteria implements Redactable {

    @BindParam(value = "documentType")
    @Schema(name = "document-type", description = "Type of the document.", type = "string", example = "DNI", enumAsRef = true)
    protected String documentType;

    @Redacted
    @BindParam(value = "documentNumber")
    @Schema(name = "document-number", description = "Type of the document.", type = "string", example = "1234678")
    protected String documentNumber;

    @BindParam(value = "lineNumber")
    @Schema(name = "line-number", description = "Number of the document.", type = "string", example = "1234567890")
    protected String lineNumber;

    public MultiValueMap<String, String> toQueryParamsMap() {
        var mapGenerator = new DebtSearchCriteria.MapParamsGenerator();
        return mapGenerator.addIfNotNull("documentType", URLEncoder.encode(this.documentType, StandardCharsets.UTF_8))
                .addIfNotNull("documentNumber", URLEncoder.encode(this.documentNumber, StandardCharsets.UTF_8))
                .addIfNotNull("lineNumber", URLEncoder.encode(this.lineNumber, StandardCharsets.UTF_8))
                .build();
    }

    protected static class MapParamsGenerator {
        private final MultiValueMap<String, String> map = new LinkedMultiValueMap<>();

        public DebtSearchCriteria.MapParamsGenerator addIfNotNull(String key, Object value) {
            if (Objects.nonNull(value)) {
                this.map.put(key, Collections.singletonList(value.toString()));
            }
            return this;
        }

        public MultiValueMap<String, String> build() {
            return this.map;
        }
    }

    @Override
    public String toString() {
        return this.redact();
    }
}
