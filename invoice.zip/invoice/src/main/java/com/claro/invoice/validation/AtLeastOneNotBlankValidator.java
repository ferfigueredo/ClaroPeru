package com.claro.invoice.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

public class AtLeastOneNotBlankValidator implements ConstraintValidator<AtLeastOneNotBlank, Object> {

    private String firstFieldName;
    private String secondFieldName;

    @Override
    public void initialize(AtLeastOneNotBlank constraintAnnotation) {
        this.firstFieldName = constraintAnnotation.first();
        this.secondFieldName = constraintAnnotation.second();
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        BeanWrapper beanWrapper = new BeanWrapperImpl(value);
        String firstValue = (String) beanWrapper.getPropertyValue(firstFieldName);
        String secondValue = (String) beanWrapper.getPropertyValue(secondFieldName);

        boolean isValid = (firstValue != null && !firstValue.isBlank())
                || (secondValue != null && !secondValue.isBlank());

        if (!isValid) {
            var atLeastOneNotBlankCode = "AtLeastOneNotBlank";
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate(atLeastOneNotBlankCode)
                    .addPropertyNode(firstFieldName)
                    .addConstraintViolation();
            context.buildConstraintViolationWithTemplate(atLeastOneNotBlankCode)
                    .addPropertyNode(secondFieldName)
                    .addConstraintViolation();
        }
        return isValid;
    }
}
