package com.claro.invoice.validation.handler;

import lombok.RequiredArgsConstructor;
import org.springframework.validation.FieldError;

import java.util.List;

@RequiredArgsConstructor
public class AtLeastOneNotBlankHandler implements Handler {

    private final Handler next;

    @Override
    public String handle(StringBuilder builder, List<FieldError> errors) {
        List<FieldError> filteredErrors = this.filterByCode(errors, "AtLeastOneNotBlank");

        if (filteredErrors.isEmpty()) {
            return next.handle(builder, errors);
        }
        if (!builder.isEmpty()) {
            builder.append(". ");
        }

        builder.append("Incomplete field list: one of them ")
                .append(filteredErrors.stream()
                        .map(FieldError::getField)
                        .reduce((field1, field2) -> field1.concat(", ").concat(field2))
                        .orElse(" "))
                .append(" is required");

        return next.handle(builder, errors);
    }
}
