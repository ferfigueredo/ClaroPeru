package com.claro.invoice.service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.security.SignatureException;


public interface JwtValidatorService {

    /**
     * Validates the integrity and validity of a JWT token.
     *
     * @param token the JWT token to validate
     * @return {@code true} if the token is valid, {@code false} otherwise
     */
    boolean validateToken(String token);

    /**
     * Retrieves the claims from the provided JWT token.
     *
     * @param token the JWT token from which to extract claims
     * @return the claims extracted from the token
     * @throws ExpiredJwtException if the token is expired
     * @throws SignatureException  if the token signature is invalid
     */
    Claims getClaimsFromToken(String token) throws ExpiredJwtException, SignatureException;


}

