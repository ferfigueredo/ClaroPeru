package com.claro.invoice.filter;


import com.claro.invoice.utils.ConstantUtils;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;

import java.io.IOException;


@Slf4j
public class TraceFilter implements Filter {

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        var httpServletRequest = (HttpServletRequest) servletRequest;
        var requestId = httpServletRequest.getHeader(ConstantUtils.X_REQUEST_ID);
        var correlationId = httpServletRequest.getHeader(ConstantUtils.X_CORRELATION_ID);
        var clientVersionId = httpServletRequest.getHeader(ConstantUtils.X_CLIENT_VERSION_ID);

        MDC.put(ConstantUtils.X_REQUEST_ID, requestId);
        MDC.put(ConstantUtils.X_CORRELATION_ID, correlationId);
        MDC.put(ConstantUtils.X_CLIENT_VERSION_ID, clientVersionId);

        var httpServletResponse = (HttpServletResponse) servletResponse;
        filterChain.doFilter(httpServletRequest, httpServletResponse);
        MDC.clear();
    }

}