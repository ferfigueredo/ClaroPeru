package com.claro.invoice.validation.handler;

import lombok.RequiredArgsConstructor;
import org.springframework.validation.FieldError;

import java.util.List;

@RequiredArgsConstructor
public class NotNullHandler implements Handler {

    private final Handler next;

    @Override
    public String handle(StringBuilder builder, List<FieldError> errors) {
        var errorCodes = List.of("NotBlank", "NotNull", "NotEmpty");
        List<FieldError> filteredErrors = this.filterByCode(errors, errorCodes);
        if (filteredErrors.isEmpty()) {
            return next.handle(builder, errors);
        }
        if (!builder.isEmpty()) {
            builder.append(". ");
        }
        if (filteredErrors.size() == 1) {

            builder.append("Incomplete field list: ")
                    .append(filteredErrors.getFirst().getField())
                    .append(" is required");
        } else {
            builder.append("Incomplete field list: ")
                    .append(filteredErrors.stream()
                            .map(FieldError::getField)
                            .reduce((field1, field2) -> field1.concat(", ").concat(field2))
                            .orElse(" "))
                    .append(" are required");
        }
        return next.handle(builder, errors);
    }
}


