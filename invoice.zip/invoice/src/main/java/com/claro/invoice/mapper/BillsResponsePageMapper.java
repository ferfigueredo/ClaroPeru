package com.claro.invoice.mapper;

import com.claro.common.claro.dto.response.Response;
import com.claro.invoice.dto.response.BillsDetailResponse;
import com.claro.invoice.dto.response.PaidBill;
import com.claro.invoice.dto.response.PendingBill;
import com.claro.invoice.model.BillDetail;
import com.claro.invoice.model.HistoricalDocument;
import com.claro.invoice.model.PendingDocument;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;

import static com.claro.invoice.utils.ConstantUtils.INVOICE_SUCCESS_CODE;
import static com.claro.invoice.utils.ConstantUtils.INVOICE_SUCCESS_MESSAGE;

@Component
public class BillsResponsePageMapper {

    public BillsDetailResponse mapDebtDetailToBillsResponse(BillDetail billDetail) {
        var response = new BillsDetailResponse();
        response.setTotalDebt(billDetail.getTotalDebtAmount());
        response.setCurrency(billDetail.getTotalDebtCurrency());
        response.setPendingBills(mapPendingDocuments(billDetail, billDetail.getPendingDocuments()));
        response.setPaidBills(mapHistoricalDocuments(billDetail, billDetail.getHistoricalDocuments()));
        return response;
    }

    private List<PendingBill> mapPendingDocuments(BillDetail billDetail, List<PendingDocument> pendingDocuments) {
        if (pendingDocuments == null) {
            return Collections.emptyList();
        }
        return pendingDocuments.stream().map(doc -> mapPendingDocument(billDetail, doc))
                .toList();
    }

    private PendingBill mapPendingDocument(BillDetail billDetail, PendingDocument doc) {
        return PendingBill.builder()
                .type(doc.getDocumentType())
                .number(doc.getDocumentNumber())
                .name(doc.getDocumentName())
                .amount(doc.getAmount())
                .dueDate(doc.getDueDate())
                .lineNumbers(List.of(doc.getAccountCode()))
                .build();
    }

    private List<PaidBill> mapHistoricalDocuments(BillDetail billDetail, List<HistoricalDocument> historicalDocuments) {
        if (historicalDocuments == null) {
            return Collections.emptyList();
        }
        return historicalDocuments.stream().map(doc -> mapHistoricalDocument(billDetail, doc)).toList();
    }

    private PaidBill mapHistoricalDocument(BillDetail billDetail, HistoricalDocument doc) {
        return PaidBill.builder()
                .type(doc.getDocumentType())
                .number(doc.getDocumentNumber())
                .name(doc.getDocumentName())
                .amount(doc.getAmount())
                .paymentDue(doc.getPaymentDate())
                .lineNumbers(List.of(doc.getAccountCode()))
                .build();
    }

    public Response<BillsDetailResponse> mapToBillsResponsePage(BillDetail billDetail) {
        var data = this.mapDebtDetailToBillsResponse(billDetail);

        data.setTotalDebt(billDetail.getTotalDebtAmount());
        data.setCurrency(billDetail.getTotalDebtCurrency());

        return Response.<BillsDetailResponse>builder()
                .code(INVOICE_SUCCESS_CODE)
                .message(INVOICE_SUCCESS_MESSAGE)
                .data(data)
                .build();
    }
}
