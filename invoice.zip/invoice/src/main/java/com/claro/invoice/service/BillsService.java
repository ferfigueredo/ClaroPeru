package com.claro.invoice.service;


import com.claro.common.claro.dto.response.Response;
import com.claro.invoice.dto.response.BillsDetailResponse;

public interface BillsService {

    /**
     * Find bills by invoice params.
     *
     * @param documentType Invoice document type.
     * @param documentNumber Invoice document number.
     * @param lineNumber Invoice line number.
     *
     * @return Bills detail.
     */
    Response<BillsDetailResponse> findBills(String documentType, String documentNumber, String lineNumber, Integer historyMonth,
                                            Integer pendingRecordsCount, Integer historicalRecordsCount);
}
