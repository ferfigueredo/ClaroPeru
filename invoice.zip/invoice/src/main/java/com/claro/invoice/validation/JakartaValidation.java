package com.claro.invoice.validation;

import com.claro.invoice.validation.handler.Handler;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;

import java.util.List;

@Component
@RequiredArgsConstructor
public class JakartaValidation {

    private final Handler validationHandler;

    public String validationExceptionMessageGenerator(MethodArgumentNotValidException ex) {
        var stringBuilder = new StringBuilder();
        List<FieldError> errors = ex.getBindingResult().getFieldErrors();

        return validationHandler.handle(stringBuilder, errors);
    }
}

