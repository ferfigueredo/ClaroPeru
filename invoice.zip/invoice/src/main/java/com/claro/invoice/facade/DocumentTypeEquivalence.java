package com.claro.invoice.facade;

import com.claro.invoice.client.ConfigurationManagerClient;
import com.claro.invoice.exception.DocumentTypeInvalidException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import static com.claro.invoice.utils.ConstantUtils.CODE_ERROR_IDF6;

@Slf4j
@Component
public class DocumentTypeEquivalence {

    private final ConfigurationManagerClient client;

    public DocumentTypeEquivalence(ConfigurationManagerClient client) {
        this.client = client;
    }

    public String getCode(String documentType) {
        var response = client.getResponseFromEquivalence(documentType, "TIMPROD");
        if (response != null && response.getCode() == HttpStatus.OK.value() && response.getData() != null) {
            return response.getData().getCrmDocTypeCode();
        } else {
            log.error("::: Invalid document-type: {} :::", documentType);
            throw new DocumentTypeInvalidException("Invalid document type provided: '" + documentType + "'.", CODE_ERROR_IDF6);
        }
    }

}
