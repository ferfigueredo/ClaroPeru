package com.claro.invoice.configuration;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Filtro de Servlet que transforma los nombres de los query parameters de kebab-case a camelCase.
 * Por ejemplo, un parámetro 'document-type' se convierte en 'documentType' antes de que
 * llegue al controlador, permitiendo un data binding automático a los campos de un DTO.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class KebabCaseToCamelCaseFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        if (request instanceof HttpServletRequest && request.getParameterMap().size() > 0) {
            HttpServletRequest wrappedRequest = new KebabCaseRequestWrapper((HttpServletRequest) request);
            chain.doFilter(wrappedRequest, response);
        } else {
            chain.doFilter(request, response);
        }
    }

    private static class KebabCaseRequestWrapper extends HttpServletRequestWrapper {
        private final Map<String, String[]> modifiedParameters;

        public KebabCaseRequestWrapper(HttpServletRequest request) {
            super(request);
            this.modifiedParameters = new ConcurrentHashMap<>();

            // Procesa el mapa de parámetros original
            Map<String, String[]> originalParams = super.getParameterMap();
            for (Map.Entry<String, String[]> entry : originalParams.entrySet()) {
                String camelCaseKey = convertKebabToCamel(entry.getKey());
                this.modifiedParameters.put(camelCaseKey, entry.getValue());
            }
        }

        private String convertKebabToCamel(String kebabCase) {
            if (kebabCase == null || !kebabCase.contains("-")) {
                return kebabCase;
            }
            StringBuilder camelCase = new StringBuilder();
            boolean capitalizeNext = false;
            for (char c : kebabCase.toCharArray()) {
                if (c == '-') {
                    capitalizeNext = true;
                } else {
                    if (capitalizeNext) {
                        camelCase.append(Character.toUpperCase(c));
                        capitalizeNext = false;
                    } else {
                        camelCase.append(c);
                    }
                }
            }
            return camelCase.toString();
        }

        @Override
        public String getParameter(String name) {
            if (modifiedParameters.containsKey(name)) {
                String[] values = modifiedParameters.get(name);
                return (values != null && values.length > 0) ? values[0] : null;
            }
            return super.getParameter(name);
        }

        @Override
        public Map<String, String[]> getParameterMap() {
            return Collections.unmodifiableMap(this.modifiedParameters);
        }

        @Override
        public Enumeration<String> getParameterNames() {
            return Collections.enumeration(this.modifiedParameters.keySet());
        }

        @Override
        public String[] getParameterValues(String name) {
            return this.modifiedParameters.get(name);
        }
    }
}