package com.claro.invoice.service.impl;

import com.claro.common.claro.dto.response.Response;
import com.claro.invoice.dto.response.TotalDebtResponse;
import com.claro.invoice.facade.DocumentTypeEquivalence;
import com.claro.invoice.mapper.DebtResponseMapper;
import com.claro.invoice.model.BillDetail;
import com.claro.invoice.repository.DebtsDetailRepository;
import com.claro.invoice.service.DebtsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Slf4j
@Service
@RequiredArgsConstructor
public class DebtsServiceImpl implements DebtsService {

    private final DocumentTypeEquivalence documentTypeEquivalence;
    private final DebtsDetailRepository debtsDetailRepository;
    private final DebtResponseMapper mapper;

    @Value("${total-debts.pending-records-count}")
    private Integer pendingRecordsCount;

    @Value("${total-debts.historical-records-count}")
    private Integer historicalRecordsCount;

    /**
     * See {@link DebtsService#findTotalDebt(String, String, String)}
     */
    @Override
    public Response<TotalDebtResponse> findTotalDebt(String documentType, String documentNumber, String lineNumber) {

        BillDetail billDetail;
        if (StringUtils.hasText(lineNumber)) {
            billDetail = this.debtsDetailRepository
                    .fetchInvoiceDetailsByLineNumber(lineNumber, null, this.pendingRecordsCount, this.historicalRecordsCount);
        } else {
            String documentTypeCode = documentTypeEquivalence.getCode(documentType);
            billDetail = this.debtsDetailRepository
                    .fetchInvoiceDetailsByDocument(documentTypeCode, documentNumber, null, this.pendingRecordsCount, this.historicalRecordsCount);
        }
        log.info("findTotalDebt: response billDetail={}", billDetail);
        return this.mapper.debtDetailToDebtResponse(billDetail);
    }
}
