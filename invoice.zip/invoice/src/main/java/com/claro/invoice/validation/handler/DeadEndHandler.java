package com.claro.invoice.validation.handler;

import org.springframework.validation.FieldError;

import java.util.List;

public class DeadEndHandler implements Handler {

    @Override
    public String handle(StringBuilder builder, List<FieldError> errors) {
        return builder.toString();
    }
}

