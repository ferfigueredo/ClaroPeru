package com.claro.invoice.dto.request;

import com.claro.common.commonlogger.utils.redaction.Redactable;
import com.claro.common.commonlogger.utils.redaction.Redacted;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.BindParam;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Objects;

@Data
@NoArgsConstructor
@SuperBuilder
public class BillSearchCriteria implements Redactable {

    @BindParam(value = "documentType")
    @Schema(name = "document-type", description = "Type of the document.", type = "string",
            example = "DNI",
            allowableValues = {"PASAPORTE", "DNI", "CARNET_EXTRANJERIA", "CIP", "RUC", "CIE", "CIRE", "CPP", "CTM"})
    private String documentType;

    @Redacted
    @BindParam(value = "documentNumber")
    @Schema(name = "document-number", description = "Type of the document.", type = "string", example = "1234678")
    private String documentNumber;

    @BindParam(value = "lineNumber")
    @Schema(name = "lineNumber", description = "Number of the document.", type = "string", example = "1234567890")
    private String lineNumber;

    @BindParam(value = "historyMonths")
    @Schema(name = "history-months", description = "Number of months of history to query.", example = "12", type = "integer")
    private Integer historyMonths;

    @BindParam("pendingRecordsCount")
    @Schema(name = "pending-records-count", description = "", type = "Integer", defaultValue = "10")
    private Integer pendingRecordsCount;

    @BindParam(value = "historicalRecordsCount")
    @Schema(name = "historical-records-count", description = "", type = "Integer", defaultValue = "10")
    private Integer historicalRecordsCount;

    @Override
    public String toString() {
        return this.redact();
    }

    public MultiValueMap<String, String> toQueryParamsMap() {
        var mapGenerator = new MapParamsGenerator();
        return mapGenerator.addIfNotNull("documentType", URLEncoder.encode(this.documentType, StandardCharsets.UTF_8))
                .addIfNotNull("documentNumber", URLEncoder.encode(this.documentNumber, StandardCharsets.UTF_8))
                .addIfNotNull("lineNumber", URLEncoder.encode(this.lineNumber, StandardCharsets.UTF_8))
                .addIfNotNull("historyMonths", this.historyMonths)
                .addIfNotNull("pendingRecordsCount", this.pendingRecordsCount)
                .addIfNotNull("historicalRecordsCount", this.historicalRecordsCount)
                .build();
    }

    protected static class MapParamsGenerator {
        private final MultiValueMap<String, String> map = new LinkedMultiValueMap<>();

        public MapParamsGenerator addIfNotNull(String key, Object value) {
            if (Objects.nonNull(value)) {
                this.map.put(key, Collections.singletonList(value.toString()));
            }
            return this;
        }

        public MultiValueMap<String, String> build() {
            return this.map;
        }
    }

}
