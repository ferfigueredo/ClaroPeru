package com.claro.invoice.controller.impl;

import com.claro.common.claro.dto.response.Response;
import com.claro.invoice.controller.BillsController;
import com.claro.invoice.dto.request.BillSearchCriteria;
import com.claro.invoice.dto.response.BillsDetailResponse;
import com.claro.invoice.service.BillsService;
import com.claro.invoice.validation.DocumentTypeAndLineNumberValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
public class BillsControllerImpl implements BillsController {

    private final BillsService billsService;
    private final DocumentTypeAndLineNumberValidator validator;

    /**
     * See {@link BillsController#getBills(BillSearchCriteria, String, String, String)}
     */
    @Override
    public ResponseEntity<Response<BillsDetailResponse>> getBills(BillSearchCriteria billSearchCriteria, String xRequestId, String xCorrelationId, String xClientVersionId) {

        var documentType = billSearchCriteria.getDocumentType();
        var documentNumber = billSearchCriteria.getDocumentNumber();
        var lineNumber = billSearchCriteria.getLineNumber();
        var historyMonths = billSearchCriteria.getHistoryMonths();
        var pendingRecordsCount = billSearchCriteria.getPendingRecordsCount();
        var historicalRecordsCount = billSearchCriteria.getHistoricalRecordsCount();
        log.info("query params: {}", billSearchCriteria);

        this.validator.validate(documentType, documentNumber, lineNumber);

        var billsResponse = this.billsService.findBills(documentType, documentNumber, lineNumber, historyMonths, pendingRecordsCount, historicalRecordsCount);
        return ResponseEntity.ok(billsResponse);
    }
}
