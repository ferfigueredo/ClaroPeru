package com.claro.invoice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class HistoricalDocument {

    private String documentType;
    private String documentName;
    private String documentNumber;
    private LocalDateTime issueDate;
    private LocalDateTime paymentDate;
    private String month;
    private BigDecimal amount;
    private String currency;
    private String accountCode;
}
