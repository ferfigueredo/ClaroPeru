package com.claro.invoice.configuration;

import com.claro.invoice.validation.handler.AtLeastOneNotBlankHandler;
import com.claro.invoice.validation.handler.DeadEndHandler;
import com.claro.invoice.validation.handler.Handler;
import com.claro.invoice.validation.handler.NotNullHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JakartaValidationConfig {

    @Bean
    public Handler createValidationHandler() {
        Handler deadEndHandler = new DeadEndHandler();
        Handler atLeastOneNotBlankHandler = new AtLeastOneNotBlankHandler(deadEndHandler);
        return new NotNullHandler(atLeastOneNotBlankHandler);
    }

}

