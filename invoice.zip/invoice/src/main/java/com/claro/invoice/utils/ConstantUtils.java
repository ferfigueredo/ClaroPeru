package com.claro.invoice.utils;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ConstantUtils {

    public static final Integer INVOICE_SUCCESS_CODE = 200;
    public static final String INVOICE_SUCCESS_MESSAGE = "Operación exitosa";
    public static final String STATUS_OK = "0";
    public static final String MESSAGE_OK = "Exito";

    public static final String INVOICE_ERROR_MESSAGE = "INVOICE_ERROR";
    public static final String CODE_ERROR_IDF1 = "IDF1";
    public static final String CODE_ERROR_IDF3 = "IDF3";
    public static final String CODE_ERROR_IDF5 = "IDF5";
    public static final String CODE_ERROR_IDF6 = "IDF6";

    public static final int DEFAULT_PAGE_0 = 0;

    public static final String PN_CANT_REG_POR_PAGAR = "pn_cant_RegPorPagar";
    public static final String PN_CANT_REG_HISTORICO = "pn_cant_RegHistorico";
    public static final String EMISION = "emision";
    public static final String XV_STATUS = "xv_status";
    public static final String XV_MESSAGE = "xv_message";

    public static final String X_REQUEST_ID = "x-request-id";
    public static final String X_CORRELATION_ID = "x-correlation-id";
    public static final String X_CLIENT_VERSION_ID = "x-client-version-id";
}
