package com.claro.invoice.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.http.HttpStatus;

@Data
@EqualsAndHashCode(callSuper = false)
public class StoredProcedureException extends RuntimeException {

    private final String codeError;
    private final HttpStatus httpStatus;

    public StoredProcedureException(HttpStatus httpStatus, String message, String codeError) {
        super(message);
        this.codeError = codeError;
        this.httpStatus = httpStatus;
    }
}

