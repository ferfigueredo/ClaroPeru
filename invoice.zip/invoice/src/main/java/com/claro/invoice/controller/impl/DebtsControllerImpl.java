package com.claro.invoice.controller.impl;

import com.claro.common.claro.dto.response.Response;
import com.claro.invoice.controller.DebtsController;
import com.claro.invoice.dto.request.DebtSearchCriteria;
import com.claro.invoice.dto.response.TotalDebtResponse;
import com.claro.invoice.service.DebtsService;
import com.claro.invoice.validation.DocumentTypeAndLineNumberValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
public class DebtsControllerImpl implements DebtsController {

    private final DebtsService debtsService;
    private final DocumentTypeAndLineNumberValidator validator;

    /**
     * See {@link DebtsController#getDebts(DebtSearchCriteria, String, String, String)}
     */
    @Override
    public ResponseEntity<Response<TotalDebtResponse>> getDebts(DebtSearchCriteria debtSearchCriteria, String xRequestId, String xCorrelationId, String xClientVersionId) {

        var documentType = debtSearchCriteria.getDocumentType();
        var documentNumber = debtSearchCriteria.getDocumentNumber();
        var lineNumber = debtSearchCriteria.getLineNumber();
        log.info("query params: {}", debtSearchCriteria);

        this.validator.validate(documentType, documentNumber, lineNumber);

        return ResponseEntity.ok(this.debtsService.findTotalDebt(documentType, documentNumber, lineNumber));
    }
}
