package com.claro.invoice.mapper;

import com.claro.common.claro.dto.response.Response;
import com.claro.invoice.dto.response.TotalDebtResponse;
import com.claro.invoice.model.BillDetail;
import com.claro.invoice.model.PendingDocument;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

import static com.claro.invoice.utils.ConstantUtils.INVOICE_SUCCESS_CODE;
import static com.claro.invoice.utils.ConstantUtils.INVOICE_SUCCESS_MESSAGE;

@Component
@RequiredArgsConstructor
public class DebtResponseMapper {

    public Response<TotalDebtResponse> debtDetailToDebtResponse(BillDetail billDetail) {
        var data = new TotalDebtResponse();

        if (billDetail.getDocumentNumber() != null) {
            try {
                data.setCustomerId(Integer.valueOf(billDetail.getDocumentNumber()));
            } catch (NumberFormatException e) {
                data.setCustomerId(null);
            }
        }
        if (billDetail.getTotalDebtAmount() != null) {
            try {
                BigDecimal accountDebt = billDetail.getPendingDocuments().stream()
                        .map(PendingDocument::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
                data.setAccountDebt(accountDebt);
            } catch (NumberFormatException e) {
                data.setAccountDebt(BigDecimal.ZERO);
            }
        }
        data.setCurrency(billDetail.getTotalDebtCurrency());

        if (billDetail.getPendingDocuments() != null && !billDetail.getPendingDocuments().isEmpty()) {
            data.setDueDate(billDetail.getPendingDocuments().getFirst().getDueDate());
        }

        return Response.<TotalDebtResponse>builder()
                .code(INVOICE_SUCCESS_CODE)
                .message(INVOICE_SUCCESS_MESSAGE)
                .data(data)
                .build();
    }
}
