package com.claro.invoice.model;

import com.claro.common.commonlogger.utils.redaction.Redactable;
import com.claro.common.commonlogger.utils.redaction.Redacted;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillDetail implements Redactable {

    @JsonProperty("xv_tot_deuda_total")
    private BigDecimal totalDebtAmount;

    @JsonProperty("xv_mon_deuda_total")
    private String totalDebtCurrency;

    @JsonProperty("xv_tipo_documento")
    private String documentType;

    @Redacted
    @JsonProperty("xv_numero_documento")
    private String documentNumber;

    @JsonProperty("xv_nombres")
    private String firstName;

    @JsonProperty("xv_apellidos")
    private String lastName;

    @JsonProperty("xv_ciudad")
    private String city;

    @JsonProperty("xv_direccion")
    private String address;

    @JsonProperty("xc_DocPorPagar")
    private List<PendingDocument> pendingDocuments;

    @JsonProperty("xc_DocHistorico")
    private List<HistoricalDocument> historicalDocuments;

    @JsonProperty("xv_status")
    private String status;

    @JsonProperty("xv_message")
    private String message;

    @Override
    public String toString() {
        return this.redact();
    }
}
