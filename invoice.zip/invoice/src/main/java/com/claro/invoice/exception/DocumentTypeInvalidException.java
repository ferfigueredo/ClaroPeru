package com.claro.invoice.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class DocumentTypeInvalidException extends RuntimeException {

    private final String codeError;

    public DocumentTypeInvalidException(String message, String codeError) {
        super(message);
        this.codeError = codeError;
    }
}