package com.claro.invoice.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class InvalidParameterException extends RuntimeException {

    private final String codeError;

    public InvalidParameterException(String message, String codeError) {
        super(message);
        this.codeError = codeError;
    }
}