package com.claro.invoice.service;

import com.claro.common.claro.dto.response.Response;
import com.claro.invoice.dto.response.TotalDebtResponse;

public interface DebtsService {

    /**
     * Find total debt by invoice params.
     * @param documentType Invoice document type.
     * @param documentNumber Invoice document number.
     * @param lineNumber Invoice line number.
     * @return Total debt.
     */
    Response<TotalDebtResponse> findTotalDebt(String documentType, String documentNumber, String lineNumber);
}
