package com.claro.invoice.repository;

import com.claro.invoice.model.BillDetail;

public interface DebtsDetailRepository {


    /**
     * Fetch invoice details by line number.
     *
     * @param lineNumber Line number.
     * @param historyMonth History month.
     * @param pendingRecordsCount Pending records count.
     * @param historicalRecordsCount Historical records count.
     * @return Bill detail.
     */
    BillDetail fetchInvoiceDetailsByLineNumber(String lineNumber, Integer historyMonth,
                                               Integer pendingRecordsCount, Integer historicalRecordsCount);


    /**
     * Fetch invoice details by document.
     * @param documentType Document type.
     * @param documentNumber Document number.
     * @param historyMonth History month.
     * @param pendingRecordsCount Pending records count.
     * @param historicalRecordsCount Historical records count.
     * @return Bill detail.
     */
    BillDetail fetchInvoiceDetailsByDocument(String documentType, String documentNumber, Integer historyMonth,
                                             Integer pendingRecordsCount, Integer historicalRecordsCount);

}
