package com.claro.invoice.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class MutuallyExclusiveParametersException extends RuntimeException {

    private final String codeError;

    public MutuallyExclusiveParametersException(String message, String codeError) {
        super(message);
        this.codeError = codeError;
    }
}