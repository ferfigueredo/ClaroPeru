package com.claro.invoice.service.impl;

import com.claro.common.claro.dto.response.Response;
import com.claro.invoice.dto.response.BillsDetailResponse;
import com.claro.invoice.facade.DocumentTypeEquivalence;
import com.claro.invoice.mapper.BillsResponsePageMapper;
import com.claro.invoice.model.BillDetail;
import com.claro.invoice.repository.DebtsDetailRepository;
import com.claro.invoice.service.BillsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillsServiceImpl implements BillsService {

    private final DocumentTypeEquivalence documentTypeEquivalence;
    private final DebtsDetailRepository debtsDetailRepository;
    private final BillsResponsePageMapper mapper;

    /**
     * See {@link BillsService#findBills(String, String, String, Integer, Integer, Integer)
     */
    @Override
    public Response<BillsDetailResponse> findBills(String documentType, String documentNumber, String lineNumber, Integer historyMonth,
                                                   Integer pendingRecordsCount, Integer historicalRecordsCount) {

        BillDetail billDetail;
        if (StringUtils.hasText(lineNumber)) {
            billDetail = this.debtsDetailRepository
                    .fetchInvoiceDetailsByLineNumber(lineNumber, historyMonth, pendingRecordsCount, historicalRecordsCount);
        } else {
            String documentTypeCode = documentTypeEquivalence.getCode(documentType);
            billDetail = this.debtsDetailRepository
                    .fetchInvoiceDetailsByDocument(documentTypeCode, documentNumber, historyMonth, pendingRecordsCount, historicalRecordsCount);
        }
        log.info("findBills: response billDetail={}", billDetail);
        return this.mapper.mapToBillsResponsePage(billDetail);
    }


}
