package com.claro.invoice.validation.handler;

import org.springframework.validation.FieldError;

import java.util.List;
import java.util.Objects;

public interface Handler {

    String handle(StringBuilder builder, List<FieldError> errors);

    default List<FieldError> filterByCode(List<FieldError> errors, String code) {
        return errors.stream().filter(fieldError -> Objects.equals(code, fieldError.getCode())).toList();
    }

    default List<FieldError> filterByCode(List<FieldError> errors, List<String> codes) {
        return errors.stream().filter(fieldError ->
                codes.contains(fieldError.getCode())).toList();
    }
}

