CREATE OR REPLACE procedure pr_deuda_oac_v3(pv_num_linea             in varchar2,
                                                 pn_cant_RegPorPagar      in number,
                                                 pn_cant_RegHistorico     in number,
                                                 xv_tot_deuda_total       out varchar2,
                                                 xv_mon_deuda_total       out varchar2,
                                                 xv_tipo_documento        out varchar2,
                                                 xv_numero_documento      out varchar2,
                                                 xv_nombres               out varchar2,
                                                 xv_apellidos             out varchar2,
                                                 xv_ciudad                out varchar2,
                                                 xv_direccion             out varchar2,
                                                 xc_DocPorPagar           out sys_refcursor,
                                                 xc_DocHistorico          out sys_refcursor,
                                                 xv_status                out varchar2,
                                                 xv_message               out varchar2) is

    vn_party_id         hz_cust_accounts.party_id%type;
    vv_cust_account_id  hz_cust_accounts.cust_account_id%type;
    vv_cust_cant        number;

begin

    -- FP-GlobalHitss-04/08/2020
    execute immediate 'alter session set nls_laNguage = ''LATIN AMERICAN SPANISH'' ';

    if pv_num_linea is not null then

        select count(distinct(cpa.cust_account_id))
        into vv_cust_cant
        from ts_oac_cl_cuenta_producto_all cpa
        where cpa.producto_identificacion = pv_num_linea;

        if (vv_cust_cant > 1) then
            begin
                select cpa.cust_account_id
                     , hca.party_id
                into vv_cust_account_id
                    , vn_party_id
                from hz_cust_accounts                   hca,
                     ts_oac_cl_cuenta_producto_all cpa
                where hca.cust_account_id = cpa.cust_account_id
                  and cpa.producto_identificacion = pv_num_linea
                  and cpa.estado_producto in ('A', 'S')
                  and rownum = 1;
            exception
                when no_data_found then
                    xv_status  := '2';
                    xv_message := 'Linea Desactiva';
                    goto FIN;
            end;
        else
            begin
                select cpa.cust_account_id
                     , hca.party_id
                into vv_cust_account_id
                    , vn_party_id
                from hz_cust_accounts                   hca,
                     ts_oac_cl_cuenta_producto_all cpa
                where hca.cust_account_id = cpa.cust_account_id
                  and cpa.producto_identificacion = pv_num_linea
                  and cpa.estado_producto in ('A', 'S')
                  and rownum = 1;
            exception
                when no_data_found then
                    xv_status  := '2';
                    xv_message := 'Linea No Existe';
                    goto FIN;
            end;
        end if;

        dbms_output.put_line(vv_cust_account_id);

        -- Obtener datos personales
        begin
            select p.person_first_name
                 , p.person_last_name
                 , p.jgzz_fiscal_code
                 , nvl(p.city, p.state)
                 , p.address1
                 , p.attribute2/*(select v.description
                  from fnd_flex_value_sets        vs,
                       fnd_flex_values_vl         v
                 where vs.flex_value_set_id = v.flex_value_set_id
                   and vs.flex_value_set_name = 'TS_OAC_CL_TIPO_DOC_IDENT_SUNAT'
                   and v.flex_value_meaning  = p.attribute2)*/
            into xv_nombres
                , xv_apellidos
                , xv_numero_documento
                , xv_ciudad
                , xv_direccion
                , xv_tipo_documento
            from hz_parties p
            where p.party_id = vn_party_id;
        exception
            when no_data_found then
                xv_nombres          := null;
                xv_apellidos        := null;
                xv_numero_documento := null;
                xv_ciudad           := null;
                xv_direccion        := null;
                xv_tipo_documento   := null;
            when too_many_rows then
                xv_nombres          := null;
                xv_apellidos        := null;
                xv_numero_documento := null;
                xv_ciudad           := null;
                xv_direccion        := null;
                xv_tipo_documento   := null;
            when others then
                xv_nombres          := null;
                xv_apellidos        := null;
                xv_numero_documento := null;
                xv_ciudad           := null;
                xv_direccion        := null;
                xv_tipo_documento   := null;
        end;

        -- Documentos con deuda
        open xc_DocPorPagar for
            select sel.*
            from (-- DEUDA POR VENCER SOLES REC
                     select rctt.name as tipo_documento
                          , rctt.global_attribute1 || decode(rctt.name, 'REC',' ' || to_char(aps.trx_date, 'month'),'') as nombre_documento
                          , hca.attribute19 as origen
                          , aps.trx_number as numero_documento
                          , aps.trx_date as emision
                          , aps.due_date as fecha_vencimiento
                          , decode(rctt.name, 'FIN', upper(to_char(aps.due_date, 'month')), upper(to_char(aps.trx_date, 'month'))) as mes
                          , fu_consulta_deuda_ldi(aps.trx_number,aps.amount_due_remaining - nvl(aps.amount_in_dispute, 0)) as monto
                          , aps.invoice_currency_code as moneda
                          , hca.account_number as cod_cuenta
                     from ar_payment_schedules_all aps,
                          ra_customer_trx_all      rct,
                          ra_cust_trx_types_all    rctt,
                          hz_cust_accounts         hca
                     where aps.customer_trx_id       = rct.customer_trx_id
                       and rct.bill_to_customer_id   = hca.cust_account_id
                       and APS.CUSTOMER_ID           = HCA.CUST_ACCOUNT_ID
                       and rct.cust_trx_type_id      = rctt.cust_trx_type_id
                       and aps.amount_due_remaining >= nvl(aps.amount_in_dispute, 0)
                       and aps.status                = 'OP'
                       and rct.invoice_currency_code = 'PEN'
                       -- { FP-GlobalHitss-04/08/2020
                       -- and rctt.name                in ('REC', 'DCE', 'BVA', 'BVP', 'ND','FAC')
                       and exists (select a.flex_value
                                   from fnd_flex_values_vl a
                                      , fnd_flex_value_sets b
                                   where a.flex_value_set_id   = b.flex_value_set_id
                                     and b.flex_value_set_name = 'DEUDA_OAC_TIPO_DOCUMENTO'
                                     and a.ENABLED_FLAG        = 'Y'
                                     and a.FLEX_VALUE          = rctt.name
                                     and (case a.ATTRIBUTE1 when 'N' then '1' when 'Y' then substr(aps.trx_number, a.ATTRIBUTE3, a.ATTRIBUTE4) end) =
                                         (case a.ATTRIBUTE1 when 'N' then '1' when 'Y' then a.ATTRIBUTE2                                       end)
                     )
                       -- and rct.interface_header_attribute9 ='-'
                       and (case rctt.name when 'FIN' then nvl(rct.interface_header_attribute9, '-') else rct.interface_header_attribute9 end) =
                           (case rctt.name when 'FIN' then nvl(rct.interface_header_attribute9, '-') else '-'                             end)
                       -- } FP-GlobalHitss-04/08/2020
                       and hca.cust_account_id       = vv_cust_account_id
                     /* -- { FP-GlobalHitss-04/08/2020
                      union all
                     select rctt.name as tipo_documento
                          , rctt.global_attribute1 as nombre_documento

                          , hca.attribute19 as origen
                          , aps.trx_number as numero_documento
                          , aps.trx_date as emision
                          , aps.due_date as fecha_vencimiento
                          , decode(rctt.name, 'FIN', upper(to_char(aps.due_date, 'month')), upper(to_char(aps.trx_date, 'month'))) as mes
                          , aps.amount_due_remaining - nvl(aps.amount_in_dispute, 0) as monto
                          , aps.invoice_currency_code as moneda
                           , hca.account_number as cod_cuenta
                       from ar_payment_schedules_all aps,
                            ra_customer_trx_all      rct,
                            ra_cust_trx_types_all    rctt,
                            hz_cust_accounts         hca
                      where aps.customer_trx_id       = rct.customer_trx_id
                        and rct.bill_to_customer_id   = hca.cust_account_id
                        and APS.CUSTOMER_ID           = HCA.CUST_ACCOUNT_ID
                        and rct.cust_trx_type_id      = rctt.cust_trx_type_id
                        and aps.amount_due_remaining >= nvl(aps.amount_in_dispute, 0)
                        and aps.status                = 'OP'
                        and rct.invoice_currency_code = 'PEN'
                        and rctt.name                 = 'FIN'
                        and hca.cust_account_id       = vv_cust_account_id
                       -- } FP-GlobalHitss-04/08/2020 */
                 ) sel
            where 1 = 1
              and rownum <= nvl(pn_cant_RegPorPagar,999999)
            order by sel.fecha_vencimiento
        ;

        -- Documentos con deuda totales
        begin
            select nvl(sum(aps.amount_due_remaining - nvl(aps.amount_in_dispute, 0)), 0) as monto
                 , nvl(max(aps.invoice_currency_code), '') as moneda
            into xv_tot_deuda_total
                , xv_mon_deuda_total
            from ar_payment_schedules_all aps,
                 ra_customer_trx_all      rct,
                 ra_cust_trx_types_all    rctt,
                 hz_cust_accounts         hca
            where aps.customer_trx_id       = rct.customer_trx_id
              and rct.bill_to_customer_id   = hca.cust_account_id
              and APS.CUSTOMER_ID           = HCA.CUST_ACCOUNT_ID
              and rct.cust_trx_type_id      = rctt.cust_trx_type_id
              and aps.amount_due_remaining >= nvl(aps.amount_in_dispute, 0)
              and aps.status                = 'OP'
              and rct.invoice_currency_code = 'PEN'
              -- { FP-GlobalHitss-04/08/2020
              -- and rctt.name                in ('REC', 'DCE', 'BVA', 'BVP', 'ND', 'FIN','FAC')
              and exists (select a.flex_value
                          from fnd_flex_values_vl a
                             , fnd_flex_value_sets b
                          where a.flex_value_set_id   = b.flex_value_set_id
                            and b.flex_value_set_name = 'DEUDA_OAC_TIPO_DOCUMENTO'
                            and a.ENABLED_FLAG        = 'Y'
                            and a.FLEX_VALUE          = rctt.name
                            and (case a.ATTRIBUTE1 when 'N' then '1' when 'Y' then substr(aps.trx_number, a.ATTRIBUTE3, a.ATTRIBUTE4) end) =
                                (case a.ATTRIBUTE1 when 'N' then '1' when 'Y' then a.ATTRIBUTE2                                       end)
            )
              -- { FP-GlobalHitss-04/08/2020
              and hca.cust_account_id       = vv_cust_account_id;
        exception
            when no_data_found then
                xv_tot_deuda_total := 0;
        end;

        -- Documentos pagados
        open xc_DocHistorico for
            select sel.*
            from (select rctt.name as tipo_documento
                       , rctt.global_attribute1 || decode(rctt.name, 'REC', ' ' || to_char(aps.trx_date, 'month'), '')  as nombre_documento
                       , aps.trx_number as numero_documento
                       , aps.trx_date as emision
                       , nvl(app.apply_date, adj.apply_date) as fecha_pago
                       , decode(rctt.name, 'FIN', upper(to_char(aps.due_date, 'month')), upper(to_char(aps.trx_date, 'month'))) as mes
                       , fu_consulta_pago_ldi(aps.trx_number,nvl(app.amount_applied, 0) + abs(nvl(adj.amount_adjust, 0) )) as monto --CelulaRecaudacion

                       , aps.invoice_currency_code as moneda
                       , hca.account_number as cod_cuenta
                  from hz_cust_accounts hca
                     , ar_payment_schedules_all aps
                     , ra_cust_trx_types_all rctt
                     , ra_customer_trx_all rct --CelulaRecaudacion
                     , (-- pagos
                      select max(app1.apply_date) as apply_date
                           , app1.applied_customer_trx_id
                           , sum(app1.amount_applied) amount_applied
                      from ar_receivable_applications_all app1
                      where 1 = 1
                        and app1.status = 'APP'
                        and app1.application_type = 'CASH'
                      group by app1.applied_customer_trx_id
                  ) app
                     , (-- ajuste
                      select max(adj1.apply_date) as apply_date
                           , adj1.customer_trx_id
                           , sum(adj1.amount) amount_adjust
                      from ar_adjustments_all adj1
                      where 1 = 1
                      group by adj1.customer_trx_id
                  ) adj
                  where  hca.cust_account_id       = aps.customer_id
                    and aps.customer_trx_id       = rct.customer_trx_id --CelulaRecaudacion
                    and aps.cust_trx_type_id      = rctt.cust_trx_type_id
                    and aps.customer_trx_id       = app.applied_customer_trx_id(+)
                    and aps.customer_trx_id       = adj.customer_trx_id(+)
                    and rct.interface_header_attribute9 ='-'
                    -- and aps.status                = 'CL'
                    and aps.amount_applied > 0
                    and aps.amount_due_original - aps.amount_due_remaining  >0
                    -- { FP-GlobalHitss-04/08/2020
                    -- and rctt.name                in ('REC', 'DCE', 'BVA', 'BVP', 'ND', 'FIN','FAC')
                    and exists (select a.flex_value
                                from fnd_flex_values_vl a
                                   , fnd_flex_value_sets b
                                where a.flex_value_set_id   = b.flex_value_set_id
                                  and b.flex_value_set_name = 'DEUDA_OAC_TIPO_DOCUMENTO'
                                  and a.ENABLED_FLAG        = 'Y'
                                  and a.FLEX_VALUE          = rctt.name
                                  and (case a.ATTRIBUTE1 when 'N' then '1' when 'Y' then substr(aps.trx_number, a.ATTRIBUTE3, a.ATTRIBUTE4) end) =
                                      (case a.ATTRIBUTE1 when 'N' then '1' when 'Y' then a.ATTRIBUTE2                                       end)
                  )
                    -- } FP-GlobalHitss-04/08/2020
                    and aps.invoice_currency_code = 'PEN'
                    and aps.customer_id           = vv_cust_account_id
                  order by aps.trx_date desc
                 ) sel
            where 1 = 1
              and rownum <= nvl(pn_cant_RegHistorico,999999)
        ;



        xv_status  := '0';
        xv_message := 'Exito';

    else
        xv_status  := '-1';
        xv_message := 'Ingrese Numero de Linea';
    end if;

    <<FIN>>
        null;
end;