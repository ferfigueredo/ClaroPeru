# archetype-java21

Arquetipo para crear microservicios de integración.

## Installación

```bash
mvn clean install
```

## Uso

```
mvn archetype:generate -DarchetypeGroupId=com.claro.common -DarchetypeArtifactId=archetype-java21 -DarchetypeVersion=1.1.0
```

## Parametros Requeridos
Se crea el proyecto en modo interactivo. Sera necesario proveer:
* `classPrefix` nomenclatura clases java PascalCase, **example: Account**
* `groupId` **examples: com.claro  , com.claro.pe**
* `artifactId` nombre de artefacto, **example: app-account**
* `version` nomenclatura SemVer, **example: 1.1.0**
* `package` seria el package name, **example: com.claro.accounts**

## Datos de interes
- **Implementacion de HttpComponentsClientHttpRequestFactory**: En el proyecto se utiliza HttpComponentsClientHttpRequestFactory 
  con una implementacion de PoolingHttpClientConnectionManager, en ella se configuran los valores por default para deadline-timeout, 
  read-timeout, connect-timeout, max-total y max-per-route. Asimismo en el componente client se configuran los parametros especificos 
  de read-timeout, connect-timeout, max-per-route para una ruta determinada. Para mas información se adjunta un enlace de 
  referencia (https://docs.spring.io/spring-framework/reference/integration/rest-clients.html#rest-request-factories)

- **Spring boot 3.2.0**: reference (https://docs.spring.io/spring-boot/docs/3.2.0/reference/html/)

## Example
- Despues de haber hecho la instalacion de archetype-java21 nos posicionamos donde querramos generar el proyecto:\
![step1.png](./images/step1.png)

- Ejecutamos el comando de **Uso**:\
![step2.png](./images/step2.png)

- Completamos los datos de parameros requeridos y al final escribimos '***y***' para generarlo:\
![step3.png](./images/step3.png)

- Validamos que se haga generado correctamente:\
![step4.png](./images/step4.png)

## Notas
- **En Windows:** Si por algun motivo no se crea correctamente la app , abrir la terminal(CMD) como administrador
