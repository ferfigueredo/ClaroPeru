package ${package}.kafka.errorhandler;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.listener.CommonErrorHandler;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.kafka.support.serializer.DeserializationException;

import java.util.Objects;

@Slf4j
public class KafkaErrorHandler implements CommonErrorHandler {


    /**
     * Handler Error.
     *
     * @param thrownException consumerRecord
     */
    @Override
    public boolean handleOne(Exception thrownException, ConsumerRecord<?, ?> consumerRecord, Consumer<?, ?> consumer,
            MessageListenerContainer container) {

        try {
            String topic = consumerRecord.topic();
            long offset = consumerRecord.offset();
            int partition = consumerRecord.partition();

            if (Objects.nonNull(consumerRecord.value())) {
                log.info("ConsumerRecord value: {}", consumerRecord.value());
            }
            if (thrownException.getClass().equals(DeserializationException.class)) {
                DeserializationException exception = (DeserializationException) thrownException;
                String malformedMessage = exception.getMessage();
                log.warn("Se ignora mensaje con topic: {}, offset: {} "
                                + "- mensaje con formato incorrecto: {} , exception: {}", topic, offset, malformedMessage,
                        exception.getLocalizedMessage());
            } else {
                log.warn("Se ignora mensaje con topic: {}, offset: {}, partition: {} - exception: {}",
                        topic, offset, partition, thrownException.getMessage());
            }
        } catch (Exception e) {
            log.error("No se pudieron recuperar los valores de topic, offset y partition - exception: {}", e.getMessage());
            return false;
        }
        return true;
    }


}
