package ${package}.kafka.service;


import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.handler.annotation.Payload;

import ${package}.kafka.dto.KFKDummyDTO;


public interface KafkaConsumerService {

    void retentionConsumer(@Payload KFKDummyDTO consumerRecord, Acknowledgment ack);
 
}
