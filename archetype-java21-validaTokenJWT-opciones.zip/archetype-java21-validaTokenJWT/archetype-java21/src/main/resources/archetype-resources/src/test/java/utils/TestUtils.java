package ${package}.utils;

import ${package}.dto.request.${classPrefix}Request;
import ${package}.dto.response.${classPrefix}Response;
import ${package}.dto.response.ResultDto;
#if( $includeDB == 'true' )
import ${package}.model.Example;
import java.util.Optional;
#end
import org.springframework.http.HttpStatus;


public class TestUtils {

    public static final String CELLULAR_NUMBER = "123456789";

    public static ${classPrefix}Request exampleRequest() {
        return ${classPrefix}Request.builder()
                .cellularNumber(CELLULAR_NUMBER)
                .build();
    }

    public static ${classPrefix}Response<ResultDto> exampleResponse() {
        ResultDto resultDto = new ResultDto(TestUtils.CELLULAR_NUMBER);
        return new ${classPrefix}Response<>(HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.value(), resultDto);
    }

#if( $includeDB == 'true' )
    public static Optional<Example> example() {
        Example example = Example.builder()
                .id(1)
                .name("test")
                .phoneNumber(TestUtils.CELLULAR_NUMBER)
                .build();

        return Optional.of(example);
    }
#end
}

