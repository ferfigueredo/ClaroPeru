package ${package}.service;
#if( $includeRestClient == 'true' )
import ${package}.client.UserClient;
#end
import ${package}.dto.response.ResultDto;
#if( $includeDB == 'true' )
import ${package}.repository.ExampleRepository;
#end
import ${package}.utils.TestUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import com.claro.common.claro.dto.response.Response;
import ${package}.service.impl.${classPrefix}ServiceImpl;

#if( $includeDB == 'true' )
import java.util.Optional;
import static org.mockito.ArgumentMatchers.any;
#end 
import static org.junit.jupiter.api.Assertions.assertEquals;

#if( $includeDB == 'true' || $includeRestClient == 'true')
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.Mock;
#end 

@ExtendWith(MockitoExtension.class)
class ${classPrefix}ServiceTest {

#if( $includeRestClient == 'true' )
    @Mock
    private UserClient userClient;
#end
#if( $includeDB == 'true' )
    @Mock
    private ExampleRepository exampleRepository;
#end
    @InjectMocks
    private ${classPrefix}ServiceImpl service;

#if( $includeDB == 'true' )
    @Test
    @DisplayName("example ok from db")
    void whenExampleOkDb() {		
        when(this.exampleRepository.findOneByPhoneNumber(any())).thenReturn(TestUtils.example());		
        Response<ResultDto> response = this.service.example(TestUtils.exampleRequest());
        assertEquals(HttpStatus.OK.getReasonPhrase() , response.message());
        assertEquals(HttpStatus.OK.value() , response.code());
        assertEquals(TestUtils.CELLULAR_NUMBER , response.data().getResult());
#if( $includeDB == 'true' )
        verify(this.exampleRepository, times(1)).findOneByPhoneNumber(TestUtils.CELLULAR_NUMBER);
#end
#if( $includeRestClient == 'true' )
        verify(this.userClient, times(0)).getResponseFromIntegration(TestUtils.CELLULAR_NUMBER);
#end
    }
#end

    @Test
    @DisplayName("example ok from client")
    void whenExampleOkClient() {
#if( $includeDB == 'true' )
        when(this.exampleRepository.findOneByPhoneNumber(any())).thenReturn(Optional.empty());
#end
#if( $includeRestClient == 'true' )
        when(this.userClient.getResponseFromIntegration(TestUtils.CELLULAR_NUMBER)).thenReturn(new Response<>(HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.value(), new ResultDto(TestUtils.CELLULAR_NUMBER)));
#end
        Response<ResultDto> response = this.service.example(TestUtils.exampleRequest());
        assertEquals(HttpStatus.OK.getReasonPhrase() , response.message());
        assertEquals(HttpStatus.OK.value() , response.code());
        assertEquals(TestUtils.CELLULAR_NUMBER , response.data().getResult());
#if( $includeDB == 'true' )
        verify(this.exampleRepository, times(1)).findOneByPhoneNumber(TestUtils.CELLULAR_NUMBER);
#end
#if( $includeRestClient == 'true' )
        verify(this.userClient, times(1)).getResponseFromIntegration(TestUtils.CELLULAR_NUMBER);
#end
    }
}