package ${package}.controller.impl;

import ${package}.dto.request.${classPrefix}Request;
import ${package}.dto.response.ResultDto;
import ${package}.service.${classPrefix}Service;
import ${package}.controller.${classPrefix}Controller;



import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.claro.common.claro.dto.response.Response;



@Slf4j
@RestController
@Tag(name = "${classPrefix}", description = "Controller para ...")
@RequiredArgsConstructor
public class ${classPrefix}ControllerImpl implements ${classPrefix}Controller {

    private final ${classPrefix}Service service;

    public Response<ResultDto> example(@RequestBody ${classPrefix}Request request) {
        return this.service.example(request);
    }

}