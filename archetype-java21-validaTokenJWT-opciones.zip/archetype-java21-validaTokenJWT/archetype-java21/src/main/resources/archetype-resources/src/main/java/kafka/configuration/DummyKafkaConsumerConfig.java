package ${package}.kafka.configuration;

import ${package}.kafka.errorhandler.KafkaErrorHandler;
import ${package}.kafka.dto.KFKDummyDTO;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class DummyKafkaConsumerConfig {

    @Value("${kafka.dummy.consumer.bootstrap-servers}")
    private String bootstrapServer;
    @Value("${kafka.consumer.auto-reset-offset}")
    private String autoResetOffset;
    @Value("${kafka.consumer.max-poll-records}")
    private int maxPollRecords;
    @Value("${kafka.consumer.max-poll-interval-ms}")
    private int maxPollIntervalMs;
    @Value("${kafka.consumer.concurrency}")
    private int concurrency;

    /**
     * Instantiates a new Kafka consumer config.
     */
    public DummyKafkaConsumerConfig() {
    }

    /**
     * Kafka configuration properties.
     *
     * @return Kafka configuration map
     */
    public Map<String, Object> consumerConfig() {
        Map<String, Object> config = new HashMap<>();

        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServer);
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoResetOffset);
        config.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, maxPollRecords);
        config.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, maxPollIntervalMs);
        config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);

        return config;
    }

    /**
     * Consumer factory configuration.
     *
     * @return Consumer factory.
     */
    @Bean
    public ConsumerFactory<String, KFKDummyDTO> mtxTransactionDtoConsumerFactory() {

        JsonDeserializer<KFKDummyDTO> valueDeserializer = new JsonDeserializer<>(KFKDummyDTO.class);
        valueDeserializer.setRemoveTypeHeaders(false);
        valueDeserializer.addTrustedPackages("*");
        valueDeserializer.setUseTypeMapperForKey(true);
        return new DefaultKafkaConsumerFactory<>(
                consumerConfig(), new StringDeserializer(),
                new ErrorHandlingDeserializer<>(valueDeserializer));
    }

    /**
     * Kafka listener container factory configuration.
     *
     * @param consumerFactory Consumer factory
     * @return Kafka listener container factory
     */
    @Bean
    public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, KFKDummyDTO>> kfkDummyDtoKafkaListenerContainerFactory(
            ConsumerFactory<String, KFKDummyDTO> consumerFactory) {

        ConcurrentKafkaListenerContainerFactory<String, KFKDummyDTO> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory);
        factory.setCommonErrorHandler(new KafkaErrorHandler());
        factory.setConcurrency(concurrency);
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL);
        return factory;
    }

}
