#if( $includeRestClient == 'true' )
package ${package}.client;

import ${package}.configuration.restclient.RestClientCustom;
import com.claro.common.claro.dto.response.Response;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import java.util.Map;
import org.apache.hc.client5.http.HttpRoute;
import org.apache.hc.client5.http.config.ConnectionConfig;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.core5.function.Resolver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

@Slf4j
@Component
@RequiredArgsConstructor
public class UserClient {
    
    @Autowired
    private RestClient restClient;
    
    @Autowired
    private Map<String, Resolver<HttpRoute, ConnectionConfig>> resolverMap;
    
    @Autowired
    private PoolingHttpClientConnectionManager connectionManager;
    
    @Value("${user.rest-client.read-timeout}")
    private int readTimeout;
    
    @Value("${user.rest-client.connect-timeout}")
    private int connectTimeout;
    
    @Value("${user.rest-client.max-per-route}")
    private int maxPerRoute;
    
    @Value("${user.path}")
    private String path;
    
    @Value("${user.url}")
    private String host;
    
    @PostConstruct
    public void iniatilize() {
        RestClientCustom.chargeCustomRoute(host + path, maxPerRoute, readTimeout, connectTimeout, resolverMap, connectionManager);
    }

    public Response getResponseFromIntegration(String cellularNumber) {
        log.debug(":::::: Integration getResponseFromIntegration: {} ::::::", host + path);
        return this.restClient.get()
                .uri(host + path, cellularNumber)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .body(new ParameterizedTypeReference<>() {
                });
    }
}
#end