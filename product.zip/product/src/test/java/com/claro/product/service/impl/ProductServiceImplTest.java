package com.claro.product.service.impl;

import com.claro.common.claro.dto.response.PageResponse;
import com.claro.product.dto.ProductDto;
import com.claro.product.exception.ProductException;
import com.claro.product.mapper.ProductMapper;
import com.claro.product.projection.ProductView;
import com.claro.product.repository.ProductRepository;
import com.claro.product.utils.TestUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;

import static com.claro.product.utils.TestUtils.PAGE_NUMBER;
import static com.claro.product.utils.TestUtils.PAGE_SIZE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProductServiceImplTest {
    @Mock
    private ProductRepository productRepository;

    @Mock
    private ProductMapper productMapper;

    @InjectMocks
    private ProductServiceImpl productService;

    private Page<ProductView> productPage;
    private PageResponse<List<ProductDto>> productsResponse;

    @BeforeEach
    void setUp() {
        productPage = new PageImpl<>(List.of(mock(ProductView.class)));
        productsResponse = TestUtils.buildGetAllProductsInfoResponse();
        ReflectionTestUtils.setField(productService, "primarySystem", TestUtils.PRIMARY_SYSTEM_VALUE);
        ReflectionTestUtils.setField(productService, "secondarySystem", TestUtils.SECONDARY_SYSTEM_VALUE);
    }

    @Test
    void testGetAllProductsWithLineNumber() {
        when(productRepository.findByLineNumber(anyString(), anyString(), anyString(), any(PageRequest.class)))
                .thenReturn(productPage);
        when(productMapper.toGetAllProductsResponse(any())).thenReturn(productsResponse);

        var response = productService.getAllProducts(TestUtils.LINE_NUMBER, null, PageRequest.of(PAGE_NUMBER, PAGE_SIZE));

        assertNotNull(response);
        verify(productRepository, times(1)).findByLineNumber(anyString(), anyString(), anyString(), any(PageRequest.class));
        verify(productMapper, times(1)).toGetAllProductsResponse(any());
    }

    @Test
    void testGetAllProductsWithCustomerId() {
        when(productRepository.findByCustomerId(anyList(), any(PageRequest.class))).thenReturn(productPage);
        when(productMapper.toGetAllProductsResponse(any())).thenReturn(productsResponse);

        var response = productService.getAllProducts(null, TestUtils.CUSTOMER_ID, PageRequest.of(PAGE_NUMBER, PAGE_SIZE));

        assertNotNull(response);
        verify(productRepository, times(1)).findByCustomerId(anyList(), any(PageRequest.class));
        verify(productMapper, times(1)).toGetAllProductsResponse(any());
    }

    @Test
    void testGetAllProductsValidationException() {
        var exception = assertThrows(ProductException.class, () -> productService.getAllProducts(TestUtils.LINE_NUMBER, TestUtils.CUSTOMER_ID, PageRequest.of(PAGE_NUMBER, PAGE_SIZE)));

        assertEquals(HttpStatus.BAD_REQUEST.value(), exception.getErrorDTO().getCode());
        verify(productRepository, never()).findByLineNumber(anyString(), anyString(), anyString(), any(PageRequest.class));
        verify(productRepository, never()).findByCustomerId(anyList(), any(PageRequest.class));
    }

}
