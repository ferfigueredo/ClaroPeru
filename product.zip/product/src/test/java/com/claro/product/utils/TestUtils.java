package com.claro.product.utils;

import com.claro.common.claro.dto.response.PageResponse;
import com.claro.product.dto.LineDto;
import com.claro.product.dto.ProductDto;

import java.util.List;

public class TestUtils {

    public static final String LINE_NUMBER = "123456789";
    public static final List<String> CUSTOMER_ID = List.of("1", "2");
    public static final String PRIMARY_SYSTEM_VALUE = "BSCS";
    public static final String SECONDARY_SYSTEM_VALUE = "BSCSIX";
    public static final int DEFAULT_TIME_MILLISECONDS = 10000;

    public static final int PAGE_NUMBER = 0;
    public static final int PAGE_SIZE = 10;



    public static PageResponse<List<ProductDto>> buildGetAllProductsInfoResponse() {
        return PageResponse.<List<ProductDto>>builder().code(200).message("Operación exitosa").data(List.of(buildProductDto())).build();
    }

    public static ProductDto buildProductDto() {
        return ProductDto.builder().customerId("1").line(buildLineDto()).build();
    }

    private static LineDto buildLineDto() {
        return LineDto.builder().lineNumber(LINE_NUMBER).planDescription("Plan Description").coId("CO123").build();
    }
}

