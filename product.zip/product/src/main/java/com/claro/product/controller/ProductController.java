package com.claro.product.controller;

import com.claro.common.claro.dto.response.PageResponse;
import com.claro.common.claro.exceptions.dto.ErrorDTO;
import com.claro.product.dto.ProductDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.constraints.Min;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * Controlador para la consulta paginada de productos/líneas de clientes.
 */
public interface ProductController {
    /**
     * Obtiene una lista paginada de productos/líneas asociadas a los clientes.
     *
     * @param pageNumber       Número de página (inicia en 0, opcional, por defecto 0)
     * @param pageSize         Tamaño de página (opcional, por defecto 10)
     * @param lineNumber       Número de línea (opcional)
     * @param customerId       Lista de IDs de cliente (opcional, permite múltiples valores)
     * @param xRequestId       ID de correlación para trazabilidad (requerido)
     * @param xCorrelationId   ID de correlación para trazabilidad (requerido)
     * @param xClientVersionId Versión del cliente (requerido)
     * @return Respuesta paginada con la lista de productos
     */
    @Operation(
            operationId = "getAllProducts",
            summary = "Obtiene una lista paginada de productos/líneas del cliente",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Consulta exitosa",
                            useReturnTypeSchema = true
                    ),
                    @ApiResponse(
                            responseCode = "400",
                            description = "Solicitud incorrecta",
                            content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))
                    ),
                    @ApiResponse(
                            responseCode = "401",
                            description = "No autorizado",
                            content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))
                    ),
                    @ApiResponse(
                            responseCode = "404",
                            description = "Recurso no encontrado",
                            content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))
                    ),
                    @ApiResponse(
                            responseCode = "500",
                            description = "Error interno del servidor",
                            content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorDTO.class))
                    )
            }
    )
    @GetMapping(value = "/api/v1/products", produces = {"application/json"})
    ResponseEntity<PageResponse<List<ProductDto>>> getAllProducts(
            @Parameter(
                    name = "page-number",
                    description = "Número de página (inicia en 0)",
                    in = ParameterIn.QUERY
            )
            @Min(0) @RequestParam(value = "page-number", required = false, defaultValue = "0") Integer pageNumber,
            @Parameter(
                    name = "page-size",
                    description = "Tamaño de página",
                    in = ParameterIn.QUERY
            )
            @Min(1) @RequestParam(value = "page-size", required = false, defaultValue = "10") Integer pageSize,
            @Parameter(
                    name = "line-number",
                    description = "Número de línea",
                    in = ParameterIn.QUERY
            )
            @RequestParam(value = "line-number", required = false) String lineNumber,
            @Parameter(
                    name = "customer-id",
                    description = "Lista de IDs de cliente",
                    in = ParameterIn.QUERY
            )
            @RequestParam(value = "customer-id", required = false) List<String> customerId,
            @Parameter(
                    name = "x-request-id",
                    description = "ID de correlación para trazabilidad",
                    required = true,
                    example = "3a16264f-fcd4-4b41-8a5d-61509395642e"
            )
            @RequestHeader("x-request-id") String xRequestId,
            @Parameter(
                    name = "x-correlation-id",
                    description = "ID de correlación para trazabilidad",
                    required = true,
                    example = "29db9cb2-f77a-478e-829f-3c6ba60acb76"
            )
            @RequestHeader("x-correlation-id") String xCorrelationId,
            @Parameter(
                    name = "x-client-version-id",
                    description = "Versión del cliente",
                    required = true,
                    example = "1.0.0"
            )
            @RequestHeader("x-client-version-id") String xClientVersionId
    );

}
