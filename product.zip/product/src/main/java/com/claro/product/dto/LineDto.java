package com.claro.product.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LineDto {

    private String coId;
    private String lineNumber;
    private String type;
    private String planCode;
    private String planDescription;
    private String productOriginCode;
    private String alias;
    private String stateId;
    private String stateDescription;
    private String serviceType;
    private String billingCycle;
    private String billingAddress;

}
