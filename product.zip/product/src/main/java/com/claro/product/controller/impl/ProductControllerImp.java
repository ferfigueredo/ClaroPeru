package com.claro.product.controller.impl;


import com.claro.common.claro.dto.response.PageResponse;
import com.claro.product.controller.ProductController;
import com.claro.product.dto.ProductDto;
import com.claro.product.service.ProductService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@Tag(name = "Product")
@RestController
@RequiredArgsConstructor
@RequestMapping("${app.api}")
public class ProductControllerImp implements ProductController {

    private final ProductService service;

    /**
     * @see ProductController#getAllProducts(Integer, Integer, String, List, String, String, String)
     */
    @Override
    public ResponseEntity<PageResponse<List<ProductDto>>> getAllProducts(Integer pageNumber, Integer pageSize, String lineNumber, List<String> customerId, String xRequestId, String xCorrelationId, String xClientVersionId) {
        return new ResponseEntity<>(service.getAllProducts(lineNumber, customerId, PageRequest.of(pageNumber, pageSize)), HttpStatus.OK);
    }

}
