package com.claro.product.service;

import com.claro.common.claro.dto.response.PageResponse;
import com.claro.product.dto.ProductDto;
import org.springframework.data.domain.PageRequest;

import java.util.List;

public interface ProductService {
    /**
     * Retrieves a paginated list of products/lines associated with a line number or a list of customer IDs.
     * At least one parameter must be provided: line number or customer IDs.
     *
     * @param lineNumber  Line number (optional).
     * @param customerId  List of customer IDs (optional).
     * @param pageRequest Pagination parameters.
     * @return {@link PageResponse} containing a paginated list of {@link ProductDto}.
     */
    PageResponse<List<ProductDto>> getAllProducts(String lineNumber, List<String> customerId, PageRequest pageRequest);
}
