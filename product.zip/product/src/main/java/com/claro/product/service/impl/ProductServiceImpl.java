package com.claro.product.service.impl;

import com.claro.common.claro.dto.response.PageResponse;
import com.claro.common.claro.exceptions.dto.ErrorDTO;
import com.claro.product.dto.ProductDto;
import com.claro.product.exception.ProductException;
import com.claro.product.mapper.ProductMapper;
import com.claro.product.projection.ProductView;
import com.claro.product.repository.ProductRepository;
import com.claro.product.service.ProductService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.claro.product.exception.ProductExceptionHandler.SERVICE_ERROR;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final ProductMapper mapper;
    @Value("${product.primary-system}")
    String primarySystem;
    @Value("${product.secondary-system}")
    String secondarySystem;

    private static boolean present(String s) {
        return s != null && !s.isBlank();
    }

    private static boolean present(List<String> s) {
        return s != null && !s.isEmpty();
    }

    private static void paramsValidation(String lineNumber, List<String> customerId) {
        if (present(lineNumber) == present(customerId)) {
            throw new ProductException(ErrorDTO.builder().code(HttpStatus.BAD_REQUEST.value()).status(HttpStatus.BAD_REQUEST.name()).message(SERVICE_ERROR)
                    .detail("One of 'line-number' or 'customer-id' must be provided").type("IllegalArgumentException").subType("IDF1").build());
        }
    }

    /**
     * See {@link ProductService#getAllProducts(String, List, PageRequest)}
     */
    @Override
    public PageResponse<List<ProductDto>> getAllProducts(String lineNumber, List<String> customerId, PageRequest pageRequest) {
        paramsValidation(lineNumber, customerId);
        var page = present(lineNumber) ? this.findByLineNumber(lineNumber, pageRequest) : this.findByCustomerId(customerId, pageRequest);
        return mapper.toGetAllProductsResponse(page);
    }

    private Page<ProductView> findByLineNumber(String lineNumber, PageRequest pageRequest) {
        log.info("::: Finding products for lineNumber: {} :::", lineNumber);
        var products = productRepository.findByLineNumber(lineNumber, primarySystem, secondarySystem, pageRequest);
        log.info("::: Products successfully retrieved for lineNumber: {} :::", lineNumber);
        return products;
    }

    private Page<ProductView> findByCustomerId(List<String> customerId, Pageable pageable) {
        log.info("::: Finding products for customerId: {} :::", customerId);
        var response = productRepository.findByCustomerId(customerId, pageable);
        log.info("::: Products successfully retrieved for customerId: {} :::", customerId);
        return response;
    }

}
