package com.claro.product.exception;

import com.claro.common.claro.exceptions.dto.ErrorDTO;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import static com.claro.product.exception.ProductExceptionHandler.ERROR;
import static com.claro.product.exception.ProductExceptionHandler.SERVICE_ERROR;

@Getter
@Setter
public class ProductException extends RuntimeException {

    private final ErrorDTO errorDTO;

    public ProductException(ErrorDTO errorDTO) {
        super(errorDTO.getMessage());
        this.errorDTO = errorDTO;
    }

    public ProductException() {
        super("Product Exception");
        this.errorDTO = ErrorDTO.builder().code(HttpStatus.INTERNAL_SERVER_ERROR.value()).detail("There is an internal problem").message(SERVICE_ERROR).status(HttpStatus.INTERNAL_SERVER_ERROR.name()).subType(ERROR).build();
    }
}
