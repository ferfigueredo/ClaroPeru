package com.claro.product.repository;

import com.claro.product.entity.ProductEntity;
import com.claro.product.projection.ProductView;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

import static com.claro.product.utils.ConstantUtils.COUNT_PRODUCTS_BY_CUSTOMER_ID;
import static com.claro.product.utils.ConstantUtils.COUNT_PRODUCTS_BY_LINE_NUMBER;
import static com.claro.product.utils.ConstantUtils.FIND_PRODUCTS_BY_CUSTOMER_ID;
import static com.claro.product.utils.ConstantUtils.FIND_PRODUCTS_BY_LINE_NUMBER;


public interface ProductRepository extends JpaRepository<ProductEntity, String> {

    /**
     * Find products by customer id.
     *
     * @param customerId Customer id.
     * @param pageable   Pageable object.
     * @return Page of ProductView.
     */
    @Query(value = FIND_PRODUCTS_BY_CUSTOMER_ID, countQuery = COUNT_PRODUCTS_BY_CUSTOMER_ID, nativeQuery = true)
    Page<ProductView> findByCustomerId(@Param("customerId") List<String> customerId, Pageable pageable);

    /**
     * Find products by line number.
     *
     * @param lineNumber      Line number.
     * @param primarySystem   Primary system.
     * @param secondarySystem Secondary system.
     * @param pageable        Pageable object.
     * @return Page of ProductView.
     */
    @Query(value = FIND_PRODUCTS_BY_LINE_NUMBER, countQuery = COUNT_PRODUCTS_BY_LINE_NUMBER, nativeQuery = true)
    Page<ProductView> findByLineNumber(@Param("lineNumber") String lineNumber, @Param("primarySystem") String primarySystem, @Param("secondarySystem") String secondarySystem, Pageable pageable);

}
