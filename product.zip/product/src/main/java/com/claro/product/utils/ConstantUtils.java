package com.claro.product.utils;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ConstantUtils {

    public static final String FIND_PRODUCTS_BY_CUSTOMER_ID = """
            SELECT
                  CP.CLIENTE_ID         AS customerId,
                  PL.NUMERO             AS lineNumber,
                  P.CODIGO_EXTERNO      AS coId,
                  P.CODIGO_ORIGEN       AS productOriginCode,
                  P.ALIAS               AS alias,
                  PPS.NOMBRE            AS descriptionPlan,
                  PPS.TIPO_PRODUCTO     AS lineType,
                  PPS.CODIGO_EXTERNO    AS linePlanCode,
                  PPS.TIPO_SERVICIO     AS serviceType,
                  PE.ESTADO_ID          AS stateId,
                  EST.DESCRIPCION       AS stateDescription,
                  FAC.DIRECCION_FACTURACION AS billingAddress,
                  FAC.CICLO_FACTURACION AS billingCycle
            FROM CU_CLIENTE_PRODUCTO CP
                  LEFT JOIN CU_CUENTA_FACTURACION FAC ON FAC.CLIENTE_ID = CP.CLIENTE_ID
                  JOIN CU_PRODUCTO P            ON CP.PRODUCTO_ID = P.PRODUCTO_ID
                  LEFT JOIN CU_PRODUCTO P1 ON P.CODIGO_ORIGEN = P1.CODIGO_ORIGEN AND P.SISTEMA_ORIGEN='BSCS' AND P1.SISTEMA_ORIGEN='BSCSIX'
                  JOIN CU_PRODUCTO_PLAN_SERVICIO PPS ON P.PRODUCTO_ID = PPS.PRODUCTO_ID
                  JOIN CU_PRODUCTO_LINEA PL      ON P.PRODUCTO_ID = PL.PRODUCTO_ID
                  JOIN CU_PRODUCTO_ESTADO PE     ON P.PRODUCTO_ID = PE.PRODUCTO_ID
                  JOIN CU_ESTADOS_PRODUCTO EST   ON PE.ESTADO_ID = EST.ESTADO_ID
            WHERE CP.CLIENTE_ID IN (:customerId)
                          AND CP.FLAG_ACTIVO = 1
                          AND PPS.FLAG_ACTIVO = 1
                          AND PL.FLAG_ACTIVO = 1
                          AND PE.FLAG_ACTIVO = 1
                          AND PE.ESTADO_ID NOT IN ('6','1')
            ORDER BY P.PRODUCTO_ID, PPS.PLAN_ID
            """;

    public static final String COUNT_PRODUCTS_BY_CUSTOMER_ID = """
            SELECT COUNT(*)
            FROM CU_CLIENTE_PRODUCTO CP
                  LEFT JOIN CU_CUENTA_FACTURACION FAC ON FAC.CLIENTE_ID = CP.CLIENTE_ID
                  JOIN CU_PRODUCTO P            ON CP.PRODUCTO_ID = P.PRODUCTO_ID
                  LEFT JOIN CU_PRODUCTO P1 ON P.CODIGO_ORIGEN = P1.CODIGO_ORIGEN AND P.SISTEMA_ORIGEN='BSCS' AND P1.SISTEMA_ORIGEN='BSCSIX'
                  JOIN CU_PRODUCTO_PLAN_SERVICIO PPS ON P.PRODUCTO_ID = PPS.PRODUCTO_ID
                  JOIN CU_PRODUCTO_LINEA PL      ON P.PRODUCTO_ID = PL.PRODUCTO_ID
                  JOIN CU_PRODUCTO_ESTADO PE     ON P.PRODUCTO_ID = PE.PRODUCTO_ID
                  JOIN CU_ESTADOS_PRODUCTO EST   ON PE.ESTADO_ID = EST.ESTADO_ID
            WHERE CP.CLIENTE_ID IN (:customerId)
                          AND CP.FLAG_ACTIVO = 1
                          AND PPS.FLAG_ACTIVO = 1
                          AND PL.FLAG_ACTIVO = 1
                          AND PE.FLAG_ACTIVO = 1
                          AND PE.ESTADO_ID NOT IN ('6','1')
            """;

    public static final String FIND_PRODUCTS_BY_LINE_NUMBER = """ 
            SELECT
                  CP.CLIENTE_ID         AS customerId,
                  PL.NUMERO             AS lineNumber,
                  C.CODIGO_EXTERNO      AS clientCustomerId,
                  PE.ESTADO_ID          AS stateId,
                  PRT.NUMERO_DOCUMENTO  AS documentNumber,
                  PRT.TIPO_DOCUMENTO    AS documentType,
                  PRT.ALIAS             AS documentAlias,
                  P.CODIGO_EXTERNO      AS coId,
                  P.CODIGO_ORIGEN       AS productOriginCode,
                  P.ALIAS               AS alias,
                  PPS.NOMBRE            AS descriptionPlan,
                  PPS.TIPO_PRODUCTO     AS lineType,
                  PPS.CODIGO_EXTERNO    AS linePlanCode,
                  PPS.TIPO_SERVICIO     AS serviceType,
                  EST.DESCRIPCION       AS stateDescription,
                  FAC.DIRECCION_FACTURACION AS billingAddress,
                  FAC.CICLO_FACTURACION AS billingCycle
            FROM CU_PARTICIPANTE PRT
                  INNER JOIN CU_CLIENTE C ON C.PARTICIPANTE_ID = PRT.PARTICIPANTE_ID
                  INNER JOIN CU_CLIENTE_PRODUCTO CP ON CP.CLIENTE_ID = C.CLIENTE_ID
                  LEFT JOIN CU_CUENTA_FACTURACION FAC ON FAC.CLIENTE_ID = CP.CLIENTE_ID
                  JOIN CU_PRODUCTO P            ON CP.PRODUCTO_ID = P.PRODUCTO_ID
                  LEFT JOIN CU_PRODUCTO P1 ON P.CODIGO_ORIGEN = P1.CODIGO_ORIGEN AND P.SISTEMA_ORIGEN='BSCS' AND P1.SISTEMA_ORIGEN='BSCSIX'
                  JOIN CU_PRODUCTO_PLAN_SERVICIO PPS ON P.PRODUCTO_ID = PPS.PRODUCTO_ID
                  JOIN CU_PRODUCTO_LINEA PL      ON P.PRODUCTO_ID = PL.PRODUCTO_ID
                  JOIN CU_PRODUCTO_ESTADO PE     ON P.PRODUCTO_ID = PE.PRODUCTO_ID
                  JOIN CU_ESTADOS_PRODUCTO EST   ON PE.ESTADO_ID = EST.ESTADO_ID
            WHERE PL.NUMERO = :lineNumber
                          AND CP.FLAG_ACTIVO = 1
                          AND PPS.FLAG_ACTIVO = 1
                          AND PL.FLAG_ACTIVO = 1
                          AND PE.FLAG_ACTIVO = 1
                          AND PE.ESTADO_ID NOT IN ('6','1')
            ORDER BY P.PRODUCTO_ID, PPS.PLAN_ID
            """;

    public static final String COUNT_PRODUCTS_BY_LINE_NUMBER = """
            SELECT COUNT(*)
            FROM CU_PARTICIPANTE PRT
                  INNER JOIN CU_CLIENTE C ON C.PARTICIPANTE_ID = PRT.PARTICIPANTE_ID
                  INNER JOIN CU_CLIENTE_PRODUCTO CP ON CP.CLIENTE_ID = C.CLIENTE_ID
                  LEFT JOIN CU_CUENTA_FACTURACION FAC ON FAC.CLIENTE_ID = CP.CLIENTE_ID
                  JOIN CU_PRODUCTO P            ON CP.PRODUCTO_ID = P.PRODUCTO_ID
                  LEFT JOIN CU_PRODUCTO P1 ON P.CODIGO_ORIGEN = P1.CODIGO_ORIGEN AND P.SISTEMA_ORIGEN='BSCS' AND P1.SISTEMA_ORIGEN='BSCSIX'
                  JOIN CU_PRODUCTO_PLAN_SERVICIO PPS ON P.PRODUCTO_ID = PPS.PRODUCTO_ID
                  JOIN CU_PRODUCTO_LINEA PL      ON P.PRODUCTO_ID = PL.PRODUCTO_ID
                  JOIN CU_PRODUCTO_ESTADO PE     ON P.PRODUCTO_ID = PE.PRODUCTO_ID
                  JOIN CU_ESTADOS_PRODUCTO EST   ON PE.ESTADO_ID = EST.ESTADO_ID
            WHERE PL.NUMERO = :lineNumber
                          AND CP.FLAG_ACTIVO = 1
                          AND PPS.FLAG_ACTIVO = 1
                          AND PL.FLAG_ACTIVO = 1
                          AND PE.FLAG_ACTIVO = 1
                          AND PE.ESTADO_ID NOT IN ('6','1')
            """;

}
