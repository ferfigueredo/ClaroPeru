package com.claro.product.utils;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ConstantUtils {

    public static final String FIND_PRODUCTS_BY_CUSTOMER_ID = """
            SELECT 
                cp.CLIENTE_ID          AS customerId,
                cp.PRODUCTO_ID         AS productId,
                pl.NUMERO             AS lineNumber,
                p.CODIGO_ORIGEN       AS productOriginCode,
                pps.NOMBRE            AS descriptionPlan,
                pps.TIPO_PRODUCTO     AS lineType,
                pps.CODIGO_EXTERNO    AS linePlanCode,
                p.ALIAS               AS alias
            FROM CU_CLIENTE_PRODUCTO cp
            JOIN CU_PRODUCTO p            ON cp.PRODUCTO_ID = p.PRODUCTO_ID
            JOIN CU_PRODUCTO_PLAN_SERVICIO pps ON p.PRODUCTO_ID = pps.PRODUCTO_ID
            JOIN CU_PRODUCTO_LINEA pl      ON p.PRODUCTO_ID = pl.PRODUCTO_ID
            JOIN CU_PRODUCTO_ESTADO pe     ON p.PRODUCTO_ID = pe.PRODUCTO_ID
            JOIN CU_ESTADOS_PRODUCTO est   ON pe.ESTADO_ID = est.ESTADO_ID
            WHERE cp.CLIENTE_ID IN (:customerId)
              AND cp.FLAG_ACTIVO = 1
              AND pps.FLAG_ACTIVO = 1
              AND pl.FLAG_ACTIVO = 1
              AND pe.FLAG_ACTIVO = 1
            ORDER BY p.PRODUCTO_ID, pps.PLAN_ID  
            """;

    public static final String COUNT_PRODUCTS_BY_CUSTOMER_ID = """
            SELECT COUNT(*)
            FROM CU_CLIENTE_PRODUCTO cp
            JOIN CU_PRODUCTO p            ON cp.PRODUCTO_ID = p.PRODUCTO_ID
            JOIN CU_PRODUCTO_PLAN_SERVICIO pps ON p.PRODUCTO_ID = pps.PRODUCTO_ID
            JOIN CU_PRODUCTO_LINEA pl      ON p.PRODUCTO_ID = pl.PRODUCTO_ID
            JOIN CU_PRODUCTO_ESTADO pe     ON p.PRODUCTO_ID = pe.PRODUCTO_ID
            JOIN CU_ESTADOS_PRODUCTO est   ON pe.ESTADO_ID = est.ESTADO_ID
            WHERE cp.CLIENTE_ID IN (:customerId)
              AND cp.FLAG_ACTIVO = 1
              AND pps.FLAG_ACTIVO = 1
              AND pl.FLAG_ACTIVO = 1
              AND pe.FLAG_ACTIVO = 1
            """;

    public static final String FIND_PRODUCTS_BY_LINE_NUMBER = """
            SELECT 
                cp.CLIENTE_ID          AS customerId,
                cp.PRODUCTO_ID         AS productId,
                pl.NUMERO              AS lineNumber,
                p.CODIGO_ORIGEN        AS productOriginCode,
                pps.NOMBRE             AS descriptionPlan,
                pps.TIPO_PRODUCTO      AS lineType,
                pps.CODIGO_EXTERNO     AS linePlanCode,
                p.ALIAS                AS alias                   
            FROM CU_CLIENTE_PRODUCTO cp
            JOIN CU_PRODUCTO p                 ON cp.PRODUCTO_ID = p.PRODUCTO_ID
            LEFT JOIN CU_PRODUCTO p1           ON p.CODIGO_ORIGEN = p1.CODIGO_ORIGEN
                 AND p.SISTEMA_ORIGEN  = :primarySystem
                 AND p1.SISTEMA_ORIGEN = :secondarySystem
            JOIN CU_PRODUCTO_PLAN_SERVICIO pps ON p.PRODUCTO_ID = pps.PRODUCTO_ID AND pps.FLAG_ACTIVO = 1
            JOIN CU_PRODUCTO_LINEA pl          ON p.PRODUCTO_ID = pl.PRODUCTO_ID   AND pl.FLAG_ACTIVO = 1
            JOIN CU_PRODUCTO_ESTADO pe         ON p.PRODUCTO_ID = pe.PRODUCTO_ID   AND pe.FLAG_ACTIVO = 1
            JOIN CU_ESTADOS_PRODUCTO est       ON pe.ESTADO_ID = est.ESTADO_ID
            WHERE pl.NUMERO = :lineNumber
              AND cp.FLAG_ACTIVO = 1
              AND p1.PRODUCTO_ID IS NULL
            ORDER BY p.PRODUCTO_ID, pps.PLAN_ID
            """;

    public static final String COUNT_PRODUCTS_BY_LINE_NUMBER = """
            SELECT COUNT(*)
            FROM CU_CLIENTE_PRODUCTO cp
            JOIN CU_PRODUCTO p                 ON cp.PRODUCTO_ID = p.PRODUCTO_ID
            LEFT JOIN CU_PRODUCTO p1           ON p.CODIGO_ORIGEN = p1.CODIGO_ORIGEN
                 AND p.SISTEMA_ORIGEN  = :primarySystem
                 AND p1.SISTEMA_ORIGEN = :secondarySystem
            JOIN CU_PRODUCTO_LINEA pl          ON p.PRODUCTO_ID = pl.PRODUCTO_ID   AND pl.FLAG_ACTIVO = 1
            JOIN CU_PRODUCTO_ESTADO pe         ON p.PRODUCTO_ID = pe.PRODUCTO_ID   AND pe.FLAG_ACTIVO = 1
            WHERE pl.NUMERO = :lineNumber
              AND cp.FLAG_ACTIVO = 1
              AND p1.PRODUCTO_ID IS NULL
            """;

}
