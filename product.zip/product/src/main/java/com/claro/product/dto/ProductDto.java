package com.claro.product.dto;

import com.claro.common.commonlogger.utils.redaction.ARedactable;
import com.claro.common.commonlogger.utils.redaction.Redacted;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductDto extends ARedactable {

    @Redacted
    private String customerId;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private ClientDto client;
    private LineDto line;

}
