package com.claro.product;

import com.claro.common.commonlogger.scan.EnableClaroCommonLoggerComponentScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
@EnableClaroCommonLoggerComponentScan
public class ProductApp extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(ProductApp.class, args);
    }
}