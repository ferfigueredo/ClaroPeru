package com.claro.product.projection;

public interface ProductView {

    String getCustomerId();

    String getLineNumber();

    String getProductOriginCode();

    String getDescriptionPlan();

    String getLineType();

    String getLinePlanCode();

    String getAlias();

}
