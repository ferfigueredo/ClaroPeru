-- Create table
create table PERU.CU_PRODUCTO_PLAN_SERVICIO
(
  producto_id          VARCHAR2(25) not null,
  plan_id              VARCHAR2(20) not null,
  codigo_origen        VARCHAR2(50),
  secuencial           VARCHAR2(20),
  codigo_externo       VARCHAR2(50),
  codigo_instancia     VARCHAR2(20),
  nombre               VARCHAR2(250),
  descripcion          VARCHAR2(100),
  tipo_producto        VARCHAR2(20),
  tipo_servicio        VARCHAR2(100),
  fecha_inicio         DATE,
  fecha_fin            DATE,
  flag_activo          INTEGER default 1,
  sistema_origen       VARCHAR2(25),
  fecha_registro       DATE default SYSDATE,
  usuario_registro     VARCHAR2(25) default USER,
  fecha_modificacion   DATE default SYSDATE,
  usuario_modificacion VARCHAR2(25) default USER
);
-- Create/Recreate indexes 
create index PERU.IDX_CU_PRODUCTO_PLAN_SERVICIO_1 on PERU.CU_PRODUCTO_PLAN_SERVICIO (FLAG_ACTIVO);
create index PERU.IDX_CU_PRODUCTO_PLAN_SERVICIO_2 on PERU.CU_PRODUCTO_PLAN_SERVICIO (PRODUCTO_ID);
create index PERU.IDX_CU_PRODUCTO_PLAN_SERVICIO_3 on PERU.CU_PRODUCTO_PLAN_SERVICIO (PRODUCTO_ID, SECUENCIAL);
create index PERU.IDX_CU_PRODUCTO_PLAN_SERVICIO_4 on PERU.CU_PRODUCTO_PLAN_SERVICIO (SISTEMA_ORIGEN);
create index PERU.IDX_CU_PRODUCTO_PLAN_SERVICIO_5 on PERU.CU_PRODUCTO_PLAN_SERVICIO (PRODUCTO_ID, FLAG_ACTIVO);
create index PERU.IDX_CU_PRODUCTO_PLAN_SERVICIO_6 on PERU.CU_PRODUCTO_PLAN_SERVICIO (PRODUCTO_ID, FLAG_ACTIVO, SISTEMA_ORIGEN);
create index PERU.IDX_CU_PRODUCTO_PLAN_SERVICIO_7 on PERU.CU_PRODUCTO_PLAN_SERVICIO (FLAG_ACTIVO, SISTEMA_ORIGEN, FECHA_MODIFICACION);
-- Create/Recreate primary, unique and foreign key constraints 
alter table PERU.CU_PRODUCTO_PLAN_SERVICIO
  add constraint CU_PRODUCTO_PLAN_SERVICIO_FK_PRODUCTO foreign key (PRODUCTO_ID)
  references PERU.CU_PRODUCTO (PRODUCTO_ID);
