-- Create table
create table PERU.CU_PRODUCTO_LINEA
(
  producto_id          VARCHAR2(25) not null,
  linea_id             VARCHAR2(20) not null,
  codigo_origen        VARCHAR2(30) not null,
  secuencial           VARCHAR2(20),
  numero               VARCHAR2(20),
  fecha_inicio         DATE,
  fecha_fin            DATE,
  flag_activo          INTEGER default 1,
  sistema_origen       VARCHAR2(25),
  fecha_registro       DATE default SYSDATE,
  usuario_registro     VARCHAR2(25) default USER,
  fecha_modificacion   DATE default SYSDATE,
  usuario_modificacion VARCHAR2(25) default USER
);
-- Create/Recreate indexes 
create index PERU.IDX_CU_PRODUCTO_LINEA_1 on PERU.CU_PRODUCTO_LINEA (FLAG_ACTIVO);
create index PERU.IDX_CU_PRODUCTO_LINEA_2 on PERU.CU_PRODUCTO_LINEA (PRODUCTO_ID);
create index PERU.IDX_CU_PRODUCTO_LINEA_3 on PERU.CU_PRODUCTO_LINEA (PRODUCTO_ID, SECUENCIAL);
create index PERU.IDX_CU_PRODUCTO_LINEA_4 on PERU.CU_PRODUCTO_LINEA (NUMERO);
create index PERU.IDX_CU_PRODUCTO_LINEA_5 on PERU.CU_PRODUCTO_LINEA (PRODUCTO_ID, FLAG_ACTIVO, SISTEMA_ORIGEN);
create index PERU.IDX_CU_PRODUCTO_LINEA_6 on PERU.CU_PRODUCTO_LINEA (CODIGO_ORIGEN, SISTEMA_ORIGEN);
create index PERU.IDX_CU_PRODUCTO_LINEA_7 on PERU.CU_PRODUCTO_LINEA (PRODUCTO_ID, FLAG_ACTIVO);
create index PERU.IDX_CU_PRODUCTO_LINEA_8 on PERU.CU_PRODUCTO_LINEA (FLAG_ACTIVO, SISTEMA_ORIGEN, FECHA_MODIFICACION);
-- Create/Recreate primary, unique and foreign key constraints 
alter table PERU.CU_PRODUCTO_LINEA
  add constraint FK_CU_PRDLN_TO_PRD foreign key (PRODUCTO_ID)
  references PERU.CU_PRODUCTO (PRODUCTO_ID);