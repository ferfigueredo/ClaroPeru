-- Create table
create table PERU.CU_CLIENTE_PRODUCTO
(
  cliente_id           VARCHAR2(20) not null,
  producto_id          VARCHAR2(25) not null,
  fecha_inicio         DATE not null,
  fecha_fin            DATE,
  flag_activo          INTEGER default 1,
  sistema_origen       VARCHAR2(25),
  fecha_registro       DATE default SYSDATE,
  usuario_registro     VARCHAR2(25) default USER,
  fecha_modificacion   DATE default SYSDATE,
  usuario_modificacion VARCHAR2(25) default USER
);
-- Create/Recreate indexes 
create index PERU.IDX_CLIENTE_PRODUCTO_1 on PERU.CU_CLIENTE_PRODUCTO (PRODUCTO_ID);
create index PERU.IDX_CLIENTE_PRODUCTO_2 on PERU.CU_CLIENTE_PRODUCTO (CLIENTE_ID);
create index PERU.IDX_CLIENTE_PRODUCTO_5 on PERU.CU_CLIENTE_PRODUCTO (SISTEMA_ORIGEN);
create index PERU.IDX_CLIENTE_PRODUCTO_6 on PERU.CU_CLIENTE_PRODUCTO (PRODUCTO_ID, FLAG_ACTIVO);
create index PERU.IDX_CU_CLIENTE_PRODUCTO_3 on PERU.CU_CLIENTE_PRODUCTO (CLIENTE_ID, FLAG_ACTIVO);
create index PERU.IDX_CU_CLIENTE_PRODUCTO_4 on PERU.CU_CLIENTE_PRODUCTO (FLAG_ACTIVO);
-- Create/Recreate primary, unique and foreign key constraints 
alter table PERU.CU_CLIENTE_PRODUCTO
  add constraint XPKCU_CLIENTE_PRODUCTO1 primary key (CLIENTE_ID, PRODUCTO_ID, FECHA_INICIO);
alter table PERU.CU_CLIENTE_PRODUCTO
  add constraint CU_CLIENTE_PRODUCTO_FK_CLIENTE foreign key (CLIENTE_ID)
  references PERU.CU_CLIENTE (CLIENTE_ID);
alter table PERU.CU_CLIENTE_PRODUCTO
  add constraint CU_CLIENTE_PRODUCTO_FK_PRODUCTO1 foreign key (PRODUCTO_ID)
  references PERU.CU_PRODUCTO (PRODUCTO_ID);