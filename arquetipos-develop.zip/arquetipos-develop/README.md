# create-mf-project CLI

CLI para generar proyectos Angular microfrontend con Native Federation (host o remote).

## 1. Requerimientos

Para que el arquetipo funcione correctamente, es necesario tener instaladas las siguientes versiones mínimas:

- **Node.js >= 20.19**  
  *(recomendado: Node 22.12 o superior, ya que algunas versiones del Angular CLI requieren esta versión)*  
- **npm >= 10**
- **Angular CLI >= 18** (el proyecto generado usa esta versión)

> Si usás una versión anterior de Node (por ejemplo 18.x o 20.0.0), al ejecutar Angular CLI verás errores como:  
> **"The Angular CLI requires a minimum Node.js version of v20.19 or v22.12."**

Una vez instalado, clonar este repositorio en local.

Luego en local, correr en consola:

```
npm install
```
y
```
npm link
```

Asi va a quedar disponible para usar.


## 2. Uso

Uso correcto: 

```
create-mf-project <nombre> --port <puerto> --type <host|remote>
```

### Crear un Shell (host):
```bash
npx create-mf-project nombre-shell --port 4200 --type host
```

### Crear un Remote:
```bash
npx create-mf-project nombre-mf --port 4201 --type remote
```

## 3. Conectar Shell con Microfrontend

### Agregar nuevo Remote al Shell


En el proyecto del shell, agregar url en el archivo ```federation.manifest.js``` y registrar la ruta en el archivo ```app.routes.ts```


federation.manifest.js


    {
      "customer-mf": "http://localhost:4201/remoteEntry.json"
    }


app.routes.ts


    import { loadRemoteModule } from '@angular-architects/native-federation';
    import { Routes } from '@angular/router';


    export const routes: Routes = [
      {
        path: 'customer',
        loadComponent: () => loadRemoteModule('customer-mf', './Component').then((m) => m.App)
      }
    ];


---


#### IMPORTANTE
En **app.routes.ts** el nombre del microfrontend que se pasa al metodo ```loadRemoteModule()``` debe coincidir con el nombre registrado en el **federation.manifest.js** (como en el ejemplo 'customer-mf' en ambos)


---




## 4. Primera vez levantando el proyecto


Una vez completada la configuracion inincial, ejecutamos un ```ng build``` **en cada proyecto**, esto genera el output ```./dist```


Y finalmente ejecutamos el ```ng serve``` (o ng s)  **en cada proyecto** para correr local y probar.